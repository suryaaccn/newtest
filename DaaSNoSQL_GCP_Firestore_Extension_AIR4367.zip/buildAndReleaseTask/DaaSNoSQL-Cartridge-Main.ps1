param (

    $PAT,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AirID,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AppName,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$SolutionToDeploy,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$OperationToPerform,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$SetupOptions,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AdhocBackupOptions,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AdhocRestoreOptions,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$Repo,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$ConfigFile,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AzureDevOpsProjectName,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AzureDevOpsProjectId,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$AzureDevOpsOrg,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RequestorEmail,
    [Parameter(Mandatory=$True)][ValidateNotNullOrEmpty()][string]$RequestorName
)


foreach($key in $PSBoundParameters.Keys)
{
     Write-Verbose ("  $($key)" + ' = ' + $PSBoundParameters[$key]) -Verbose
}

$TOOL_TF_BACKEND_KEY = ""
$ACR_BACKEND = ""
$GitCredential = ""
$AzureDevOpsOrg = $AzureDevOpsOrg.TrimEnd('/') -replace "https://dev.azure.com/",""
$AzureDevOpsAccount = "$AzureDevOpsOrg.visualstudio.com"
$base64AuthInfo = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(("{0}:{1}" -f "",$PAT)))

#Import DaaSNoSQL_Cartridge_Modules_AIR4367
cd $PSScriptRoot

Get-ChildItem -Path "DaaSNoSQL_Cartridge_Modules_AIR4367" -Recurse | Remove-Item -force -recurse -ErrorAction SilentlyContinue
Remove-Item "DaaSNoSQL_Cartridge_Modules_AIR4367" -Force  -ErrorAction SilentlyContinue

git clone https://$GitCredential@dev.azure.com/accenturecio08/DataPlatformEng_4367/_git/DaaSNoSQL_Cartridge_Modules_AIR4367

$PSM1Path = $PSScriptRoot + "\DaaSNoSQL_Cartridge_Modules_AIR4367\DaaSNoSQL.psm1"
Import-Module $PSM1Path

#Get inputs from config file
$BackupRestoreEnv, $BackupRestoreBlobContainer, $BackupRestoreStorageClass, $BackupRestoreStorageLocation, $BackupRestoreCloudSchedRegion, $BackupRestoreCloudSchedTimezone, $BackupRestoreProjectID, $BackupRestoreProjectName, $BackupRestoreSA, $BackupRestoreSAClientEmail, $BackupRestoreCredFile, $BackupRestoreCreateCloudSched, $AdhocBackupRestoreEnv, $AdhocBackupRestoreProjectID, $AdhocBackupRestoreSAClientEmail, $AdhocBackupRestoreCredFile, $AdhocBackupRestorePipeline, $AdhocBackupRestoreRepository, $AdhocBackupRestoreYAMLFile, $AdhocBackupRestoreBucket, $AdhocBackupRestoreFilePath, $AdhocBackupRestoreCollections, $AdhocBackupRestorePubsubTopic, $AdhocBackupRestoreFilter = GetDetails -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -Repo $Repo -ConfigFile $ConfigFile

#Validate inputs for the setup
if([string]::IsNullOrEmpty($BackupRestoreEnv) -or [string]::IsNullOrEmpty($BackupRestoreBlobContainer) -or [string]::IsNullOrEmpty($BackupRestoreStorageClass) -or [string]::IsNullOrEmpty($BackupRestoreStorageLocation) -or [string]::IsNullOrEmpty($BackupRestoreCloudSchedRegion) -or [string]::IsNullOrEmpty($BackupRestoreCloudSchedTimezone) -or [string]::IsNullOrEmpty($BackupRestoreProjectID) -or [string]::IsNullOrEmpty($BackupRestoreProjectName) -or [string]::IsNullOrEmpty($BackupRestoreSA) -or [string]::IsNullOrEmpty($BackupRestoreSAClientEmail) -or [string]::IsNullOrEmpty($BackupRestoreCredFile) -or [string]::IsNullOrEmpty($BackupRestoreCreateCloudSched)){
    
    try{
            
        1/0
    }
    catch{
            
        Throw "Please make sure to provide all the details needed in the JSON file."
        Exit
    }
}
else{

    #Validate if the CreateCloudScheduler property is set to true or false
    if($BackupRestoreCreateCloudSched -ne 'true' -and $BackupRestoreCreateCloudSched -ne 'false'){
        
        try{
            
            1/0
        }
        catch{
            
            Throw "Please make sure that the value for CreateCloudScheduler in the JSON file is set to true or false only!"
            Exit
        }

    }

    #Validate if the environment property is set to the following values: "Sbx", "Dev", "Test", "Stage", "Perf", or "Prod"
    if($BackupRestoreEnv -ne 'Sbx' -and $BackupRestoreEnv -ne 'Dev' -and $BackupRestoreEnv -ne 'Test' -and $BackupRestoreEnv -ne 'Stage' -and $BackupRestoreEnv -ne 'Perf' -and $BackupRestoreEnv -ne 'Prod'){
        
        try{
            
            1/0
        }
        catch{
            
            Throw "Please make sure that the value for Environment in the JSON file is set to Sbx, Dev, Test, Stage, Perf, or Prod only!"
            Exit
        }

    }
    else{

        #Performing what was selected
        if("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "SetupResources" -and $SetupOptions -eq "FirstTime"){
    
            Write-Host
            Write-Host "Setting up Resources to deploy the Backup and Restore Solution in your GCP Project..."
            Write-Host

            $adhocBRRepo = $AppName + "_adhoc_backup_restore_repo_AIR" + $AirID
            $adhocBRPipeline = $AppName + "_adhoc_backup_restore_AIR" + $AirID
            $alertsMonitoringRepo = $AppName + "_alerts_monitoring_backup_restore_repo_AIR" + $AirID
            $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_backup_restore_AIR" + $AirID
            $backupRestoreRepo = $AppName + "_backup_restore_repo_AIR" + $AirID
            $backupRestorePipeline = $AppName + "_backup_restore_AIR" + $AirID

            #Check first if repos and pipeline provided are existing or not
            $checkifBackupRestorePipelinesRepoExists = CheckifBackupRestorePipelinesRepoExists -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AppName $AppName -backupRestoreRepo $backupRestoreRepo -alertsMonitoringRepo $alertsMonitoringRepo -adhocBRRepo $adhocBRRepo -backupRestorePipeline $backupRestorePipeline -adhocBRPipeline $adhocBRPipeline -alertsMonitoringPipeline $alertsMonitoringPipeline

            if($checkifBackupRestorePipelinesRepoExists -eq $true){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Some of the Repositories and Pipelines are already existing!"
                    Exit
                }
            }
            else{

                #Proceed with setup
                Write-Verbose "Pipelines and Repos are not yet existing, beginning to create..." -Verbose

                $setupBRsolution = SetupBackupRestoreSolution -PAT $PAT -AirID $AirID -AppName $AppName -BackupRestoreEnv $BackupRestoreEnv -BackupRestoreBlobContainer $BackupRestoreBlobContainer -BackupRestoreStorageClass $BackupRestoreStorageClass -BackupRestoreStorageLocation $BackupRestoreStorageLocation -BackupRestoreCloudSchedRegion $BackupRestoreCloudSchedRegion -BackupRestoreCloudSchedTimezone $BackupRestoreCloudSchedTimezone -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreProjectName $BackupRestoreProjectName -BackupRestoreSA $BackupRestoreSA -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreCreateCloudSched $BackupRestoreCreateCloudSched -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName -TOOL_TF_BACKEND_KEY $TOOL_TF_BACKEND_KEY -ACR_BACKEND $ACR_BACKEND
            }
        }
        elseif("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "SetupResources" -and $SetupOptions -eq "OtherEnv"){
    
            Write-Host
            Write-Host "Setting up Resources to deploy the Backup and Restore Solution to your other Environments..."
            Write-Host

            $adhocBRRepo = $AppName + "_adhoc_backup_restore_repo_AIR" + $AirID
            $adhocBRPipeline = $AppName + "_adhoc_backup_restore_AIR" + $AirID
            $alertsMonitoringRepo = $AppName + "_alerts_monitoring_backup_restore_repo_AIR" + $AirID
            $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_backup_restore_AIR" + $AirID
            $backupRestoreRepo = $AppName + "_backup_restore_repo_AIR" + $AirID
            $backupRestorePipeline = $AppName + "_backup_restore_AIR" + $AirID

            #Check first if repos and pipeline provided are existing or not
            $checkifBackupRestorePipelinesRepoExists = CheckifBackupRestorePipelinesRepoExists -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AppName $AppName -backupRestoreRepo $backupRestoreRepo -alertsMonitoringRepo $alertsMonitoringRepo -adhocBRRepo $adhocBRRepo -backupRestorePipeline $backupRestorePipeline -adhocBRPipeline $adhocBRPipeline -alertsMonitoringPipeline $alertsMonitoringPipeline

            if($checkifBackupRestorePipelinesRepoExists -eq $false){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Repositories and Pipelines are not yet existing!"
                    Exit
                }
            }
            else{

                #Proceed with setup
                $setupBRsolutionToOtherEnvironments = SetupBackupRestoreSolutionForOtherEnvironments -PAT $PAT -AirID $AirID -AppName $AppName -BackupRestoreEnv $BackupRestoreEnv -BackupRestoreStorageClass $BackupRestoreStorageClass -BackupRestoreStorageLocation $BackupRestoreStorageLocation -BackupRestoreCloudSchedRegion $BackupRestoreCloudSchedRegion -BackupRestoreCloudSchedTimezone $BackupRestoreCloudSchedTimezone -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreProjectName $BackupRestoreProjectName -BackupRestoreSA $BackupRestoreSA -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreCreateCloudSched $BackupRestoreCreateCloudSched -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName
            }
        }
        elseif("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "SetupResources" -and $SetupOptions -eq "Redeploy"){
    
            Write-Host
            Write-Host "Setting up Resources to redeploy the Backup and Restore Solution to your other GCP Project..."
            Write-Host

            $adhocBRRepo = $AppName + "_adhoc_backup_restore_repo_AIR" + $AirID
            $adhocBRPipeline = $AppName + "_adhoc_backup_restore_AIR" + $AirID
            $alertsMonitoringRepo = $AppName + "_alerts_monitoring_backup_restore_repo_AIR" + $AirID
            $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_backup_restore_AIR" + $AirID
            $backupRestoreRepo = $AppName + "_backup_restore_repo_AIR" + $AirID
            $backupRestorePipeline = $AppName + "_backup_restore_AIR" + $AirID

            #Check first if repos and pipeline provided are existing or not
            $checkifBackupRestorePipelinesRepoExists = CheckifBackupRestorePipelinesRepoExists -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AppName $AppName -backupRestoreRepo $backupRestoreRepo -alertsMonitoringRepo $alertsMonitoringRepo -adhocBRRepo $adhocBRRepo -backupRestorePipeline $backupRestorePipeline -adhocBRPipeline $adhocBRPipeline -alertsMonitoringPipeline $alertsMonitoringPipeline

            if($checkifBackupRestorePipelinesRepoExists -eq $false){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Repositories and Pipelines are not yet existing!"
                    Exit
                }
            }
            else{

                #Proceed with setup
                $setupBRsolutionToOtherGCPProjects = SetupBackupRestoreSolutionForOtherGCPProjects -PAT $PAT -AirID $AirID -AppName $AppName -BackupRestoreEnv $BackupRestoreEnv -BackupRestoreStorageClass $BackupRestoreStorageClass -BackupRestoreStorageLocation $BackupRestoreStorageLocation -BackupRestoreCloudSchedRegion $BackupRestoreCloudSchedRegion -BackupRestoreCloudSchedTimezone $BackupRestoreCloudSchedTimezone -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreProjectName $BackupRestoreProjectName -BackupRestoreSA $BackupRestoreSA -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreCreateCloudSched $BackupRestoreCreateCloudSched -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName
            }
        }
    }
}


#Validate inputs for adhoc backup or restore
if([string]::IsNullOrEmpty($AdhocBackupRestoreEnv) -or [string]::IsNullOrEmpty($AdhocBackupRestoreProjectID) -or [string]::IsNullOrEmpty($AdhocBackupRestoreSAClientEmail) -or [string]::IsNullOrEmpty($AdhocBackupRestoreCredFile) -or [string]::IsNullOrEmpty($AdhocBackupRestorePipeline) -or [string]::IsNullOrEmpty($AdhocBackupRestoreRepository) -or [string]::IsNullOrEmpty($AdhocBackupRestoreYAMLFile) -or [string]::IsNullOrEmpty($AdhocBackupRestoreBucket) -or [string]::IsNullOrEmpty($AdhocBackupRestorePubsubTopic)){
    
    try{
            
        1/0
    }
    catch{
            
        Throw "Please make sure to provide the details needed in the JSON file."
        Exit
    }
}
else{
    
    #Validate if the environment property is set to the following values: "Sbx", "Dev", "Test", "Stage", "Perf", or "Prod"
    if($AdhocBackupRestoreEnv -ne 'Sbx' -and $AdhocBackupRestoreEnv -ne 'Dev' -and $AdhocBackupRestoreEnv -ne 'Test' -and $AdhocBackupRestoreEnv -ne 'Stage' -and $AdhocBackupRestoreEnv -ne 'Perf' -and $AdhocBackupRestoreEnv -ne 'Prod'){
        
        try{
            
            1/0
        }
        catch{
            
            Throw "Please make sure that the value for Environment in the JSON file is set to Sbx, Dev, Test, Stage, Perf, or Prod only!"
            Exit
        }

    }
    else{

        if("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "AdhocBackup" -and $AdhocBackupOptions -eq "BackupSpecificCollection"){
    
            Write-Host
            Write-Verbose "Performing Adhoc Backup of specific collection\s only..."
            Write-Host

            $isNullorWhiteSpace = [string]::IsNullOrWhiteSpace($AdhocBackupRestoreFilePath)

            if($isNullorWhiteSpace -ne $true){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure not to provide a File Path in the JSON file"
                    Exit
                }
            }

            Write-Host "Checking if the GCP Project ID corresponds to the Environment provided..." -Verbose

            if($AdhocBackupRestoreEnv -eq 'Sbx'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID -like 'sbx*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a Sandbox environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }
            elseif($AdhocBackupRestoreEnv -eq 'Dev' -or $AdhocBackupRestoreEnv -eq 'Test' -or $AdhocBackupRestoreEnv -eq 'Stage' -or $AdhocBackupRestoreEnv -eq 'Perf'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'npd*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }

            }
            elseif($AdhocBackupRestoreEnv -eq 'Prod'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'prd*'

                if($checkProjectID -eq $false){
            
	                try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }

            $adhocBackupSpecific = PerformAdhocBackupSpecificCollection -PAT $PAT -AirID $AirID -AppName $AppName -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter
    
            if($adhocBackupSpecific -eq $false){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure to provide collection/s in the JSON file"
                    Exit
                }
            }
        }
        elseif("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "AdhocBackup" -and $AdhocBackupOptions -eq "BackupAllCollection"){
    
            Write-Host
            Write-Verbose "Performing Adhoc Backup of all collections..."
            Write-Host

            $isNullorWhiteSpace = [string]::IsNullOrWhiteSpace($AdhocBackupRestoreFilePath)

            if($isNullorWhiteSpace -ne $true){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure not to provide a File Path in the JSON file"
                    Exit
                }
            }

            Write-Host "Checking if the GCP Project ID corresponds to the Environment provided..." -Verbose

            if($AdhocBackupRestoreEnv -eq 'Sbx'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID -like 'sbx*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a Sandbox environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }
            elseif($AdhocBackupRestoreEnv -eq 'Dev' -or $AdhocBackupRestoreEnv -eq 'Test' -or $AdhocBackupRestoreEnv -eq 'Stage' -or $AdhocBackupRestoreEnv -eq 'Perf'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'npd*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }

            }
            elseif($AdhocBackupRestoreEnv -eq 'Prod'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'prd*'

                if($checkProjectID -eq $false){
            
	                try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }

            $adhocBackupAll = PerformAdhocBackupAllCollections -PAT $PAT -AirID $AirID -AppName $AppName -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

            if($adhocBackupAll -eq $false){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure not to provide any collection in the JSON file"
                    Exit
                }
            }
        }
        elseif("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "AdhocRestore" -and $AdhocRestoreOptions -eq "RestoreSpecificCollection"){
    
            Write-Host
            Write-Verbose "Performing Adhoc Restore for specific collection\s only..."
            Write-Host

            $isNullorWhiteSpace = [string]::IsNullOrWhiteSpace($AdhocBackupRestoreFilePath)

            if($isNullorWhiteSpace -eq $true){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure to provide the File Path in the JSON file"
                    Exit
                }
            }

            Write-Host "Checking if the GCP Project ID corresponds to the Environment provided..." -Verbose

            if($AdhocBackupRestoreEnv -eq 'Sbx'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID -like 'sbx*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a Sandbox environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }
            elseif($AdhocBackupRestoreEnv -eq 'Dev' -or $AdhocBackupRestoreEnv -eq 'Test' -or $AdhocBackupRestoreEnv -eq 'Stage' -or $AdhocBackupRestoreEnv -eq 'Perf'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'npd*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }

            }
            elseif($AdhocBackupRestoreEnv -eq 'Prod'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'prd*'

                if($checkProjectID -eq $false){
            
	                try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }

            $adhocRestoreSpecific = PerformAdhocRestoreSpecificCollection -PAT $PAT -AirID $AirID -AppName $AppName -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter
    
            if($adhocRestoreSpecific -eq $false){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure to provide collection/s in the JSON file"
                    Exit
                }
            }
        }
        elseif("$SolutionToDeploy" -eq "BackupRestore" -and $OperationToPerform -eq "AdhocRestore" -and $AdhocRestoreOptions -eq "RestoreAllCollection"){
    
            Write-Host
            Write-Verbose "Performing Adhoc Restore of all collections..."
            Write-Host

            $isNullorWhiteSpace = [string]::IsNullOrWhiteSpace($AdhocBackupRestoreFilePath)

            if($isNullorWhiteSpace -eq $true){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure to provide the File Path in the JSON file"
                    Exit
                }
            }

            Write-Host "Checking if the GCP Project ID corresponds to the Environment provided..." -Verbose

            if($AdhocBackupRestoreEnv -eq 'Sbx'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID -like 'sbx*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a Sandbox environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }
            elseif($AdhocBackupRestoreEnv -eq 'Dev' -or $AdhocBackupRestoreEnv -eq 'Test' -or $AdhocBackupRestoreEnv -eq 'Stage' -or $AdhocBackupRestoreEnv -eq 'Perf'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'npd*'

                if($checkProjectID -eq $false){
            
                    try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }

            }
            elseif($AdhocBackupRestoreEnv -eq 'Prod'){
        
                $checkProjectID = $AdhocBackupRestoreProjectID  -like 'prd*'

                if($checkProjectID -eq $false){
            
	                try{
            
                        1/0
                    }
                    catch{
                
                        Write-Host
                        Write-Host "GCP Project ID provided is not a $($AdhocBackupRestoreEnv) environment."
                        Write-Host
                        Write-Host "Environment: $($AdhocBackupRestoreEnv)"
                        Write-Host "GCP Project ID: $($AdhocBackupRestoreProjectID)"

                        Throw "Please make sure that the GCP Project ID corresponds to the Environment provided in the JSON file"
                        Exit
                    }
                }
            }

            $adhocRestoreAll = PerformAdhocRestoreAllCollections -PAT $PAT -AirID $AirID -AppName $AppName -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectId $AzureDevOpsProjectId -PSM1Path $PSM1Path -RequestorEmail $RequestorEmail -RequestorName $RequestorName -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

            if($adhocRestoreAll -eq $false){
        
                try{
            
                    1/0
                }
                catch{
            
                    Throw "Please make sure not to provide any collection in the JSON file"
                    Exit
                }
            }
        }
    }
}