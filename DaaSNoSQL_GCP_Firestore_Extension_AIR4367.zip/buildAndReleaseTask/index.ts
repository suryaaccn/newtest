import tl = require('azure-pipelines-task-lib/task');
import { SSL_OP_NO_TLSv1_1 } from 'constants';
import os = require('os');

async function run() {
    try {
        tl.assertAgent('2.115.0');
        tl.cd(__dirname);
        let psCorePath = tl.which('pwsh');
        let psPath = tl.which('powershell');
        if(psCorePath || psPath) {
            const DaaSNoSQLCartridgeScript = __dirname + '\\DaaSNoSQL-Cartridge-Main.ps1';

            let ENV_Pat = tl.getVariable("vsts.pat");
            let ENV_AzureDevOpsProjectName = tl.getVariable("System.TeamProject");
            let ENV_AzureDevOpsProjectId = tl.getVariable("System.TeamProjectId");
            let ENV_AzureDevOpsOrg = tl.getVariable("System.TeamFoundationCollectionUri");
            let ENV_RequestorEmail = tl.getVariable("Build.RequestedForEmail");
            let ENV_RequestorName = tl.getVariable("Build.RequestedFor");
            let input_Air_ID = tl.getInput("AirID");
            let input_App_Name = tl.getInput("AppName");

            let input_Solution_To_Deploy = tl.getInput("SolutionToDeploy");
            let input_Operation_To_Perform = tl.getInput("OperationToPerform");
            let input_Setup_Options = tl.getInput("SetupOptions");
            let input_Adhoc_Backup_Options = tl.getInput("AdhocBackupOptions");
            let input_Adhoc_Restore_Options = tl.getInput("AdhocRestoreOptions");
            let input_Repo = tl.getInput("Repository");
            let input_ConfigFile = tl.getInput("ConfigFile");

            if (!ENV_Pat || ENV_Pat.length === 0){
                tl.setResult(tl.TaskResult.Failed, "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret.");
            }
            else{

                if (input_Solution_To_Deploy = 'BackupRestore'){
                    let powershell = tl.tool(psCorePath || psPath || tl.which('pwsh', true))
                        .arg('-NoLogo')
                        .arg('-NoProfile')
                        .arg('-NonInteractive')
                        .arg('-Command')
                        .arg(`& '${DaaSNoSQLCartridgeScript}' '${ENV_Pat}' '${input_Air_ID}' '${input_App_Name}' '${input_Solution_To_Deploy}' '${input_Operation_To_Perform}' '${input_Setup_Options}' '${input_Adhoc_Backup_Options}' '${input_Adhoc_Restore_Options}' '${input_Repo}' '${input_ConfigFile}' '${ENV_AzureDevOpsProjectName}' '${ENV_AzureDevOpsProjectId}' '${ENV_AzureDevOpsOrg}' '${ENV_RequestorEmail}' '${ENV_RequestorName}'`);
                    await powershell.exec();    
                }
            }
        } 
        else {
            tl.setResult(tl.TaskResult.Failed, "Powershell is not installed.  Please install Powershell to run this task.");
        }
    }
    catch (err) {
        tl.setResult(tl.TaskResult.Failed, err.message);
    }
}
run();