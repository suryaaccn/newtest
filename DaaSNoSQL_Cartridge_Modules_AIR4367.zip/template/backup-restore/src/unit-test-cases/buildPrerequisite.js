const { Firestore } = require("@google-cloud/firestore");

const{Storage}=require("@google-cloud/storage");
//const { storage } = require("googleapis/build/src/apis/storage");
const testconfig = require("./testConfig.json");

//let _firestore = require("@google-cloud/firestore");

var TestCollectionName = testconfig.TestCollectionName;
var dataObjects=testconfig.dataObjects;
//var GCLOUD_PROJECT = process.env.GCLOUD_PROJECT;
/*
var dataObjects=[
    { id:1 , Name:"Mangesh" , Subjects:"Maths" },
    { id:2 , Name:"Sam" , Subjects:"Physics" },
    { id:3 , Name:"Mary" , Subjects:"Chemistry" },
    { id:4 , Name:"Javi" , Subjects:"History" },
    { id:5 , Name:"Flor" , Subjects:"Geography" }
];*/
var objData;
module.exports ={
    createCollection : createCollection,
    addData : addData,
    deleteCollection : deleteCollection,
    createStorage:createStorage,
    deleteStorage:deleteStorage
};

async function createStorage(bucketName){
    try {
        var _storage=new Storage();
        var res = await _storage.bucket(bucketName).exists();
        if(res[0]==false)
        {
            var s = await _storage.createBucket(bucketName);
            console.log(s);
            console.log("Bucket Created Successfully");
        }
        
    } catch (error) {
        console.log(error);
    }
}

async function deleteStorage(bucketName){
    try {
        var _storage=new Storage();

        var files = await _storage.bucket(bucketName).deleteFiles();
        console.log(`Files in Bucket:${bucketName} deleted Successfully`);
        var s = await _storage.bucket(bucketName).delete();
        console.log("Bucket Deleted Successfully");
        console.log(s);
    } catch (error) {
        console.log(error);
    }
}
//module.exports.createCollection = async function(){
async function createCollection(TestCollectionName){
    return new Promise(async function(resolve,reject){
        try {
            for(i=0;i<dataObjects.length;i++)
            {
                await addData(TestCollectionName,dataObjects[i]);
            }
            console.log("Data Added To collection");
            resolve("SUCCESS"); 
        } catch (error) {
            console.log(error);
            reject("ERROR"); 
        }
    });
}

//module.exports.addData=async function(objData){
async function addData(TestCollectionName,objData){
    return new Promise(async function(resolve,reject){
        try {
            let _firestore = new Firestore({
                projectId:process.env.GCLOUD_PROJECT
            });
            let addDoc = await _firestore.collection(TestCollectionName).add(objData).
            then(ref => {
                console.log('Logs added to Firestore collection with ID: ', ref.id);
                resolve("SUCCESS");
            });
        } catch (error) {
            console.log(error);
            reject("ERROR");
        }
    });
}


//module.exports.deleteCollection = async function(){
async function deleteCollection(TestCollectionName){
    return new Promise(async function(resolve,reject){
        try {
            let _firestore = new Firestore({
                projectId:process.env.GCLOUD_PROJECT
            });
            var collectionRef = await _firestore.collection(TestCollectionName).get();
            var docs = collectionRef.docs;
            for(i=0;i<docs.length;i++)
            {
                var res = await docs[i].ref.delete();
            }
            console.log("Data removed from collection");
            resolve("SUCCESS"); 
        } catch (error) {
            console.log(error);
            reject("ERROR"); 
        }
    });
}