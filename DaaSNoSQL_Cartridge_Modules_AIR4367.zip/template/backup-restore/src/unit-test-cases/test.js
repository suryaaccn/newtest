var assert = require('chai').assert;
const monitoring = require('@google-cloud/monitoring');
const {GoogleAuth} = require('google-auth-library');
const {google,firestore_v1, monitoring_v3} = require('googleapis');
const firestore1 = google.firestore('v1');

const {Logging, Entry, Log} = require('@google-cloud/logging');

const sinon = require('sinon');
const firestore = require('@google-cloud/firestore');
const client = new firestore.v1.FirestoreAdminClient();
const {expect} = require('chai');
const testconfig = require("./testConfig.json");
process.env.GCLOUD_PROJECT = testconfig.GCLOUD_PROJECT;

var TestCollectionName = testconfig.TestCollectionName;

var br_app = require("../index");
//var prerequisite = require("./buildPrerequisite");

describe('hooks', function() {
  var stub_mock_listCollections,stub_mock_exportDocuments,stub_getstatus,stub_getAuthClient,stub_mock_importDocuments;
  var stub_createTimeSeries,stub_collectionRef,stub_docref,stub_docAdd,stub_createMetricDescriptor;

  beforeEach(function() {
    // runs once before the first test in this block
    stub_mock_listCollections = sinon.stub(firestore.Firestore.prototype, 'listCollections');
    stub_mock_listCollections.returns([
      {id: "Sample"}, 
      {id: "Sample_1010"}, 
      {id: "Test"}, 
      {id: "Sample_2010"}
    ]);

    stub_mock_exportDocuments = sinon.stub(firestore.v1.FirestoreAdminClient.prototype, 'exportDocuments');
    stub_mock_exportDocuments
    .withArgs(sinon.match.any)
    .returns(Promise.resolve([{
      metadata: {
        outputUriPrefix: `gs://${testconfig.BUCKET}/2021-02-10T07:59:01_20184`,
        startTime: {
          seconds:new Date('2021-02-10T07:59:01.301854Z').getTime()
        }
      },
      name: "sample"
    }]));

    _date = new Date();
    stub_getstatus = sinon.stub(firestore_v1.Resource$Projects$Databases$Operations.prototype, 'get');
    stub_getstatus.returns({
    data: {
          metadata: {
            operationState:"SUCCESSFUL",
            progressDocuments:{
              completedWork:34234
            },
            progressBytes:{
              completedWork:324234
            },
            startTime:_date,
            endTime:_date.setSeconds(50)
          },
          error:{
            message:"ERROR",
            code:999
          }
      }
    });

    stub_getAuthClient = sinon.stub(GoogleAuth.prototype, 'getClient');
    stub_getAuthClient.returns({
        _clientId: "test",
        _clientSecret: "test"
    });  

    stub_mock_importDocuments = sinon.stub(firestore.v1.FirestoreAdminClient.prototype, 'importDocuments');
    stub_mock_importDocuments
    .withArgs(sinon.match.any)
    .returns(Promise.resolve([{
      metadata: {
        inputUriPrefix: `gs://${testconfig.BUCKET}/2021-02-10T07:59:01_20184`,
        startTime: {
          seconds:new Date('2021-02-10T07:59:01.301854Z').getTime()
        }
      },
      name: "sample"
    }]));
  
    stub_createTimeSeries = sinon.stub(monitoring.MetricServiceClient.prototype,'createTimeSeries')
    stub_createTimeSeries.returns([{}]);

    stub_collectionRef = sinon.stub(firestore.Firestore.prototype,"collection");
    stub_collectionRef.returns({result:"SUCCESS5",listDocuments:function(){return [
      {
        path:"SamplePath/SJ6oKnGFrGwbQY7dFSme",
        id:"SJ6oKnGFrGwbQY7dFSme",
        OPERATIONLOGPATH:"MOCK_OPERATIONLOGPATH"
      }
    ]}});

    stub_docref = sinon.stub(firestore.Firestore.prototype,"doc");
    stub_docref.returns({
      result:"SUCCESS1",
      get:function(){
        return{
          data:()=>{
            return {Name:"Sample"}; 
          } 
        }
      },
      delete:async function(){
        return Promise.resolve("DELETED");
      }
    });

    /*
    stub_docAdd = sinon.stub(firestore.CollectionReference.prototype,"add");
    stub_docAdd
    //.withArgs("BackupRestoreLogs")
    .resolves({
      add:async ()=>{
        Promise.resolve({id:"asdasdasdasd"});
      }
    });
    */
   
   var obj = {
        description: 'Susccessful instance for Backup',
        displayName: 'Susccessful Backup Instance',
        type: 'custom.googleapis.com/firestore/verify_successbackup_instance',
        metricKind: 'GAUGE',
        valueType: 'DOUBLE',
        unit: '{Count}',
        labels: [
          {
            key: 'successfulbackup_instance',
            valueType: 'STRING',
            description: 'Susccessful backup instance',
          },
        ],
      };
    stub_createMetricDescriptor = sinon.stub(monitoring.MetricServiceClient.prototype,'createMetricDescriptor');
    stub_createMetricDescriptor
    //.onCall(0)
    .withArgs({
      "name":`projects/${testconfig.GCLOUD_PROJECT}`,
      "metricDescriptor":{
        "description":"Susccessful instance for Backup",
        "displayName":"Susccessful Backup Instance",
        "type":"custom.googleapis.com/firestore/verify_successbackup_instance",
        "metricKind":"GAUGE",
        "valueType":"DOUBLE",
        "unit":"{Count}",
        "labels":[
          {
            "key":"successfulbackup_instance",
            "valueType":"STRING",
            "description":"Susccessful backup instance"
          }]
        }
      })
    .returns([{
      name:`projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/verify_successbackup_instance`,
      displayName:"mock_displayName",
      description:"mock_description",
      type:"mock_type",
      metricKind:"mock_metricKind",
      valueType:"mock_valueType",
      unit:"mock_unit",
      labels:[
        {
          key:"mock_key",
          valueType:"mock_valueType",
          description:"mock_description"
        }
      ]
    }]);

    stub_createMetricDescriptor
    .withArgs({
      "name":`projects/${testconfig.GCLOUD_PROJECT}`,
      "metricDescriptor":{
        description: 'Failed instance for Backup',
        displayName: 'Failed Backup Instance',
        type: 'custom.googleapis.com/firestore/verify_failedbackup_instance',
        metricKind: 'GAUGE',
        valueType: 'DOUBLE',
        unit: '{Count}',
        labels: [
          {
            key: 'failedbackup_instance',
            valueType: 'STRING',
            description: 'Failed backup instance',
          }]
        }
    })
    //.onCall(1)
    .returns([{
      name:`projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/verify_failedbackup_instance`,
      displayName:"mock_displayName",
      description:"mock_description",
      type:"mock_type",
      metricKind:"mock_metricKind",
      valueType:"mock_valueType",
      unit:"mock_unit",
      labels:[
        {
          key:"mock_key",
          valueType:"mock_valueType",
          description:"mock_description"
        }
      ]
    }]);

    stub_createMetricDescriptor
    .withArgs({
      "name":`projects/${testconfig.GCLOUD_PROJECT}`,
      "metricDescriptor":{
      description: 'Failed instance for Backup',
      displayName: 'Failed Backup Instance',
      type: 'custom.googleapis.com/firestore/failedbackup_instance',
      metricKind: 'GAUGE',
      valueType: 'DOUBLE',
      unit: '{Count}',
      labels: [
        {
          key: 'failedbackup_instance',
          valueType: 'STRING',
          description: 'Failed backup instance',
        }]
      }
    })
    .returns([{
      name:`projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/failedbackup_instance`,
      displayName:"mock_displayName",
      description:"mock_description",
      type:"mock_type",
      metricKind:"mock_metricKind",
      valueType:"mock_valueType",
      unit:"mock_unit",
      labels:[
        {
          key:"mock_key",
          valueType:"mock_valueType",
          description:"mock_description"
        }
      ]
    }]);

    stub_createMetricDescriptor
    .withArgs({
      "name":`projects/${testconfig.GCLOUD_PROJECT}`,
      "metricDescriptor":{
        description: 'Susccessful instance for Backup',
        displayName: 'Susccessful Backup Instance',
        type: 'custom.googleapis.com/firestore/successbackup_instance',
        metricKind: 'GAUGE',
        valueType: 'DOUBLE',
        unit: '{Count}',
        labels: [
          {
            key: 'successfulbackup_instance',
            valueType: 'STRING',
            description: 'Susccessful backup instance'
          }]
      }
    })
    .returns([{
      name:`projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/successbackup_instance`,
      displayName:"mock_displayName",
      description:"mock_description",
      type:"mock_type",
      metricKind:"mock_metricKind",
      valueType:"mock_valueType",
      unit:"mock_unit",
      labels:[
        {
          key:"mock_key",
          valueType:"mock_valueType",
          description:"mock_description"
        }
      ]
    }]);

    stub_LogggingWriteentry = sinon.stub(Logging.prototype,"log");
    stub_LogggingWriteentry.returns({
      entry:function(){
        return "SUCCESS";
      },
      write:async function(entry){
        Promise.resolve("SUCCESS");
      }
    });

    stub_LogWriteentry = sinon.stub(Log.prototype,"entry");
    stub_LogWriteentry.returns({
      RESULT:"SUCCESS"
    });

    stub_LogWrite = sinon.stub(Log.prototype,"write");
    stub_LogWrite.resolves({
      RESULT:"SUCCESS"
    });

  });

  afterEach(function() {
    // runs once after the last test in this block
    stub_mock_listCollections.restore();
    stub_mock_exportDocuments.restore();
    stub_getstatus.restore();
    stub_getAuthClient.restore();
    stub_mock_importDocuments.restore();
    stub_createTimeSeries.restore();
    stub_collectionRef.restore();
    stub_docref.restore();
    //stub_docAdd.restore();
    stub_createMetricDescriptor.restore();

    stub_LogggingWriteentry.restore();
    stub_LogWriteentry.restore();
    stub_LogWrite.restore();
  });
  
  /*  it('check writelogstoFirestore',async()=>{
    var x = await br_app.MainBR.writelogstoFirestore({Name:"Mangesh"});
    console.log(x);
    assert.equal(x.id,'asdasdasdasd');
  });*/
  it('collection should be exist', async () => {
      var CollectionID = ["Sample"];
      const _response = await br_app.MainBR.checkCollectionIsExists(CollectionID);

      var result = _response.filter(x => x.isExist == true).length > 0 ? true : false;
      console.log("result:" + result);
      assert.equal(result, true);
  });
  it('collection should not be exist', async () => {
      var CollectionID = ["Sample222"];
      const _response = await br_app.MainBR.checkCollectionIsExists(CollectionID);
      var result = _response.filter(x => x.isExist == true).length > 0 ? true : false;
      console.log("result:" + result);
      assert.equal(result, false);
  });

  it('collection should be exist', async () => {
      var regexpression = 'Sample%DSC%TOP1';
      const _response = await br_app.MainBR.getFilteredCollection(regexpression);
      var result = _response.length == undefined ? 0 : _response.length;
      expect(result).to.be.above(0);
  });
  it('collection should not be exist', async () => {
      var regexpression = '%%%';
      const _response = await br_app.MainBR.getFilteredCollection(regexpression);
      var result = _response.length == undefined ? 0 : _response.length;
      expect(result).to.be.equals(0);
  });
  it('collection backup should be created', async function() {
      var _collectionIds = ['Sample'];
      const _response = await br_app.MainBR.createBackup(_collectionIds);
      backupResponse = _response;
      if (_response.hasOwnProperty("metadata")) {
          _inputUriPrefix = _response.metadata.outputUriPrefix;
      }
      assert(_response.hasOwnProperty("metadata"), true);
  });

  it('backup response should be get', async function() {
      const _response = await br_app.verifyByOperation.getStatus(backupResponse.name);
      console.log(_response);
      assert(_response.hasOwnProperty("metadata"), true);
  });
  it('collection backup should be restored', async function() {
    var _collectionIds = ['Sample'];
    //await sleep(12000);
    const _response = await br_app.MainBR.restoreDataBase(_collectionIds,_inputUriPrefix);
    //await sleep(5000);
    restoreResponse=_response;
    assert(_response.hasOwnProperty("metadata"),true);
  });
  it('restore response should be get', async function() {
    //await sleep(1000);
    //await new Promise(resolve => setTimeout(resolve, 10000));
    //console.log("xCxzxcCZXZX"+restoreResponse.name);
    const _response= await br_app.verifyByOperation.getStatus(restoreResponse.name);
    console.log(_response);
    assert(_response.hasOwnProperty("metadata"),true);
  });

  it('Method:writeDataforMonitoring_failedbackupinstance should be return response', async function() {
    //await sleep(1000);
    var res = await br_app.MainBR.writeDataforMonitoring_failedbackupinstance();
    console.log(res);
    expect(res[0]).to.be.empty;
  });

  it('Method:writeDataforMonitoring_successbackupinstance should be return response', async function() {
    //await sleep(1000);
    var res = await br_app.MainBR.writeDataforMonitoring_successbackupinstance();
    console.log(res);
    expect(res[0]).to.be.empty;
  });
  
  it('should be fetch document from collection', async function() {
    var res = await br_app.verifyByOperation.getDataFromCollection();
    console.log(res);
    _id=res[0]._id;
    //_id.should.be.a('string');
    var result = _id!=undefined?isNaN(_id):false;
    assert.equal(result,true);
  });
  it('should be remove document from collection', async function() {
    var res = await br_app.verifyByOperation.removeDataToCollection(_id);
    console.log(res);
    assert.equal(res,'SUCCESS');
  });

  it('Method:writeDataforMonitoring_failedbackupinstance_verifyBR should be return response', async function() {
    //await sleep(1000);
    var res = await br_app.verifyByOperation.writeDataforMonitoring_failedbackupinstance_verifyBR();
    console.log(res);
    expect(res[0]).to.be.empty;
  });

  it('Method:writeDataforMonitoring_successbackupinstance_verifyBR should be return response', async function() {
      //await sleep(1000);
      var res = await br_app.verifyByOperation.writeDataforMonitoring_successbackupinstance_verifyBR();
      console.log(res);
      expect(res[0]).to.be.empty;
  });
  // test cases

  it('should be throw exception for invalid collection', async () => {
    var event = {
      TYPE:"AUTO_BACKUP",
      OPERATION:"MAIN_BR",
      BUCKET:testconfig.BUCKET,
      COLLECTIONS:["Sample2313123"],
      FILEPATH:""
    };
    const _response = await br_app.commonBRSolution(event,null);
    var res = false;
    if(_response.message!=undefined)
    {
      count = _response.message.toString().match('^Invalid Collections:')==null?0:_response.message.toString().match('^Invalid Collections:').length;
      res = count>0?true:false;
    }
    assert.equal(res, true);
  });

  it('should be throw exception for invalid type', async () => {
    var event = {
      OPERATION:"MAIN_BR",
      BUCKET:"sbx-4367-daas03112020-backup-restore-bucket",
      COLLECTIONS:["Sample"],
      FILEPATH:""
    };
    const _response = await br_app.commonBRSolution(event,null);
    var expected_output = `INVALID TYPE`;
    assert.equal(_response.message, expected_output);
  });

  it('should be throw exception for invalid operation', async () => {
    var event = {
      TYPE:"AUTO_BACKUP",
      BUCKET:"sbx-4367-daas03112020-backup-restore-bucket",
      COLLECTIONS:["Sample"],
      FILEPATH:""
    };
    const _response = await br_app.commonBRSolution(event,null);
    var expected_output = `INVALID OPERATION`;
    assert.equal(_response.message, expected_output);
  });
  
  it('should be throw exception for invalid bucket', async () => {
    var event = {
      OPERATION:"MAIN_BR",
      TYPE:"AUTO_BACKUP",
      BUCKET:"sbx-4367-daas03112020-backup-restore-bucket",
      COLLECTIONS:["Sample"],
      FILEPATH:""
    };
    stub_mock_exportDocuments.restore();
    stub_mock_exportDocuments = sinon.stub(firestore.v1.FirestoreAdminClient.prototype, 'exportDocuments');
    stub_mock_exportDocuments.throwsException(new Error(`5 NOT_FOUND: Google Cloud Storage file does not exist: /${event.BUCKET}`));
    const _response = await br_app.commonBRSolution(event,null);
    var expected_output = `5 NOT_FOUND: Google Cloud Storage file does not exist: /${event.BUCKET}`;
    assert.equal(_response.message, expected_output);
    stub_mock_exportDocuments.restore();
  });

  it('should be execute Backup Operation successfully', async () => {
    var event = {
      TYPE:"AUTO_BACKUP",
      OPERATION:"MAIN_BR",
      BUCKET:testconfig.BUCKET,
      COLLECTIONS:["Sample"],
      FILEPATH:""
    };
    const _response = await br_app.commonBRSolution(event,null);

    var splitArray = _response.metadata.outputUriPrefix.split("/");
    FILEPATH = splitArray[splitArray.length-1];
    console.log(_response);
    assert(_response.hasOwnProperty("metadata"),true);
  });

  it('should be execute Restore Operation successfully', async () => {
    var event = {
      TYPE:"AUTO_RESTORE",
      OPERATION:"MAIN_BR",
      BUCKET:testconfig.BUCKET,
      COLLECTIONS:["Sample"],
      FILEPATH:FILEPATH
    };
    const _response = await br_app.commonBRSolution(event,null);
    console.log(_response);
    assert(_response.hasOwnProperty("metadata"),true);
  });

  it('should be execute Backup Operation successfully', async () => {
    var event = {
      TYPE:"AUTO_BACKUP",
      OPERATION:"MAIN_BR",
      BUCKET:testconfig.BUCKET,
      FILTER : "^Sample",
      FILEPATH:""
    };
    const _response = await br_app.commonBRSolution(event,null);

    var splitArray = _response.metadata.outputUriPrefix.split("/");
    FILEPATH = splitArray[splitArray.length-1];
    console.log(_response);
    assert(_response.hasOwnProperty("metadata"),true);
  });

  it('should not be execute Restore Operation successfully:Wrong Filepath', async () => {
    var event = {
      TYPE:"AUTO_RESTORE",
      OPERATION:"MAIN_BR",
      BUCKET:testconfig.BUCKET,
      COLLECTIONS:["Sample"],
      FILEPATH:"wrongpath"
    };
    stub_mock_importDocuments.restore();
    stub_mock_importDocuments = sinon.stub(firestore.v1.FirestoreAdminClient.prototype, 'importDocuments');
    stub_mock_importDocuments
    //.withArgs(event,null)
    .withArgs({name:`projects/${process.env.GCLOUD_PROJECT}/databases/(default)`,collectionIds:['Sample'],inputUriPrefix:`gs://${testconfig.BUCKET}/wrongpath`})
    .throwsException(new Error(`5 NOT_FOUND: Google Cloud Storage file does not exist: /${event.BUCKET}`));


    const _response = await br_app.commonBRSolution(event,null);
    console.log(_response);
    var res = false;
    if(_response.message!=undefined)
    {
      count = _response.message.toString().match('^5 NOT_FOUND: Google Cloud Storage file does not exist:')==null?0:_response.message.toString().match('^5 NOT_FOUND: Google Cloud Storage file does not exist:').length;
      res = count>0?true:false;
    }
    assert.equal(res, true);
    stub_mock_importDocuments.restore();
  });

  it('should be execute Restore Operation successfully', async () => {
    var event = {
      TYPE:"AUTO_RESTORE",
      OPERATION:"MAIN_BR",
      BUCKET:testconfig.BUCKET,
      COLLECTIONS:["Sample"],
      FILEPATH:FILEPATH
    };
    const _response = await br_app.commonBRSolution(event,null);
    console.log(_response);
    assert(_response.hasOwnProperty("metadata"),true);
  });

  /************************ */
  it('Method:createMetricDescriptor_verify_successbackupinstance should be return response', async function() {
    //await sleep(1000);
    var res = await br_app.MetricDescriptor.createMetricDescriptor_verify_successbackupinstance();
    console.log(res);
    var expectedOutput = `projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/verify_successbackup_instance`;
    assert.equal(res.name,expectedOutput);
  });

  it('Method:createMetricDescriptor_verify_failedbackupinstance should be return response', async function() {
      //await sleep(1000);
      var res = await br_app.MetricDescriptor.createMetricDescriptor_verify_failedbackupinstance();
      console.log(res);
      //expect(res[0]).to.be.empty;
      var expectedOutput = `projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/verify_failedbackup_instance`;
      assert.equal(res.name,expectedOutput);
  });

  it('Method:createMetricDescriptor_central_BR_failedbackupinstance should be return response', async function() {
    //await sleep(1000);
    var res = await br_app.MetricDescriptor.createMetricDescriptor_central_BR_failedbackupinstance();
    console.log(res);
    //expect(res[0]).to.be.empty;
    var expectedOutput = `projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/failedbackup_instance`;
    assert.equal(res.name,expectedOutput);
  });

  it('Method:createMetricDescriptor_central_BR_successbackupinstance should be return response', async function() {
      //await sleep(1000);
      var res = await br_app.MetricDescriptor.createMetricDescriptor_central_BR_successbackupinstance();
      console.log(res);
      var expectedOutput = `projects/${process.env.GCLOUD_PROJECT}/metricDescriptors/custom.googleapis.com/firestore/successbackup_instance`;
      assert.equal(res.name,expectedOutput);
  });

  it('should be execute Restore Operation successfully', async () => {
    var event = {
      OPERATION:"METRIC"
    };
    const _response = await br_app.commonBRSolution(event,null);
    console.log(_response);
    assert(_response.findIndex(x=>x==false),-1);
  });

  it('test loggedData:SUCCESS', async () => {
    var _date = new Date();
    var response={
      metadata:{
        progressDocuments:{
          completedWork:34234
        },
        progressBytes:{
          completedWork:324234
        },
        startTime:_date,
        endTime:_date.setSeconds(50),
      }
    };
    var logObj={
      OPERATION:"MOCK_AUTO_BACKUP",
      BUCKET:"MOCK_BUCKET",
      FILENAME:"MOCK_FILENAME",
      COLLECTIONS:"MOCK_COLLECTIONS",
      OPERATIONLOGPATH:"MOCK_OPERATIONLOGPATH",
      RequestedForEmail:"MOCK_RequestedForEmail",
      BuildId:"MOCK_BuildId",
      BuildNumber:"MOCK_BuildNumber"
    };
    var Result="SUCCESS";
    const _response = await br_app.verifyByOperation.loggedData(response,logObj,Result);
    console.log(_response);
    assert((_response==undefined?true:false),true);
  });

  it('test loggedData:CANCELLED', async () => {
    var _date = new Date();
    var response={
      metadata:{
        progressDocuments:{
          completedWork:34234
        },
        progressBytes:{
          completedWork:324234
        },
        startTime:_date,
        endTime:_date.setSeconds(50),
      },
      error:{
        message:"ERROR"
      }
    };
    var logObj={
      OPERATION:"MOCK_AUTO_BACKUP",
      BUCKET:"MOCK_BUCKET",
      FILENAME:"MOCK_FILENAME",
      COLLECTIONS:"MOCK_COLLECTIONS",
      OPERATIONLOGPATH:"MOCK_OPERATIONLOGPATH",
      RequestedForEmail:"MOCK_RequestedForEmail",
      BuildId:"MOCK_BuildId",
      BuildNumber:"MOCK_BuildNumber"
    };
    var Result="CANCELLED";
    const _response = await br_app.verifyByOperation.loggedData(response,logObj,Result);
    console.log(_response);
    assert((_response==undefined?true:false),true);
  });

  it('test loggedData:FAILED', async () => {
    var _date = new Date();
    var response={
      metadata:{
        progressDocuments:{
          completedWork:34234
        },
        progressBytes:{
          completedWork:324234
        },
        startTime:_date,
        endTime:_date.setSeconds(50),
      },
      error:{
        message:"ERROR"
      }
    };
    var logObj={
      OPERATION:"MOCK_AUTO_BACKUP",
      BUCKET:"MOCK_BUCKET",
      FILENAME:"MOCK_FILENAME",
      COLLECTIONS:"MOCK_COLLECTIONS",
      OPERATIONLOGPATH:"MOCK_OPERATIONLOGPATH",
      RequestedForEmail:"MOCK_RequestedForEmail",
      BuildId:"MOCK_BuildId",
      BuildNumber:"MOCK_BuildNumber"
    };
    var Result="FAILED";
    const _response = await br_app.verifyByOperation.loggedData(response,logObj,Result);
    console.log(_response);
    assert((_response==undefined?true:false),true);
  });

  it('test loggedData:ERROR', async () => {
    var _date = new Date();
    var response={
      metadata:{
        progressDocuments:{
          completedWork:34234
        },
        progressBytes:{
          completedWork:324234
        },
        startTime:_date,
        endTime:_date.setSeconds(50),
      },
      error:{
        message:"ERROR",
        code:999
      }
    };
    var logObj={
      OPERATION:"MOCK_AUTO_BACKUP",
      BUCKET:"MOCK_BUCKET",
      FILENAME:"MOCK_FILENAME",
      COLLECTIONS:"MOCK_COLLECTIONS",
      OPERATIONLOGPATH:"MOCK_OPERATIONLOGPATH",
      RequestedForEmail:"MOCK_RequestedForEmail",
      BuildId:"MOCK_BuildId",
      BuildNumber:"MOCK_BuildNumber"
    };
    var Result="ERROR";
    const _response = await br_app.verifyByOperation.loggedData(response,logObj,Result);
    console.log(_response);
    assert((_response==undefined?true:false),true);
  });

  it('should be check verify successfully', async () => {
    var event = {
      OPERATION:"VERIFY_BR"
    };
    const _response = await br_app.commonBRSolution(event,null);
    console.log(_response);
    assert(_response,"SUCCESS");
  });
});