//index-commonBRSolution_V2.js
//backup restore = Main + verify = common
const firestore = require('@google-cloud/firestore');
const client = new firestore.v1.FirestoreAdminClient();

const {Logging} = require('@google-cloud/logging');
const monitoring = require('@google-cloud/monitoring');  // for metric
const grpc = require('@grpc/grpc-js');
/** start : verify function param */

//const firestore = require('@google-cloud/firestore');  //common
//const {Logging} = require('@google-cloud/logging');   //common
//const { Firestore } = require('@google-cloud/firestore');
//const GCLOUD_PROJECT= process.env.GCLOUD_PROJECT;     //common

const GCLOUD_PROJECT= process.env.GCLOUD_PROJECT;

const {google} = require('googleapis');
const {GoogleAuth} = require('google-auth-library');
const collectionName = "BackupRestoreLogs";

/** stop : verify function param*/
//var TYPE = "",BUCKET = "",FILEPATH = "", OPERATION = "",COLLECTIONS = [];

global.TYPE = "",global.BUCKET = "",global.FILEPATH = "", global.OPERATION = "",global.COLLECTIONS = [];
global.GCLOUD_PROJECT="";
/*
/*
var event ={
    OPERATION:"MAIN_BR",
    TYPE:"AUTO_RESTORE",
    BUCKET:"sbx-4367-daas03112020-backup-restore-bucket",
    //COLLECTIONS:[],
    FILEPATH:"",
    FILTER:"^Test%DSC"
};*/
/*
var event ={
    OPERATION:"VERIFY_BR"
} */
/*
"^Test%DSC%TOP 5"
<Regular expression>%<ASC/DSC>%<TOP N>
*/
exports.commonBRSolution = async(event, context) => {
//var commonBRSolution = async() => {
    try {
        if(event.data==undefined)
        {
            OPERATION = event.OPERATION;
            TYPE = event.TYPE;
            BUCKET = event.BUCKET;
            COLLECTIONS = (event.COLLECTIONS!=undefined)?event.COLLECTIONS:null;
            FILEPATH = event.FILEPATH;
            _FILTER = (event.FILTER!=undefined)?event.FILTER:"";
            RequestedForEmail = (event.RequestedForEmail!=undefined)?event.RequestedForEmail:"SCHEDULED";
            BuildId = (event.BuildId !=undefined)?event.BuildId :"SCHEDULED";
            BuildNumber = (event.BuildNumber !=undefined)?event.BuildNumber :"SCHEDULED";
        }
        else
        {
            const pubsubMessage = event.data;
            var _data = (Buffer.from(pubsubMessage, 'base64').toString());
            var param = JSON.parse(_data);
            OPERATION = param.OPERATION;
            TYPE = param.TYPE;
            BUCKET = param.BUCKET;
            COLLECTIONS = (param.COLLECTIONS!=undefined)?param.COLLECTIONS:null;
            FILEPATH = param.FILEPATH;
            _FILTER = (param.FILTER!=undefined)?param.FILTER:"";
            RequestedForEmail = (param.RequestedForEmail!=undefined)?param.RequestedForEmail:"SCHEDULED";
            BuildId = (param.BuildId !=undefined)?param.BuildId :"SCHEDULED";
            BuildNumber = (param.BuildNumber !=undefined)?param.BuildNumber :"SCHEDULED";
        }
        


        if(OPERATION == "MAIN_BR"){
            if(COLLECTIONS==null && _FILTER=="")
            {
                throw new Error("Atleast one parameter required from COLLECTIONS or FILTER.");
            }

            if(COLLECTIONS==null)
            {
                var filter_collection = await getFilteredCollection(_FILTER);
                if(filter_collection!=undefined)
                {
                    COLLECTIONS=[];
                    for (let index = 0; index < filter_collection.length; index++) {
                        const element = filter_collection[index];
                        COLLECTIONS.push(element);
                    }
                    COLLECTIONS = COLLECTIONS.unique();
                }
            }
            else if(COLLECTIONS.length!=0)
            {
                var filter_collection = await getFilteredCollection(_FILTER);
                if(filter_collection!=undefined)
                {
                    for (let index = 0; index < filter_collection.length; index++) {
                        const element = filter_collection[index];
                        COLLECTIONS.push(element);
                    }
                }
                COLLECTIONS = COLLECTIONS.unique();
            }
            else
            {

            }
            
            
            var res = await centralBR(TYPE,BUCKET,COLLECTIONS,FILEPATH,RequestedForEmail,BuildId,BuildNumber);
            console.log(res);
            return res;
            if(res.name=='Error')
            {
                throw res;
            }
        }
        else if(OPERATION == "VERIFY_BR"){
            var res = await verifyBR();
            console.log(res);
            return res;
        }
        else if(OPERATION == "METRIC"){
            var res =await createMetricDescriptor();
            console.log(res);
            return res;
        }
        else
        {
            throw new Error("INVALID OPERATION");
        }
            
    } catch (error) {
         return error;   
    }
}

/********************START : Central BR***********************************/
//#region "Central BR"

module.exports.MainBR={
    TYPE:TYPE,
    BUCKET :BUCKET,
    FILEPATH : FILEPATH, 
    OPERATION:OPERATION,
    COLLECTIONS : COLLECTIONS,
    GCLOUD_PROJECT : GCLOUD_PROJECT,
    centralBR : centralBR,
    checkCollectionIsExists : checkCollectionIsExists,
    getFilteredCollection : getFilteredCollection,
    getLatestCollection : getLatestCollection,
    logData : logData,
    createBackup : createBackup,
    restoreDataBase : restoreDataBase,
    customeLogging : customeLogging,
    writeDataforMonitoring_failedbackupinstance : writeDataforMonitoring_failedbackupinstance,
    writeDataforMonitoring_successbackupinstance : writeDataforMonitoring_successbackupinstance,
    writeDataForMonitoring : writeDataForMonitoring,
    writelogstoFirestore : writelogstoFirestore
};
/*
module.exports.MainBR={
    centralBR : centralBR(TYPE,BUCKET,COLLECTIONS,FILEPATH,RequestedForEmail = "",BuildId = "",BuildNumber = ""),
    checkCollectionIsExists : checkCollectionIsExists(collections),
    getFilteredCollection : getFilteredCollection(_filter),
    getLatestCollection : getLatestCollection(regExpression),
    logData : logData(bucket,fileName,collections,startTime,endTime,operationType,operationalLogPath,RESULT,ErrorMessage,code,RequestedForEmail,BuildId,BuildNumber),
    createBackup : createBackup(_collectionIds),
    restoreDataBase : restoreDataBase(_collectionIds,_inputUriPrefix),
    customeLogging : customeLogging(Log,_logName),
    writeDataforMonitoring_failedbackupinstance : writeDataforMonitoring_failedbackupinstance(),
    writeDataforMonitoring_successbackupinstance : writeDataforMonitoring_successbackupinstance(),
    writeDataForMonitoring : writeDataForMonitoring(projectId,metricid,metric_request,metric_Data),
    writelogstoFirestore : writelogstoFirestore(logData)
};*/

async function centralBR(TYPE,BUCKET,COLLECTIONS,FILEPATH,RequestedForEmail = "",BuildId = "",BuildNumber = ""){
//module.exports.centralBR = async function (TYPE,BUCKET,COLLECTIONS,FILEPATH,RequestedForEmail = "",BuildId = "",BuildNumber = ""){
    var collections=[];
    try {
        if(TYPE == "AUTO_BACKUP" || TYPE == "ADHOC_BACKUP")
        {
            /**********************START : CREATE BACKUP****************************** */
            // colectionId array
            //var collections = ['TestDataCSV1'];
            //var collections = COLLECTIONS;
            if(COLLECTIONS.length!=0)
            {
                var collectionInfo = await checkCollectionIsExists(COLLECTIONS);
                collections = COLLECTIONS;
                var validCollections = collectionInfo.filter(x=>x.isExist==true);
                var invalidCollections = collectionInfo.filter(x=>x.isExist==false);
                if(invalidCollections.length>0)
                {
                    console.error("Invalid Collections:"+JSON.stringify(invalidCollections));
                    await logData(BUCKET,FILEPATH,collections,new Date().toUTCString(),new Date().toUTCString(),TYPE,"","ERROR","Please Enter Valid Collection(s).",0,RequestedForEmail,BuildId,BuildNumber);
                    throw new Error("Invalid Collections:"+JSON.stringify(invalidCollections));
                }
            }
            else
            {
                collections = COLLECTIONS;
            }
            var s_date = new Date().getTime();
            var bkp_response = await createBackup(collections); 
            var e_date = new Date().getTime();

            var seconds = (e_date - s_date) / 1000;
            console.log(seconds);
            console.log(bkp_response);
            if(bkp_response.name!="Error")
            {
                var startTime = new Date(bkp_response.metadata.startTime.seconds*1000).toUTCString();
                var Backup_location = bkp_response.metadata.outputUriPrefix;
                var filename = Backup_location.substring(Backup_location.lastIndexOf('/')+1,Backup_location.length);
                await logData(BUCKET,filename,collections,startTime,new Date().toUTCString(),TYPE,bkp_response.name,"SUCCESS","","",RequestedForEmail,BuildId,BuildNumber);
                return bkp_response;
            }
            else
            {
                //var filename = Backup_location.substring(Backup_location.lastIndexOf('/')+1,Backup_location.length);
                await logData(BUCKET,FILEPATH,collections,new Date().toUTCString(),new Date().toUTCString(),TYPE,bkp_response.name,"ERROR",bkp_response.message,bkp_response.code,RequestedForEmail,BuildId,BuildNumber);
                throw bkp_response;
            }

            
            /************************STOP : CREATE BACKUP**************************** */
        }
        else if(TYPE == "AUTO_RESTORE" || TYPE == "ADHOC_RESTORE")
        {
            /**********************START :  RESTORE ****************************** */
            //outputUriPrefix"gs://4367-test-cs-bucket/2020-03-09T11:20:22_95992"
            //var filepath = '2020-03-09T11:20:22_95992';
            //var inputUriPrefix = 'gs://'+bucket +'/'+ filepath;
            if(FILEPATH==undefined || FILEPATH==''){
                throw new Error("FILEPATH is mandatory for RESTORE Operation.");
            }
            var filepath =FILEPATH;
            var inputUriPrefix = 'gs://'+BUCKET +'/'+ filepath;
            var collections = COLLECTIONS;
            var restore_response = await restoreDataBase(collections,inputUriPrefix);
            console.log(restore_response);  
            if(restore_response.name!="Error")
            {
                var startTime = new Date(restore_response.metadata.startTime.seconds*1000).toUTCString();
                var Backup_location = restore_response.metadata.inputUriPrefix;
                var filename = Backup_location.substring(Backup_location.lastIndexOf('/')+1,Backup_location.length);
                await logData(BUCKET,filename,collections,startTime,new Date().toUTCString(),TYPE,restore_response.name,"SUCCESS",RequestedForEmail,BuildId,BuildNumber);
                return restore_response;
            }
            else
            {
                //var filename = Backup_location.substring(Backup_location.lastIndexOf('/')+1,Backup_location.length);
                await logData(BUCKET,FILEPATH,collections,new Date().toUTCString(),new Date().toUTCString(),TYPE,restore_response.name,"ERROR",restore_response.message,restore_response.code,RequestedForEmail,BuildId,BuildNumber);
                throw restore_response;
            }
            //console.log(restore_response);
            /**********************STOP : RESTORE ****************************** */
        }
        else
        {
            if(TYPE != "AUTO_RESTORE" && TYPE != "ADHOC_RESTORE" && TYPE != "AUTO_BACKUP" && TYPE != "ADHOC_BACKUP"){
                await logData(BUCKET,FILEPATH,collections,new Date().toUTCString(),new Date().toUTCString(),TYPE,"","ERROR","TYPE is Invalid",0,RequestedForEmail,BuildId,BuildNumber);
                throw new Error("INVALID TYPE");
            }
        }
            
    } catch (error) {
        var res = await logData(BUCKET,filename,collections,new Date().toUTCString(),new Date().toUTCString(),TYPE,error.name,"ERROR",error.message,error.code,RequestedForEmail,BuildId,BuildNumber);  
        return error;
    }
}

Array.prototype.unique = function() {
    let arr = [];
    for(let i = 0; i < this.length; i++) {
        if(!arr.includes(this[i])) {
            arr.push(this[i]);
        }
    }
    return arr; 
}

async function checkCollectionIsExists(collections)
//module.exports.checkCollectionIsExists  = async function (collections)
{
    var collectionsInfo=[];
    if(collections.length!=0){
        let _firestore = new firestore.Firestore();
        
        let collectionRef1 = await _firestore.listCollections();
        for(i=0;i<collections.length;i++)
        {
            var result = collectionRef1.find(x=>x.id==collections[i]);

            var obj={
                collectionName : collections[i],
                isExist:((result==undefined)?false:true)
            };
            collectionsInfo.push(obj);
        }
        console.log();
        return collectionsInfo;
    }
}

async function getFilteredCollection(_filter)
//module.exports.getFilteredCollection = async function(_filter)
{
    try 
    {
        var _list=[];
        var filter = _filter.split("%");
        if(filter.length>0)
        {
            if(filter[0]!=undefined)
            {
                regexpression = filter[0];
                if(regexpression!="")
                {
                    _list =  await getLatestCollection(regexpression);
                }
            }
            if(_list.length>0)
            {
                if(filter[1]!=undefined)
                {
                    if(filter[1]=="DSC")
                    {
                        _list = _list.sort().reverse();
                    }   
                    else
                    {
                    _list = _list.sort();
                    }
                }
            }
            else
            {
                _list = _list.sort();
            }
            if(filter[2]!=undefined)
            {
                const searchRegExp = / /gi;
                var N = parseInt(filter[2].replace(searchRegExp,'').substring(3,5));
                if(isNaN(N))
                {
                _list=_list.slice(0,N);
                }
            }
        }
    } 
    catch (error) {
       throw error; 
    }
    finally
    {
      return _list;
    }
}

async function getLatestCollection(regExpression){
//module.exports.getLatestCollection = async function(regExpression){
    return new Promise(async(resolve,reject)=>{
        try
        {
            var _firestore = new firestore.Firestore();
            //var s = await (await firestore.listCollections()).filter(x=>x.id.startsWith(collectionPrefix)).sort(compareValues("id",'desc'));
            var collections = await _firestore.listCollections();
            var s = collections.filter(x=>new RegExp(regExpression, 'g').test(x.id)).map(x=>x.id)
            if(s.length>0)
            {
                resolve(s);
            }
            else
            {
                resolve(undefined);
            }
        }
        catch(ex){
            reject(ex);
        }
    });
}

//module.exports.logData = async function (bucket,fileName,collections,startTime,endTime,operationType,operationalLogPath,RESULT,ErrorMessage,code,RequestedForEmail,BuildId,BuildNumber){
async function logData(bucket,fileName,collections,startTime,endTime,operationType,operationalLogPath,RESULT,ErrorMessage,code,RequestedForEmail,BuildId,BuildNumber){
    try {

        var logData ={
            "OPERATION":operationType,
            "BUCKET":bucket,
            "FILENAME":fileName,
            "COLLECTIONS":collections,
            "STARTTIME":startTime,
            "ENDTIME":endTime,
            "OPERATIONLOGPATH":operationalLogPath,
            "RESULT":RESULT,
            "RequestedForEmail":RequestedForEmail==undefined?"":RequestedForEmail,
            "BuildId":BuildId==undefined?"":BuildId,
            "BuildNumber":BuildNumber==undefined?"":BuildNumber
        };

        
        if(RESULT=="SUCCESS")
        {
            await writeDataforMonitoring_successbackupinstance();
            //await new Promise(r => setTimeout(r, 20000));
            //logData.BACKUPSIZE = await getStorageFolderSize(bucket,fileName);
            //logData.EXECUTIONTIME = (new Date(endTime)-new Date(startTime))/1000;

            await writelogstoFirestore(logData);//passing the logData paraments to this function
        }
        else
        {
            await writeDataforMonitoring_failedbackupinstance();
            logData.Code = code;
            logData.ErrorMessage = ErrorMessage;
        }

        if(operationType=="AUTO_RESTORE" || operationType=="ADHOC_RESTORE")
        {
            //var collectionInfo = await getDocumentCount(collections);
            //logData.DocumentCount = JSON.stringify(collectionInfo);
        }
        
        await customeLogging(logData,"MainBR");
        console.log(logData);
        if(logData.RESULT=="ERROR")
        {
            console.error(logData);
            throw new Error(JSON.stringify(logData));
        }
            
    } catch (error) {
        //console.error(error);
        //throw error;
    }
}

async function createBackup(_collectionIds){
//module.exports.createBackup =  async function (_collectionIds){
    const bucketpath = 'gs://'+BUCKET;
    const databaseName = client.databasePath(
        GCLOUD_PROJECT,
        '(default)'
    );
    var res = undefined;
    try {
        var d = await client
        .exportDocuments({
            name: databaseName,
            outputUriPrefix: bucketpath,
            // Leave collectionIds empty to export all collections
            // or define a list of collection IDs:
            // collectionIds: ['users', 'posts']
            collectionIds: _collectionIds,
        })
        .then(async(responses) => {
            const response = responses[0];
            console.log(`Operation Name: ${response['name']}`);
            res = response;
        })
        
    } catch (error) {
        res = error;
    }
    finally{
        return res;
    }
}

async function restoreDataBase(_collectionIds,_inputUriPrefix){
//module.exports.restoreDataBase = async function (_collectionIds,_inputUriPrefix){
    //outputUriPrefix"gs://4367-test-cs-bucket/2020-03-09T11:20:22_95992"
    const databaseName = client.databasePath(
        GCLOUD_PROJECT,
        '(default)'
    );
    var res;
    try {
        var d = await client
        .importDocuments(
            {
                name : databaseName,
                collectionIds : _collectionIds,
                inputUriPrefix :_inputUriPrefix
            }
        )
        .then(async(responses) => {
            const response = responses[0];
            console.log(`Operation Name: ${response['name']}`);
            res = response;
        }) 
    } catch (error) {
        res = error;
    }
    finally{
        return res;
    }
}
//common
/*
async function getFilteredCollection(regExpression){
    return new Promise(async(resolve,reject)=>{
        try{
            var _firestore = new firestore.Firestore();
            
            var collections = await _firestore.listCollections();
            var s = collections.filter(x=>new RegExp(regExpression, 'g').test(x.id)).map(x=>x.id)
            if(s.length>1)
            {
                resolve(s);
            }
            else
            {
                resolve(undefined);
            }
        }
        catch(ex){
            reject(ex);
        }
    });
}*/

async function customeLogging(Log,_logName){
//module.exports.customeLogging =    async function (Log,_logName){
    projectId =GCLOUD_PROJECT;
    logName=_logName;

    // Creates a client
    const logging = new Logging({
        projectId:GCLOUD_PROJECT,
        grpc:grpc
    });

    // Selects the log to write to
    const log = logging.log(logName);

    // The data to write to the log
    const text = JSON.stringify(Log);

    // The metadata associated with the entry
    const metadata = {
        resource: {type: 'global'},
        // See: https://cloud.google.com/logging/docs/reference/v2/rest/v2/LogEntry#logseverity
        severity: 'INFO',
    };

    // Prepares a log entry
    const entry = log.entry(metadata, text);

    var res = await log.write(entry);
    console.log(`Logged: ${text}`);
}

async function writeDataforMonitoring_failedbackupinstance(){
//module.exports.writeDataforMonitoring_failedbackupinstance = async function (){
    return new Promise(async(resolve,reject)=>{
        try {
            
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });

            //throw new Error("sample error");
            //const projectId = 'sbx-4367-daasnosqlsbx-eeb5219c';
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/failedbackup_instance";

            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor: {
                description: 'Failed instance for Backup',
                displayName: 'Failed Backup Instance',
                type: metricid,
                metricKind: 'GAUGE',
                valueType: 'DOUBLE',
                unit: '{Count}',
                labels: [
                    {
                    key: 'failedbackup_instance',
                    valueType: 'STRING',
                    description: 'Failed backup instance',
                    },
                ],
                },
            };

            const dataPoint = {
                interval: {
                    endTime: {
                    seconds: Date.now() / 1000,
                    },
                },
                value: {
                    doubleValue: 1,
                },
            };

            const timeSeriesData = {
            metric: {
                type: metricid,
                labels: {
                    failedbackup_instance: 'Failed backup instance',
                },
            },
            resource: {
                type: 'global',
                labels: {
                    project_id: projectId,
                },
            },
            points: [dataPoint],
            };

            const metric_Data = {
                name: client.projectPath(projectId),
                timeSeries: [timeSeriesData],
            };

            var result = await writeDataForMonitoring(projectId,metricid,metric_request,metric_Data);
            resolve(result);
                    
        } catch (error) {
            reject(error); 
        }
    });
}

async function writeDataforMonitoring_successbackupinstance(){
//module.exports.writeDataforMonitoring_successbackupinstance = async function (){
    return new Promise(async(resolve,reject)=>{
        try {
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });
            //const projectId = 'sbx-4367-daasnosqlsbx-eeb5219c';
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/successbackup_instance";
            
            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor:  {
                    description: 'Susccessful instance for Backup',
                    displayName: 'Susccessful Backup Instance',
                    type: metricid,
                    metricKind: 'GAUGE',
                    valueType: 'DOUBLE',
                    unit: '{Count}',
                    labels: [
                    {
                        key: 'successfulbackup_instance',
                        valueType: 'STRING',
                        description: 'Susccessful backup instance',
                    },
                    ],
                },
                };

            const dataPoint = {
                interval: {
                    endTime: {
                    seconds: Date.now() / 1000,
                    },
                },
                value: {
                    doubleValue: 1,
                },
            };

            const timeSeriesData = {
            metric: {
                type: metricid,
                labels: {
                    successfulbackup_instance: 'Successful backup instance'
                },
            },
            resource: {
                type: 'global',
                labels: {
                    project_id: projectId,
                },
            },
            points: [dataPoint],
            };

            const metric_Data = {
                name: client.projectPath(projectId),
                timeSeries: [timeSeriesData],
            };

            var res = await writeDataForMonitoring(projectId,metricid,metric_request,metric_Data);
            resolve(res);
        } catch (error) {
            reject(error);
        }
    });
}

//common
async function writeDataForMonitoring(projectId,metricid,metric_request,metric_Data){
//module.exports.writeDataForMonitoring =async function (projectId,metricid,metric_request,metric_Data){
    return new Promise(async(resolve,reject)=>{
        try {
            // Imports the Google Cloud client library
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });

            /*
            var res = await getMetricDescriptor(projectId,metricid);
            if(res==undefined)
            {
                await createMetricForMonitoring(projectId,metricid,metric_request);
            }
            */
            // Writes time series data
            const result = await client.createTimeSeries(metric_Data);
            console.log(`Done writing time series data.`, result);
            resolve(result);
        }
        catch(error)
        {
            reject(error);
        }
    }); 
}

//Adds the Log Data information from the logData Function
async function writelogstoFirestore(logData) {
//module.exports.writelogstoFirestore = async function (logData) {
    return new Promise(async(resolve,reject)=>{
        let _firestore = new firestore.Firestore();
        let addDoc ="";
        try {
            addDoc =await _firestore.collection('BackupRestoreLogs').add(logData);
            console.log('Logs added to Firestore collection with ID: ', addDoc.id);
            resolve(addDoc);
        } catch (error) {
            reject(error);
        }
    });
}

//#endregion
/********************STOP : Central BR***********************************/
/**==============================================================================================================================**/
/********************START : Verify BR***********************************/
//#region "Verify BR"
/*
module.exports.verifyByOperation={
    verifyBR : verifyBR(),
    removeDataToCollection : removeDataToCollection(),
    getDataFromCollection : getDataFromCollection(),
    getStatus : getStatus(name),
    authorize:authorize(),
    loggedData : loggedData(response,logObj,Result),
    writeDataforMonitoring_successbackupinstance_verifyBR : writeDataforMonitoring_successbackupinstance_verifyBR(),
    writeDataforMonitoring_failedbackupinstance_verifyBR : writeDataforMonitoring_failedbackupinstance_verifyBR()
};*/

module.exports.verifyByOperation={
    verifyBR : verifyBR,
    removeDataToCollection : removeDataToCollection,
    getDataFromCollection : getDataFromCollection,
    getStatus : getStatus,
    authorize:authorize,
    loggedData : loggedData,
    writeDataforMonitoring_successbackupinstance_verifyBR : writeDataforMonitoring_successbackupinstance_verifyBR,
    writeDataforMonitoring_failedbackupinstance_verifyBR : writeDataforMonitoring_failedbackupinstance_verifyBR
};

async function verifyBR(){
//module.exports.verifyBR =  async function(){
    try {
        var listDocuments = await getDataFromCollection();
        console.log(listDocuments);
        for(i=0;i<listDocuments.length;i++)
        {
            var logdataObj = listDocuments[i];

            if(logdataObj.OPERATIONLOGPATH==="")
            {
                continue;
            }
            var statusResponse  = await getStatus(logdataObj.OPERATIONLOGPATH);

            //var foldersize = await getStorageFolderSize(logdata.BUCKET,logdata.FILENAME);
            console.log(statusResponse);
            if(statusResponse.metadata.operationState==="SUCCESSFUL"){
                // add data to logs
                await loggedData(statusResponse,logdataObj,"SUCCESS");    
                
                //remove data from collection
                await removeDataToCollection(logdataObj._id);
            }
            else
            if(statusResponse.metadata.operationState==="CANCELLED" || statusResponse.metadata.operationState==="CANCELLING" || statusResponse.metadata.operationState==="FAILED")
            {
                // add data to logs
                await loggedData(statusResponse,logdataObj,statusResponse.metadata.operationState);    
                
                //remove data from collection
                await removeDataToCollection(logdataObj._id);
            }
            else
            {
                if(statusResponse.errors!=undefined)
                {
                    if(statusResponse.errors.length>0)
                    {
                        console.error("Method : verifyfunction : "+statusResponse);
                        await loggedData(statusResponse,logdataObj,"ERROR"); 
                    }
                    await removeDataToCollection(logdataObj._id);
                }
                /*
                else
                {
                    console.error("Method : verifyfunction : "+statusResponse);
                    await loggedData(statusResponse,logdataObj,statusResponse.operationState); 

                    await removeDataToCollection(logdataObj._id);
                }*/
            }
        }
        return "SUCCESS";  
    } catch (error) {
         return error;   
    }
}

async function removeDataToCollection(id){
//module.exports.removeDataToCollection = async function(id){
    return new Promise(async(Resolve,Reject)=>{
        //let _firestore = new firestore();
        let _firestore = new firestore.Firestore({
            //projectId:'sbx-4367-daasnosqlsbx-eeb5219c'
            projectId:GCLOUD_PROJECT
        });
        var docref = collectionName+'/'+id;
        let documentRef =await _firestore.doc(docref);
        await documentRef.delete().then(() => {
            console.log('Document successfully deleted.');
            Resolve("SUCCESS");
        }).
        catch((error)=>{
            Reject(error);
        });
    });
}

async function getDataFromCollection(){
//module.exports.getDataFromCollection = async function(){
    var itemData = [];
    return new Promise(async(Resolve,Reject)=>{
        try
        {
            let _firestore = new firestore.Firestore({
                //projectId:'sbx-4367-daasnosqlsbx-eeb5219c'
                projectId:GCLOUD_PROJECT
            });
    
            let collectionRef =await  _firestore.collection(collectionName);
            let doclist =await collectionRef.listDocuments();

            console.log("Log Collection Documents : "+doclist.length);
            for (i = 0; i < doclist.length; i++) {
                var path = doclist[i].path;
                let documentRef = _firestore.doc(path);
                var ds1 = await documentRef.get();
                if(ds1!=undefined)
                {
                    var dataobj = ds1.data();
                    dataobj._id=doclist[i].id;
                    itemData.push(dataobj);
                }
            }
            Resolve(itemData);
        }
        catch(error)
        {
            Reject(error);
        }
    });
}

async function getStatus(name){
//module.exports.getStatus = async function(name){
    const firestore = google.firestore('v1');
    let message;
  
    const authClient = await authorize();
    const request = {
        // The name of the operation resource.
        name:name,
        auth: authClient
    };
    try 
    {
        var res = undefined;
        const response = (await firestore.projects.databases.operations.get(request)).data;
            //message = JSON.stringify(response, null, 2);
            // TODO: Change code below to process the `response` object:
            res = response;
        } catch (err) {
            console.error("Method : GetStatus : "+err);
            res = err;
        }
        finally
        {
            return res;
        }
}

async function authorize() {
//module.exports.authorize = async function() {
    const auth = new GoogleAuth({
      scopes: ['https://www.googleapis.com/auth/cloud-platform','https://www.googleapis.com/auth/datastore'],
      projectId:GCLOUD_PROJECT,
      grpc:grpc
    });
    return await auth.getClient();
} 

async function loggedData(response,logObj,Result)
//module.exports.loggedData =async function(response,logObj,Result)
{
    var logDataObj ={
        "Function":"VerifyBR",
        "OPERATION":logObj.OPERATION,
        "BUCKET":logObj.BUCKET,
        "FILENAME":logObj.FILENAME,
        "COLLECTIONS":logObj.COLLECTIONS,
        "OPERATIONLOGPATH":logObj.OPERATIONLOGPATH,
        "RESULT":Result,
        "RequestedForEmail":logObj.RequestedForEmail,
        "BuildId":logObj.BuildId,
        "BuildNumber":logObj.BuildNumber
    };
    if(Result == "SUCCESS")
    {
        logDataObj.DOCUMENTCOUNT = response.metadata.progressDocuments.completedWork;
        logDataObj.BACKUPSIZE = response.metadata.progressBytes.completedWork;
        logDataObj.STARTTIME = response.metadata.startTime;
        logDataObj.ENDTIME = response.metadata.endTime;
        logDataObj.EXECUTIONTIME = (new Date(response.metadata.endTime).getTime()-new Date(response.metadata.startTime).getTime())/1000;

        console.log(logDataObj);
        await new Promise(r => setTimeout(r, 15000));
        await writeDataforMonitoring_successbackupinstance_verifyBR();
    }
    if(Result=="CANCELLED" || Result == "FAILED"){
        if(Result=="CANCELLED")
        {
            if(response.error.message)
            {
                logDataObj.ErrorMessage = response.error.message;
            }
            else
            {
                logDataObj.ErrorMessage = "Operation Cancelled";
            }
        }
        if(Result == "FAILED")
        {
            if(response.error.message)
            {
                logDataObj.ErrorMessage = response.error.message;
            }
            else
            {
                logDataObj.ErrorMessage = "Operation failed";
            }
        }
        console.error(response);
        console.error(logDataObj);

        await new Promise(r => setTimeout(r, 15000));
        await writeDataforMonitoring_failedbackupinstance_verifyBR();
    }
    /*
    else
    {
        if(response.error.message)
        {
            logDataObj.ErrorMessage = response.error.message;
        }
        console.error(response);
        console.error(logDataObj);

        await writeDataforMonitoring_failedbackupinstance();
    }*/
    if(Result=="ERROR")
    {
        logDataObj.Code = response.error.code;
        logDataObj.ErrorMessage = response.error.message;
        console.error(response);

        console.error(logDataObj);

        await new Promise(r => setTimeout(r, 15000));
        await writeDataforMonitoring_failedbackupinstance_verifyBR();
    }

    await customeLogging(logDataObj,"VerifyBR");
    
    if(logDataObj.RESULT=="ERROR")
    {
        
        //console.error("Method : logData : "+logDataObj);
        //throw new Error(JSON.stringify(logDataObj));
    }
}

async function writeDataforMonitoring_successbackupinstance_verifyBR(){
//module.exports.writeDataforMonitoring_successbackupinstance_verifyBR = async function(){
    return new Promise(async(resolve,reject)=>{
        try {
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT
            });
            //const projectId = 'sbx-4367-daasnosqlsbx-eeb5219c';
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/verify_successbackup_instance";

            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor:  {
                    description: 'Successful instance for Backup',
                    displayName: 'Successful Backup Instance',
                    type: metricid,
                    metricKind: 'GAUGE',
                    valueType: 'DOUBLE',
                    unit: '{Count}',
                    labels: [
                    {
                        key: 'successfulbackup_instance',
                        valueType: 'STRING',
                        description: 'Successful backup instance',
                    },
                    ],
                },
                };

            const dataPoint = {
                interval: {
                    endTime: {
                    seconds: Date.now() / 1000,
                    },
                },
                value: {
                    doubleValue: 1,
                },
            };

            const timeSeriesData = {
            metric: {
                type: metricid,
                labels: {
                    successfulbackup_instance: 'Successful backup instance'
                },
            },
            resource: {
                type: 'global',
                labels: {
                    project_id: projectId,
                },
            },
            points: [dataPoint],
            };

            const metric_Data = {
                name: client.projectPath(projectId),
                timeSeries: [timeSeriesData],
            };

            var res = await writeDataForMonitoring(projectId,metricid,metric_request,metric_Data);
            resolve(res);
        } catch (error) {
            reject(error);
        }
    });
}

async function writeDataforMonitoring_failedbackupinstance_verifyBR(){
//module.exports.writeDataforMonitoring_failedbackupinstance_verifyBR = async function(){
    return new Promise(async(resolve,reject)=>{
        try {
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient();
            //const projectId = 'sbx-4367-daasnosqlsbx-eeb5219c';
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/verify_failedbackup_instance";

            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor: {
                description: 'Failed instance for Backup',
                displayName: 'Failed Backup Instance',
                type: metricid,
                metricKind: 'GAUGE',
                valueType: 'DOUBLE',
                unit: '{Count}',
                labels: [
                    {
                    key: 'failedbackup_instance',
                    valueType: 'STRING',
                    description: 'Failed backup instance',
                    },
                ],
                },
            };

            const dataPoint = {
                interval: {
                    endTime: {
                    seconds: Date.now() / 1000,
                    },
                },
                value: {
                    doubleValue: 1,
                },
            };

            const timeSeriesData = {
            metric: {
                type: metricid,
                labels: {
                    failedbackup_instance: 'Failed backup instance',
                },
            },
            resource: {
                type: 'global',
                labels: {
                    project_id: projectId,
                },
            },
            points: [dataPoint],
            };

            const metric_Data = {
                name: client.projectPath(projectId),
                timeSeries: [timeSeriesData],
            };

            var res = await writeDataForMonitoring(projectId,metricid,metric_request,metric_Data);
            resolve(res);
        } catch (error) {
            reject(error);
        }
    });
    
}
//#endregion
/********************STOP : Verify BR***********************************/
/**==============================================================================================================================
/********************START : Metric Descriptor***********************************/
//#region "create Metric Descriptor"

module.exports.MetricDescriptor = {
    createMetricDescriptor : createMetricDescriptor,
    createMetricDescriptor_verify_successbackupinstance : createMetricDescriptor_verify_successbackupinstance,
    createMetricDescriptor_verify_failedbackupinstance : createMetricDescriptor_verify_failedbackupinstance,
    createMetricDescriptor_central_BR_failedbackupinstance : createMetricDescriptor_central_BR_failedbackupinstance,
    createMetricDescriptor_central_BR_successbackupinstance:createMetricDescriptor_central_BR_successbackupinstance,
    createMetricForMonitoring : createMetricForMonitoring
}

async function createMetricDescriptor(){
//module.exports.createMetricDescriptor =  async function (){
    var result=[];
    var res = await createMetricDescriptor_verify_successbackupinstance();
    if(res.name!=undefined)
    {
        console.log(res.name+ " : Metric created");
        result.push(true);
    }
    else
    {
        console.error(res);
        result.push(false);
    }

    var res = await createMetricDescriptor_verify_failedbackupinstance();
    if(res.name!=undefined)
    {
        console.log(res.name+ " : Metric created");
        result.push(true);
    }
    else
    {
        console.error(res);
        result.push(false);
    }

    var res = await createMetricDescriptor_central_BR_failedbackupinstance();
    if(res.name!=undefined)
    {
        console.log(res.name+ " : Metric created");
        result.push(true);
    }
    else
    {
        console.error(res);
        result.push(false);
    }

    var res = await createMetricDescriptor_central_BR_successbackupinstance();
    if(res.name!=undefined)
    {
        console.log(res.name+ " : Metric created");
        result.push(true);
    }
    else
    {
        console.error(res);
        result.push(false);
    }
    return result;
}

async function createMetricDescriptor_verify_successbackupinstance(){
//module.exports.createMetricDescriptor_verify_successbackupinstance =async function (){
    return new Promise(async(resolve,reject)=>{
        try {
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/verify_successbackup_instance";
        
            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor:  {
                    description: 'Susccessful instance for Backup',
                    displayName: 'Susccessful Backup Instance',
                    type: metricid,
                    metricKind: 'GAUGE',
                    valueType: 'DOUBLE',
                    unit: '{Count}',
                    labels: [
                      {
                        key: 'successfulbackup_instance',
                        valueType: 'STRING',
                        description: 'Susccessful backup instance',
                      },
                    ],
                  },
                };
            var res = await createMetricForMonitoring(projectId,metricid,metric_request);
            console.log(res);
            //return res;
            resolve(res);
        } catch (error) {
            reject(error);
        }
    });
}

async function createMetricDescriptor_verify_failedbackupinstance(){  
//module.exports.createMetricDescriptor_verify_failedbackupinstance =async function(){
    return new Promise(async(resolve,reject)=>{
        try {
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/verify_failedbackup_instance";
        
            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor: {
                  description: 'Failed instance for Backup',
                  displayName: 'Failed Backup Instance',
                  type: metricid,
                  metricKind: 'GAUGE',
                  valueType: 'DOUBLE',
                  unit: '{Count}',
                  labels: [
                    {
                      key: 'failedbackup_instance',
                      valueType: 'STRING',
                      description: 'Failed backup instance',
                    },
                  ],
                },
              };
            var res = await createMetricForMonitoring(projectId,metricid,metric_request);
            console.log(res);
            //return res;
            resolve(res);
        } catch (error) {
            reject(error);
        }
    });
}

async function createMetricDescriptor_central_BR_failedbackupinstance(){
//module.exports.createMetricDescriptor_central_BR_failedbackupinstance =   async function (){
    return new Promise(async(resolve,reject)=>{
        try {
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/failedbackup_instance";
        
            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor: {
                  description: 'Failed instance for Backup',
                  displayName: 'Failed Backup Instance',
                  type: metricid,
                  metricKind: 'GAUGE',
                  valueType: 'DOUBLE',
                  unit: '{Count}',
                  labels: [
                    {
                      key: 'failedbackup_instance',
                      valueType: 'STRING',
                      description: 'Failed backup instance',
                    },
                  ],
                },
              };
        
            //var res = await writeDataForMonitoring(projectId,metricid,metric_request);
            var res = await createMetricForMonitoring(projectId,metricid,metric_request);
            console.log(res);
            resolve(res);
            //return res;
        } catch (error) {
            reject(error);
        }
    });
}

async function createMetricDescriptor_central_BR_successbackupinstance(){
//module.exports.createMetricDescriptor_central_BR_successbackupinstance = async function(){
    return new Promise(async(resolve,reject)=>{
        try {
            const monitoring = require('@google-cloud/monitoring');
            const client = new monitoring.MetricServiceClient({
                projectId:GCLOUD_PROJECT,
                grpc:grpc
            });
            const projectId = GCLOUD_PROJECT;
            const metricid = "custom.googleapis.com/firestore/successbackup_instance";
        
            var metric_request={
                name: client.projectPath(projectId),
                metricDescriptor: {
                  description: 'Susccessful instance for Backup',
                  displayName: 'Susccessful Backup Instance',
                  type: metricid,
                  metricKind: 'GAUGE',
                  valueType: 'DOUBLE',
                  unit: '{Count}',
                  labels: [
                    {
                      key: 'successfulbackup_instance',
                      valueType: 'STRING',
                      description: 'Susccessful backup instance',
                    },
                  ],
                },
              };
        
            //var res = await writeDataForMonitoring(projectId,metricid,metric_request);
            var res = await createMetricForMonitoring(projectId,metricid,metric_request);
            console.log(res);
            resolve(res);
            //return res;
        } catch (error) {
            reject(error);
        }
    });
}

async function createMetricForMonitoring(projectId,metricid,metric_Request)
//module.exports.createMetricForMonitoring =async function(projectId,metricid,metric_Request)
{
    var response = undefined;
    try
    {
        //https://cloud.google.com/monitoring/custom-metrics/creating-metrics
        // Imports the Google Cloud client library

        // Creates a client
        const client = new monitoring.MetricServiceClient({
            projectId:GCLOUD_PROJECT,
            grpc:grpc
        });
        // Creates a custom metric descriptor
        const descriptor1 = await client.createMetricDescriptor(metric_Request);
        descriptor = descriptor1[0];
        console.log('Created custom Metric:\n');
        console.log(`Name: ${descriptor.displayName}`);
        console.log(`Description: ${descriptor.description}`);
        console.log(`Type: ${descriptor.type}`);
        console.log(`Kind: ${descriptor.metricKind}`);
        console.log(`Value Type: ${descriptor.valueType}`);
        console.log(`Unit: ${descriptor.unit}`);
        console.log('Labels:');
        descriptor.labels.forEach(label => {
            console.log(`  ${label.key} (${label.valueType}) - ${label.description}`);
        });
        response = descriptor;
    }
    catch(error)
    {
        response = error;
    }
    finally{
        return response;
    }
}

//#endregion
/********************STOP : Metric Descriptor***********************************/


//commonBRSolution();