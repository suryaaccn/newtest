#**ADHOC BACKUP AND RESTORE FOR FIRESTORE**
---

This YAML file is for performing adhoc backup and restore in Cloud Firestore. 
User triggers the adhoc backup or restore by passing variables into the DevOps pipeline. The variables are published by a pubsub topic and then will trigger the
Cloud Function to perform the operation.  (SEE BLUEPRINT BELOW)

---

##GCP SERVICES USED:
* CLOUD PUB/SUB
* CLOUD FUNCTION
* CLOUD FIRESTORE 
* CLOUD STORAGE

---

##OBJECTS REQUIRED:
* Service Account Keys 
* GCP Project ID
* GCP Service Account Email

---
##BLUEPRINT 

![Image](/FirestoreBackupRestore.png)