// unit test modules
var sinon = require('sinon');
var expect = require('chai').expect;
var assert = require('chai').assert;
// test files including the main index.js
const testconfig = require('./testConfig.json');
process.env.GCLOUD_PROJECT = testconfig.GCLOUD_PROJECT;
process.env.DURATION_IN_DAYS = testconfig.DURATION_IN_DAYS;
process.env.ALERT_POLICY_NAME = testconfig.ALERT_POLICY_NAME;
process.env.Min_THRESHOLD = testconfig.Min_THRESHOLD;
process.env.Max_THRESHOLD = testconfig.Max_THRESHOLD;
const logData = require('./test_logData.json');
const oldpolicy= require('./old_threshold_policy.json');
const newpolicy = require('./new_threshold_policy.json');
const app = require('../index.js');
const timeseries = require('./timeseries_data.json');
// GCP modules
//const grpc = require('grpc');
const grpc = require('@grpc/grpc-js');
const Firestore = require('@google-cloud/firestore');
const monitoring = require('@google-cloud/monitoring');
const {GoogleAuth} = require('google-auth-library');
const {google, monitoring_v3, firestore_v1beta1, firestore_v1, monitoring_v1} = require('googleapis');

describe('Integration test block', async function () {
    // stub variables
    var stub_listTimeseries, stub_getAuthClient, stub_updateNewThreshold, stub_getAlertPolicyDetails, stub_writetoFirestore, stub_createIndex, stub_getdata, stub_getstatus
    before(function () {
        //stub_listTimeseries = sinon.stub(monitoring.MetricServiceClient.prototype, 'listTimeSeries');
        //stub_listTimeseries.returns(timeseries.data);
        stub_listTimeseries = sinon.stub(monitoring.v3.MetricServiceClient.prototype, 'listTimeSeries');
        stub_listTimeseries.returns(timeseries.data);

        stub_getAuthClient = sinon.stub(GoogleAuth.prototype, 'getClient');
        stub_getAuthClient.returns({
            _clientId: "test",
            _clientSecret: "test",
            request: function(){
                return "success";
            }
        });
        
        stub_updateNewThreshold = sinon.stub(monitoring_v3.Resource$Projects$Alertpolicies.prototype, 'patch');
        stub_updateNewThreshold.returns({
            data: oldpolicy
        })
        stub_getAlertPolicyDetails = sinon.stub(monitoring.AlertPolicyServiceClient.prototype, 'getAlertPolicy');
        stub_getAlertPolicyDetails.returns(newpolicy.data);
        stub_writetoFirestore = sinon.stub(Firestore.CollectionReference.prototype, 'add');
        stub_writetoFirestore.returns(Promise.resolve({
            "id": "3mwk9BZKkMgeFh4iqYzD"  
        }));
        stub_createIndex = sinon.stub(firestore_v1beta1.Resource$Projects$Databases$Indexes.prototype, 'create');
        stub_createIndex.returns({
                "data": {
                "result": "test",
                "name": "mockname"
            }
        });
        /*
        stub_getdata = sinon.stub(Firestore.CollectionReference.prototype, 'get');
        stub_getdata.returns({
            docs: [
                {
                    data: () => {
                        return(logData);
                    }
                }
            ]
        });
        */
        stub_getdata = sinon.stub(Firestore.CollectionReference.prototype, 'where');
        stub_getdata.returns({
            where: () => {
                return {
                    get: () => {
                        return {
                            docs: [
                                {
                                    data: () => {
                                        return(logData);
                                    }
                                }
                            ]
                        }
                    }
                }
            },
            orderBy: function () {
                return {
                    limit: () =>  {
                        return {
                            get: () => {
                            //return(logData);
                                return {
                                        docs: [
                                        {
                                            data: () => {
                                                return(logData);
                                            }
                                        }
                                    ]
                                }
                            }   
                        }
                    }
                }
            }   
        });
        _date = new Date();
        stub_getstatus = sinon.stub(firestore_v1.Resource$Projects$Databases$Operations.prototype, 'get');
        stub_getstatus.returns({
            data: {
                response: {
                    state: "READY"
                },
                metadata: {
                    operationState:"SUCCESSFUL",
                    progressDocuments:{
                        completedWork:34234
                    },
                    progressBytes:{
                        completedWork:324234
                    },
                    startTime:_date,
                    endTime:_date.setSeconds(50)
                },
                error:{
                    message:"ERROR",
                    code:999
                }
            }
        });
    });
    after(function () {
        stub_listTimeseries.restore();
        stub_getAuthClient.restore();
        stub_updateNewThreshold.restore();
        stub_getAlertPolicyDetails.restore();
        stub_writetoFirestore.restore();
        stub_createIndex.restore();
        stub_getdata.restore();
        stub_getstatus.restore();
    });
    //main function
    it('Main solution', async () => {
        var result = await app.getThreshold();
        console.log(result);
        assert.equal(result, "success");
    });
    it('calculate_threshold', async () => {
        var filter = "firestore.googleapis.com/document/read_count";
        const thresholdValue = await app.updateThresholdFunctions.calculate_threshold(filter);
        console.log(`Threshold value is ${thresholdValue}.`);
        assert.isNumber(thresholdValue, 'Must return a value.');
    });
    it('Calculate mean', async () => {
        //getMean function
        var data = testconfig.testdata;
        const mean = await app.updateThresholdFunctions.getMean(data);
        console.log(`Mean value is ${mean}`);
        assert.isNumber(mean, 'Must return a number.');
    });
    it('Calculate SD', async () => {
        //getSD function
        var data = testconfig.testdata;
        const sd = await app.updateThresholdFunctions.getSD(data);
        console.log(`SD value is ${sd}`);
        assert.isNumber(sd, 'Must return a value.');
    });
    it('updateThreshold_New', async () => {
        var ALERT_POLICY_NAME = process.env.ALERT_POLICY_NAME;
        var res = await app.updateThresholdFunctions.updateThreshold_New(ALERT_POLICY_NAME, newpolicy);
        var newThreshold = res.conditions[0].conditionThreshold.thresholdValue
        assert.isNumber(newThreshold);
    });
    it('authorize', async () => {
        app.updateThresholdFunctions.authorize;
    });
    it('Get alert details', async () => {
        //var testpolicy = 'testpolicy';
        //var response = await app.updateThresholdFunctions.getAlertPolicyDetails(newpolicy);
        var response = await app.updateThresholdFunctions.getAlertPolicyDetails(process.env.ALERT_POLICY_NAME);
        assert.equal(response, newpolicy.data[0]);
    });
    it('Write Logs to Firestore', async () => {
        await app.updateThresholdFunctions.writelogstoFirestore(logData);
    });
    it('Get data', async () => {
        var responsedata = await app.updateThresholdFunctions.getLatestDataFromCollection();
        assert.equal(responsedata[0], logData);
    });
    it('Create index', async () => {
        var responsecreateIndex = await app.updateThresholdFunctions.createIndex();
        console.log(responsecreateIndex);
    });
    it('Get status', async () => {
        var name = 'teststatus';
        var responsestatus = await app.updateThresholdFunctions.getStatus(name);
        console.log(responsestatus);
    });
});