/*
NAME        : Update Threshold Tool
DESCRIPTION : update alert policy threhold base on historical read write consumption.
CREATED BY  : Mangesh Koyande
DATE        : 21st Sept 2020

Environment Variables : 
ALERT_POLICY_NAME   =   "projects/<<projectid>>/alertPolicies/<<alertpolicyid>>"
Min_THRESHOLD       =   Default Value 100
Max_THRESHOLD       =   Default Value 1000000
DURATION_IN_DAYS    =   Default Value 30 (In Days)
*/
/*
GCLOUD_PROJECT = "sbx-4367-daas17052021-34965457";
ALERT_POLICY_NAME = "projects/sbx-4367-daas17052021-34965457/alertPolicies/7738374582283343398";
//ALERT_POLICY_NAME   =   "projects/sbx-4367-daas05042021-2f981873/alertPolicies/4326610655121017555"
Min_THRESHOLD = 100;
Max_THRESHOLD = 1000000;
DURATION_IN_DAYS = 30;
*/

//Reference link : https://cloud.google.com/monitoring/api/ref_v3/rest/v3/projects.alertPolicies
const { Firestore, v1 } = require('@google-cloud/firestore');
const { google, monitoring_v3 } = require('googleapis');
const monitoring = google.monitoring('v3');
const { GoogleAuth } = require('google-auth-library');
const monitoring_cli = require('@google-cloud/monitoring');
const grpc = require("@grpc/grpc-js");


var GCLOUD_PROJECT = process.env.GCLOUD_PROJECT;
var ALERT_POLICY_NAME = process.env.ALERT_POLICY_NAME;
var Min_THRESHOLD = process.env.Min_THRESHOLD;
var Max_THRESHOLD = process.env.Max_THRESHOLD;
var DURATION_IN_DAYS = process.env.DURATION_IN_DAYS;

var AlertPolicyThresholdLogs = 'AlertPolicyThresholdLogs_New';

exports.getThreshold = async(event, context) => {
    //var getThreshold = async() => {
    try {
        if (!isFinite(DURATION_IN_DAYS)) {
            throw new Error("Please Pass valid value in environment variable :'DURATION_IN_DAYS'");
        }
        if (!isFinite(Min_THRESHOLD)) {
            throw new Error("Please Pass valid value in environment variable :'Min_THRESHOLD'");
        }
        if (!isFinite(Max_THRESHOLD)) {
            throw new Error("Please Pass valid value in environment variable :'Max_THRESHOLD'");
        }

        var alertResponse = await getAlertPolicyDetails(ALERT_POLICY_NAME);
        var recordFromCollection = await getLatestDataFromCollection();

        var prepareAlertResponse = alertResponse;
        delete prepareAlertResponse.creationRecord;
        delete prepareAlertResponse.mutationRecord;

        console.log(alertResponse);
        if (alertResponse.code != undefined) {
            console.log(alertResponse.message);
            throw new Error(alertResponse);
        }

        var LoggedDate = new Date().toUTCString();
        //var _conditions = alertResponse[0].conditions;
        var conditionArray = [];
        for (var i = 0; i < alertResponse.conditions.length; i++) {
            var condition = alertResponse.conditions[i];
            //var condition= _conditions[i];
            var conditionData = {
                metricType: condition.conditionThreshold.filter.split(" ").find(x => x.includes("metric.type")).split("=")[1].replace(/\"/g, ""),
                resourceType: condition.conditionThreshold.filter.split(" ").find(x => x.includes("resource.type")).split("=")[1].replace(/\"/g, ""),
                displayName: condition.displayName,
                name: condition.name,
                thresholdValue: condition.conditionThreshold.thresholdValue,
                comparison: condition.conditionThreshold.comparison,
                alertPolicyDisplayName: alertResponse.displayName,
                alertPolicyName: ALERT_POLICY_NAME.replace(/\"/g, "$"),
                LoggedDate: LoggedDate
            };

            var lastLoggedInfo = recordFromCollection.find(x => x.metricType == conditionData.metricType && x.comparison == conditionData.comparison);
            var new_threshold = 0;
            if (lastLoggedInfo == undefined || lastLoggedInfo.thresholdValue == conditionData.thresholdValue) {
                new_threshold = await calculate_threshold(conditionData.metricType);
                new_threshold = isFinite(new_threshold) ? new_threshold : 0;
                if (new_threshold < Min_THRESHOLD) {
                    new_threshold = Min_THRESHOLD;
                }

                var percentage_threshold = conditionData.thresholdValue * 0.9;

                if (new_threshold <= percentage_threshold) {
                    new_threshold = percentage_threshold;
                }

                if (new_threshold > percentage_threshold) {
                    new_threshold = new_threshold;
                }
                //if nt = 200 and ct = 1000
                //max(200, 1000 * 0.9) = 900 || nt

                //if nt = 999 and ct = 1000
                //max(999, 1000 * 0.9) = 999

                //check max threshold
                if (new_threshold > Max_THRESHOLD) {
                    new_threshold = Max_THRESHOLD;
                }
            } else {
                new_threshold = conditionData.thresholdValue;
            }
            conditionData.thresholdValue = new_threshold;
            conditionArray.push(conditionData);
            var index = prepareAlertResponse.conditions.findIndex(x => x.name == conditionData.name);
            if (index != -1) {
                prepareAlertResponse.conditions[index].conditionThreshold.thresholdValue = new_threshold;
                delete prepareAlertResponse.conditions[index].conditionThreshold.trigger.type;
                delete prepareAlertResponse.conditions[index].condition;
            }
        }
        var res = await updateThreshold_New(ALERT_POLICY_NAME, prepareAlertResponse);
        //console.log("in updateThreshold_New");
        //console.log(res);

        for (var i = 0; i < conditionArray.length; i++) {
            var logData = conditionArray[i];
            var firestoreLog = await writelogstoFirestore(logData);
            //console.log("in loop");
            //console.log(zz);
        }
        return "success";
    } catch (err) {
        throw new Error(err);
    }
}

module.exports.updateThresholdFunctions = {
    calculate_threshold: calculate_threshold,
    getMean: getMean,
    getSD: getSD,
    updateThreshold_New: updateThreshold_New,
    authorize: authorize,
    getAlertPolicyDetails: getAlertPolicyDetails,
    writelogstoFirestore: writelogstoFirestore,
    getLatestDataFromCollection: getLatestDataFromCollection,
    createIndex: createIndex,
    getStatus: getStatus
}

//calaculate threshold
async function calculate_threshold(filterType) {
    var itemData = [];
    const client = new monitoring_cli.MetricServiceClient({
        projectId: GCLOUD_PROJECT,
        grpc: grpc
    });

    //const daysFactor = 60 * 60 * 24;
    const daysFactor = 60 * 60 * 24 * DURATION_IN_DAYS;
    filterType = 'metric.type="' + filterType + '"';
    const request = {
        name: client.projectPath(GCLOUD_PROJECT),
        //filter: 'metric.type="firestore.googleapis.com/document/read_count"',
        filter: filterType,
        interval: {
            startTime: {
                // Limit results to the last 20 minutes
                seconds: (Date.now() / 1000) - (daysFactor * 10),
            },
            endTime: {
                seconds: Date.now() / 1000,
            },
        },
    };

    console.log("request");
    console.log(request);
    // Writes time series data
    const timeSeries = await client.listTimeSeries(request);
    timeSeries[0].forEach(data => {
        var minStartDttm = new Date()
        var totalPoints = 0
        data.points.forEach(point => {
            //console.log("point")
            totalPoints++;
            var startDttm = point.interval.startTime.seconds * 1000; //new Date(point.interval.startTime.seconds * 1000).toUTCString();
            var endDttm = point.interval.endTime.seconds * 1000; //new Date(point.interval.endTime.seconds * 1000).toUTCString();

            if (minStartDttm > startDttm) {
                minStartDttm = startDttm
            }

            itemData.push(parseInt(point.value.int64Value));
        })
        console.log("******TOTAL POINTS**");
        console.log(totalPoints);
        console.log("******itemData**");
        console.log(itemData);
    })

    console.log("******SD**");
    var sd = 0;
    var mean = 0;
    var data_Array = itemData.filter(x => x != 0);
    if (data_Array.length != 0) {
        mean = getMean(data_Array);
        sd = getSD(data_Array);
    }
    //calculate threshold
    //minimum threshold = 100 (del,read,write)
    var threshold = mean + (3 * sd);
    console.log(Math.round(threshold));
    return Math.round(threshold);
}

// Arithmetic mean
function getMean(data) {
    return data.reduce(function(a, b) {
        return Number(a) + Number(b);
    }) / data.length;
};

// Standard deviation
function getSD(data) {
    let m = getMean(data);
    return Math.sqrt(data.reduce(function(sq, n) {
        return sq + Math.pow(n - m, 2);
    }, 0) / (data.length - 1));
};

//update alert policy threshold
async function updateThreshold_New(name, body) {
    return new Promise(async(resolve, reject) => {
        let message;
        const authClient = await authorize();
        const request = {
            name: name,
            requestBody: body,
            auth: authClient
        };
        var res = undefined;
        try {

            //const response = (await monitoring.projects.alertPolicies.patch(request),grpc).data;
            const response = (await monitoring.projects.alertPolicies.patch(request)).data;
            /*
            const client = new monitoring_cli.v3.AlertPolicyServiceClient({
                projectId:process.env.GCLOUD_PROJECT,
                grpc:grpc
            });
            const response = await client.updateAlertPolicy({
                alertPolicy:{
                    name:name,
                    combiner:body.combiner,
                    conditions:body.conditions,
                    displayName:body.displayName,
                    creationRecord:body.creationRecord,
                    mutationRecord:body.mutationRecord
                }
            });
            */
            var res = response;
        } catch (err) {
            console.error("Method : updateThreshold : " + err);
            res = err;
            reject(new Error(err));
        } finally {
            resolve(res);
        }
    });
}

// authorize client for google api
async function authorize() {
    const auth = new GoogleAuth({
        scopes: ['https://www.googleapis.com/auth/cloud-platform', 'https://www.googleapis.com/auth/monitoring', 'https://www.googleapis.com/auth/datastore', 'https://www.googleapis.com/auth/monitoring.read'],
        projectId: GCLOUD_PROJECT
    }, grpc);
    return await auth.getClient();
}

//get Alert Policy Detail
async function getAlertPolicyDetails(name) {
    const authClient = await authorize();
    //const getmetadata = await 
    const request = {
        name: name,
        auth: authClient
    };
    try {
        var res = undefined;
        /*
        const response1 =await (await monitoring.projects.alertPolicies.get({
            auth:authClient,
            name:name
        })).data;

        const response22 = (await monitoring.projects.alertPolicies.get(request)).data;
        */
        const client = new monitoring_cli.v3.AlertPolicyServiceClient({
            projectId: GCLOUD_PROJECT,
            grpc: grpc
        });

        const response = await client.getAlertPolicy({
            name: name
        });
        res = response[0];
    } catch (err) {
        console.error("Method : getAlertPolicyDetails : " + err);
        res = err;
        throw new Error(err);
    } finally {
        return res;
    }
}

//Adds the Log Data information from the logData Function
async function writelogstoFirestore(logData) {
    //module.exports.writelogstoFirestore = async function (logData) {
    return new Promise(async(resolve, reject) => {
        //let _firestore = new firestore.Firestore();
        let _firestore = new Firestore({
            projectId: GCLOUD_PROJECT,
            grpc: grpc
        });
        let addDoc = "";
        try {
            addDoc = await _firestore.collection(AlertPolicyThresholdLogs).add(logData);
            console.log('Logs added to Firestore collection with ID: ', addDoc.id);
            resolve(addDoc);
        } catch (error) {
            reject(error);
        }
    });
}

//get latest data from collection
async function getLatestDataFromCollection() {
    var itemData = [];
    return new Promise(async(Resolve, Reject) => {
        try {
            var d = await createIndex();

            //let _firestore = new firestore.Firestore({
            let _firestore = new Firestore({
                //projectId:'sbx-4367-daasnosqlsbx-eeb5219c'
                projectId: GCLOUD_PROJECT,
                grpc: grpc
            });

            let collectionRef = await _firestore.collection(AlertPolicyThresholdLogs);
            let doclist1 = await collectionRef.where("alertPolicyName", "==", ALERT_POLICY_NAME).orderBy("LoggedDate", "desc").limit(1).get();

            if (doclist1.docs.length != 0) {
                let doc = doclist1.docs[0].data();
                var apln = ALERT_POLICY_NAME.replace(/\"/g, "$");
                let _doclist1 = await collectionRef
                    .where("alertPolicyName", "==", ALERT_POLICY_NAME)
                    .where("LoggedDate", "==", doc.LoggedDate)
                    .get();
                //itemData.push(doc);
                if (_doclist1.docs.length != 0) {
                    for (i = 0; i < _doclist1.docs.length; i++) {
                        let _doc = _doclist1.docs[i].data();
                        itemData.push(_doc);
                    }
                }
            }
            Resolve(itemData);
        } catch (error) {
            console.log(error);
            throw new Error(error);
            //Resolve(itemData);

        }
    });
}

async function createIndex() {
    return new Promise(async(Resolve, Reject) => {
        const authClient = await authorize();
        var requestBody = {
            "collectionId": AlertPolicyThresholdLogs,
            "fields": [{
                    "fieldPath": "alertPolicyName",
                    "mode": "ASCENDING"
                },
                {
                    "fieldPath": "LoggedDate",
                    "mode": "DESCENDING"
                }
            ]
        };
        const request = {
            parent: "projects/" + GCLOUD_PROJECT + "/databases/(default)",
            requestBody: requestBody,
            auth: authClient
        };
        var res;
        try {

            var response = (await google.firestore("v1beta1").projects.databases.indexes.create(request)).data;

            //var client1 = google.firestore("v1").

            res = response;
            var statusResponse = undefined,
                state = false;
            do {
                statusResponse = await getStatus(res.name);
                if (statusResponse.response != undefined) {
                    if (statusResponse.response.state == "READY")
                        state = true;
                }
            }
            while (state == false);
        } catch (err) {
            console.error("Method : createIndex : " + err);
            res = err;
        } finally {
            Resolve(res);
        }
    });
}

async function getStatus(name) {
    const firestore = google.firestore('v1');
    let message;

    const authClient = await authorize();
    const request = {
        name: name,
        auth: authClient
    };
    try {
        var res = undefined;
        const response = (await firestore.projects.databases.operations.get(request)).data;
        res = response;
    } catch (err) {
        console.error("Method : GetStatus : " + err);
        res = err;
        throw new Error(err);
    } finally {
        return res;
    }
}


//getThreshold();