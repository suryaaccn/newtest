﻿function GetDetails {
    
    Param(

       [string]$AzureDevOpsOrg,
       [string]$AzureDevOpsProjectName,
       $base64AuthInfo,
       [string]$Repo,
       [string]$ConfigFile
    )

    Write-Verbose "Getting the details from the JSON file..." -Verbose

    try{
        
        $GetConfigDetailsURI = "https://dev.azure.com/$($AzureDevOpsOrg)/$($AzureDevOpsProjectName)/_apis/git/repositories/$($Repo)/items?path=$($ConfigFile)&download=true&api-version=6.0"
        $configDetails = Invoke-RestMethod -Uri $GetConfigDetailsURI -Method Get -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get configuration details -> $ex.Message"

        Exit 0
    }

    return $configDetails
}

function ValidateSetupInputs {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$BackupRestoreEnv,
      [string]$BackupRestoreBlobContainer,
      [string]$BackupRestoreStorageClass,
      [string]$BackupRestoreStorageLocation,
      [string]$BackupRestoreCloudSchedRegion,
      [string]$BackupRestoreCloudSchedTimezone,
      [string]$BackupRestoreProjectID,
      [string]$BackupRestoreProjectName,
      [string]$BackupRestoreSA,
      [string]$BackupRestoreSAClientEmail,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreCreateCloudSched
    )

    Write-Verbose "Validating Backup and Restore Setup Inputs..."  -Verbose

    $validateSetupInputsResult = '{"code": 0, "desc":"" }'
    $validateSetupInputsResult = ConvertFrom-Json -InputObject $validateSetupInputsResult

    if([string]::IsNullOrEmpty($PAT)) {   
        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret."
        return $validateSetupInputsResult
    }
    if("undefined" -eq "$PAT") {            
        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret."
        return $validateSetupInputsResult
    }
    if([string]::IsNullOrEmpty($AirID)) {            
        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Air ID cannot be EMPTY or NULL. Please make sure to provide a valid Air ID."
        return $validateSetupInputsResult   
    }
    if([string]::IsNullOrEmpty($AppName)) {            
        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Application Name cannot be EMPTY or NULL. Please make sure to provide a valid Application Name."
        return $validateSetupInputsResult         
    }
    if([string]::IsNullOrEmpty($BackupRestoreEnv) -or [string]::IsNullOrEmpty($BackupRestoreBlobContainer) -or [string]::IsNullOrEmpty($BackupRestoreStorageClass) -or [string]::IsNullOrEmpty($BackupRestoreStorageLocation) -or [string]::IsNullOrEmpty($BackupRestoreCloudSchedRegion) -or [string]::IsNullOrEmpty($BackupRestoreCloudSchedTimezone) -or [string]::IsNullOrEmpty($BackupRestoreProjectID) -or [string]::IsNullOrEmpty($BackupRestoreProjectName) -or [string]::IsNullOrEmpty($BackupRestoreSA) -or [string]::IsNullOrEmpty($BackupRestoreSAClientEmail) -or [string]::IsNullOrEmpty($BackupRestoreCredFile) -or [string]::IsNullOrEmpty($BackupRestoreCreateCloudSched)){
        
        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Please make sure to provide all the details needed in the JSON file."
        return $validateSetupInputsResult
    }
    if($BackupRestoreCreateCloudSched -ne 'true' -and $BackupRestoreCreateCloudSched -ne 'false'){

        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Please make sure that the value for CreateCloudScheduler in the JSON file is set to true or false only!"
        return $validateSetupInputsResult
    }
    if($BackupRestoreEnv -ne 'Sbx' -and $BackupRestoreEnv -ne 'Dev' -and $BackupRestoreEnv -ne 'Test' -and $BackupRestoreEnv -ne 'Stage' -and $BackupRestoreEnv -ne 'Perf' -and $BackupRestoreEnv -ne 'Prod'){
        
        $validateSetupInputsResult.code = -1       
        $validateSetupInputsResult.desc = "Please make sure that the value for Environment in the JSON file is set to Sbx, Dev, Test, Stage, Perf, or Prod only!"
        return $validateSetupInputsResult
    }

    return $validateSetupInputsResult
}

function ValidateAdhocInputs {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AdhocBackupRestoreEnv,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestorePipeline,
      [string]$AdhocBackupRestoreRepository,
      [string]$AdhocBackupRestoreYAMLFile,
      [string]$AdhocBackupRestoreBucket,
      [string]$AdhocBackupRestoreFilePath,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestorePubsubTopic,
      $AdhocBackupRestoreFilter
    )

    $validateAdhocInputsResult = '{"code": 0, "desc":"" }'
    $validateAdhocInputsResult = ConvertFrom-Json -InputObject $validateAdhocInputsResult

    if([string]::IsNullOrEmpty($PAT)) {   
        $validateAdhocInputsResult.code = -1       
        $validateAdhocInputsResult.desc = "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret."
        return $validateAdhocInputsResult
    }
    if("undefined" -eq "$PAT") {            
        $validateAdhocInputsResult.code = -1       
        $validateAdhocInputsResult.desc = "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret."
        return $validateAdhocInputsResult
    }
    if([string]::IsNullOrEmpty($AirID)) {            
        $validateAdhocInputsResult.code = -1       
        $validateAdhocInputsResult.desc = "Air ID cannot be EMPTY or NULL. Please make sure to provide a valid Air ID."
        return $validateAdhocInputsResult
    }
    if([string]::IsNullOrEmpty($AppName)) {            
        $validateAdhocInputsResult.code = -1       
        $validateAdhocInputsResult.desc = "Application Name cannot be EMPTY or NULL. Please make sure to provide a valid Application Name."
        return $validateAdhocInputsResult        
    }
    if([string]::IsNullOrEmpty($AdhocBackupRestoreEnv) -or [string]::IsNullOrEmpty($AdhocBackupRestoreProjectID) -or [string]::IsNullOrEmpty($AdhocBackupRestoreSAClientEmail) -or [string]::IsNullOrEmpty($AdhocBackupRestoreCredFile) -or [string]::IsNullOrEmpty($AdhocBackupRestorePipeline) -or [string]::IsNullOrEmpty($AdhocBackupRestoreRepository) -or [string]::IsNullOrEmpty($AdhocBackupRestoreYAMLFile) -or [string]::IsNullOrEmpty($AdhocBackupRestoreBucket) -or [string]::IsNullOrEmpty($AdhocBackupRestorePubsubTopic)){
        
        $validateAdhocInputsResult.code = -1       
        $validateAdhocInputsResult.desc = "Please make sure to provide all the details needed in the JSON file."
        return $validateAdhocInputsResult
    }
    if($AdhocBackupRestoreEnv -ne 'Sbx' -and $AdhocBackupRestoreEnv -ne 'Dev' -and $AdhocBackupRestoreEnv -ne 'Test' -and $AdhocBackupRestoreEnv -ne 'Stage' -and $AdhocBackupRestoreEnv -ne 'Perf' -and $AdhocBackupRestoreEnv -ne 'Prod'){
            
        $validateAdhocInputsResult.code = -1       
        $validateAdhocInputsResult.desc = "Please make sure that the value for Environment in the JSON file is set to Sbx, Dev, Test, Stage, Perf, or Prod only!"
        return $validateAdhocInputsResult
    }

    return $validateAdhocInputsResult
}

function CheckProjectID {
    
    Param(
      
      [string]$AdhocBackupRestoreEnv,
      [string]$AdhocBackupRestoreProjectID
    )

    Write-Verbose "Checking if the GCP Project ID corresponds to the Environment provided..." -Verbose

    if($AdhocBackupRestoreEnv -eq 'Sbx'){
        
       $checkProjectID = $AdhocBackupRestoreProjectID -like 'sbx*'
       return $checkProjectID
    }
    elseif($AdhocBackupRestoreEnv -eq 'Dev' -or $AdhocBackupRestoreEnv -eq 'Test' -or $AdhocBackupRestoreEnv -eq 'Stage' -or $AdhocBackupRestoreEnv -eq 'Perf'){
        
       $checkProjectID = $AdhocBackupRestoreProjectID  -like 'npd*'
       return $checkProjectID
    }
    elseif($AdhocBackupRestoreEnv -eq 'Prod'){
        
       $checkProjectID = $AdhocBackupRestoreProjectID  -like 'prd*'
       return $checkProjectID
    }

    return $checkProjectID
}

function CheckFilePath {
    
    Param(
      
      $AdhocBackupRestoreFilePath
    )

    Write-Verbose "Check the value for the FilePath..." -Verbose

    $isNullorWhiteSpace = [string]::IsNullOrWhiteSpace($AdhocBackupRestoreFilePath)

    return $isNullorWhiteSpace
}

function GetPipelineList {
    
     Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    Write-Verbose "Getting the Pipelines..." -Verbose

    $getBuildPipelineListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/pipelines?api-version=6.1-preview.1"
    
    try {

        $buildPipelineList = Invoke-RestMethod -Uri $getBuildPipelineListURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get pipeline list -> $ex.Message"
    }

    return $buildPipelineList
}

function CheckifBackupRestorePipelinesExists {
    
    Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$backupRestoreCIPipeline,
      [string]$backupRestoreCDPipeline,
      [string]$adhocBRPipeline,
      [string]$alertsMonitoringPipeline
    )

    Write-Verbose "Checking if the pipelines are existing or not..." -Verbose

    $getPipelineList = GetPipelineList -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo
            
    $buildPipeline1 = $getPipelineList.value | where-object {$_.name -eq $backupRestoreCIPipeline}
    $buildPipeline1Count = $buildPipeline1 | Measure-Object
    $buildPipeline2 = $getPipelineList.value | where-object {$_.name -eq $adhocBRPipeline}
    $buildPipeline2Count = $buildPipeline2 | Measure-Object
    $buildPipeline3 = $getPipelineList.value | where-object {$_.name -eq $alertsMonitoringPipeline}
    $buildPipeline3Count = $buildPipeline3 | Measure-Object
    $buildPipeline4 = $getPipelineList.value | where-object {$_.name -eq $backupRestoreCDPipeline}
    $buildPipeline4Count = $buildPipeline4 | Measure-Object

    if($buildPipeline1Count.Count -ne 0 -or $buildPipeline2Count.Count -ne 0 -or $buildPipeline3Count.Count -ne 0 -or $buildPipeline4Count.Count -ne 0){
        
         return $true
    }
    elseif($buildPipeline1Count.Count -eq 0 -or $buildPipeline2Count.Count -eq 0 -or $buildPipeline3Count.Count -eq 0 -or $buildPipeline4Count.Count -eq 0){
        
         return $false
    }
}

function GetRepoList {
    
     Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    Write-Verbose "Getting the Repositories..." -Verbose

    $getRepoListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/git/repositories?api-version=6.1-preview.1"
    
    try {

        $repoList = Invoke-RestMethod -Uri $getRepoListURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get repo list -> $ex.Message"
    }

    return $repoList
}

function CheckifBackupRestoreReposExists {

    Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$backupRestoreRepo,
      [string]$alertsMonitoringRepo,
      [string]$adhocBRRepo
    )

    Write-Verbose "Checking if the repositories are existing or not..." -Verbose

    $getRepoList = GetRepoList -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo
     
    $repo1 = $getRepoList.value | where-object {$_.name -eq $backupRestoreRepo}
    $repo1Count = $repo1 | Measure-Object
    $repo2 = $getRepoList.value | where-object {$_.name -eq $adhocBRRepo}
    $repo2Count = $repo2 | Measure-Object
    $repo3 = $getRepoList.value | where-object {$_.name -eq $alertsMonitoringRepo}
    $repo3Count = $repo3 | Measure-Object

    if($repo1Count.Count -ne 0 -or $repo2Count.Count -ne 0 -or $repo3Count.Count -ne 0){
        
        return $true
    }
    elseif($repo1Count.Count -eq 0 -or $repo2Count.Count -eq 0 -or $repo3Count.Count -eq 0){
        
        return $false
    }
}

function CreateRepo {
    
    Param(

       [string]$AzureDevOpsAccount,
       [string]$AzureDevOpsProjectName,
       [string]$AzureDevOpsProjectId,
       $base64AuthInfo,
       [string]$repository
    )

    Write-Verbose "Creating $($repository) Repository..." -Verbose

    try{

        # Construct the REST URL and payload to create a repository
        $createRepoURI = "https://$($AzureDevOpsAccount)/$($AzureDevOpsProjectName)/_apis/git/repositories/?api-version=1.0"
        $body = '{"name": "'+ $repository +'"}'

        # Invoke the REST call and capture the results
        $createrepo = Invoke-RestMethod -Uri $createRepoURI -Method Post -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $body
        $repoID = $createrepo.id
        $repoURL = $createrepo.webUrl  
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create the repository -> $ex.Message"

        Exit 0
    }

    return $repoURL, $repoID
}

function CreateBackupRestoreCIPipeline {

    Param(

        [string]$AppName,
        [string]$AirID,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectId,
        [string]$AzureDevOpsProjectName,
        [string]$backupRestoreCIPipeline,
        [string]$repository,
        [string]$repoID,
        $base64AuthInfo  
    )

    Write-Verbose "Creating $($backupRestoreCIPipeline) Pipeline..." -Verbose

    #Creating the pipeline for Backup and Restore
    $foldername = $AppName + "_backup_restore_solution_" + $AirID + " Build Pipelines"
    $AzurePipelineYmlFileName = "azure-pipelines-ci.yml"

    $pipelineTemplatePath = "$PSScriptRoot\template\pipeline-builds\backup-restore-azure-pipelines-api-request-body.json"
    [String]$pipelineTemplateContent = Get-Content -Path "$($pipelineTemplatePath)" | Out-String
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzurePipelineYmlFileName}~", $AzurePipelineYmlFileName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsOrg}~", $AzureDevOpsOrg)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectID}~", $AzureDevOpsProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectName}~", $AzureDevOpsProjectName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsPipelineName}~", $backupRestoreCIPipeline)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoName}~", $repository)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoId}~", $repoID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{Folder}~", $foldername)    

    $createPipelineURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=5.0-preview.6"

    try{

        $createPipelineResponse = Invoke-RestMethod -Method Post -Uri $createPipelineURI -Body $pipelineTemplateContent -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}  
        
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create Pipeline $backupRestoreCIPipeline -> $ex.Message"
            
        Exit 0
    }

    return $createPipelineResponse 
}

function CreateBackupRestoreCDPipeline {

    Param(

        [string]$AppName,
        [string]$AirID,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectId,
        [string]$AzureDevOpsProjectName,
        [string]$backupRestoreCDPipeline,
        [string]$repository,
        [string]$repoID,
        $base64AuthInfo  
    )

    Write-Verbose "Creating $($backupRestoreCDPipeline) Pipeline..." -Verbose

    #Creating the pipeline for Backup and Restore
    $foldername = $AppName + "_backup_restore_solution_" + $AirID + " Build Pipelines"
    $AzurePipelineYmlFileName = "azure-pipelines-cd.yml"

    $pipelineTemplatePath = "$PSScriptRoot\template\pipeline-builds\backup-restore-azure-pipelines-api-request-body.json"
    [String]$pipelineTemplateContent = Get-Content -Path "$($pipelineTemplatePath)" | Out-String
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzurePipelineYmlFileName}~", $AzurePipelineYmlFileName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsOrg}~", $AzureDevOpsOrg)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectID}~", $AzureDevOpsProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectName}~", $AzureDevOpsProjectName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsPipelineName}~", $backupRestoreCDPipeline)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoName}~", $repository)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoId}~", $repoID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{Folder}~", $foldername)    

    $createPipelineURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=5.0-preview.6"

    try{

        $createPipelineResponse = Invoke-RestMethod -Method Post -Uri $createPipelineURI -Body $pipelineTemplateContent -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}  
        
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create Pipeline $backupRestoreCDPipeline -> $ex.Message"
            
        Exit 0
    }

    return $createPipelineResponse 
}

function SetupPipelineBackupRestore {

    Param(

        [string]$backupRestoreRepo,
        [string]$BackupRestoreEnv,
        [string]$BackupRestoreCloudSchedRegion,
        [string]$BackupRestoreCloudSchedTimezone,
        [string]$AirID,
        [string]$backupRestoreAppName,
        [string]$BackupRestoreBlobContainer,
        [string]$BackupRestoreCredFile,
        [string]$AppName,
        [string]$backupRestoreCIPipeline,
        [string]$backupRestoreCDPipeline,
        [string]$BackupRestoreCreateCloudSched,
        [string]$AzureDevOpsAccount,
        [string]$AzureDevOpsProjectName,
        [string]$AzureDevOpsProjectId,
        $base64AuthInfo,
        $PAT,
        [string]$RequestorEmail,
        [string]$RequestorName
    )

    #Creating GIT Repo backup and restore solution
    $repository = $backupRestoreRepo
    $repositoryURL, $repoID = CreateRepo -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -repository $repository
   
    Write-Host "Repository URL: $repositoryURL"
    Write-Host "Repository ID: $repoID"


    #clone the repo
    cd $PSScriptRoot

    git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository 2>$null

    #Copy backup and restore files in the repository
    $backupRestoreTemplatePath1 = "$PSScriptRoot\template\backup-restore\azure-templates"
    $backupRestoreTemplatePath2 = "$PSScriptRoot\template\backup-restore\infra"
    $backupRestoreTemplatePath3 = "$PSScriptRoot\template\backup-restore\src"
    $backupRestoreTemplatePath4 = "$PSScriptRoot\template\backup-restore\azure-pipelines-cd.yml"
    $backupRestoreTemplatePath5 = "$PSScriptRoot\template\backup-restore\azure-pipelines-ci.yml"
    $backupRestoreTemplatePath6 = "$PSScriptRoot\template\backup-restore\azure-pipelines-vars.yml"
    $backupRestoreTemplatePath7 = "$PSScriptRoot\template\backup-restore\package.json"
    $backupRestoreTemplatePath8 = "$PSScriptRoot\template\backup-restore\package-lock.json"
    
    try{
    
       cd "$PSScriptRoot\$repository"
            
       Copy-Item -Path $backupRestoreTemplatePath1 -Destination "$PSScriptRoot\$repository" -Recurse -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath2 -Destination "$PSScriptRoot\$repository" -Recurse -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath3 -Destination "$PSScriptRoot\$repository" -Recurse -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath4 -Destination "$PSScriptRoot\$repository" -Recurse -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath5 -Destination "$PSScriptRoot\$repository" -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath6 -Destination "$PSScriptRoot\$repository" -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath7 -Destination "$PSScriptRoot\$repository" -ErrorAction Stop
       Copy-Item -Path $backupRestoreTemplatePath8 -Destination "$PSScriptRoot\$repository" -ErrorAction Stop

    }
    catch{
       
       [Exception]$ex = $_.Exception
       Throw "Unable to copy the template files -> $ex.Message"
            
       Exit 0
    }

    #update main.tf file
    $maintfpath = "$PSScriptRoot\$repository\infra\Terraform_Files\main_cloudsched.tf" 

    $maintfcontent = Get-Content -Path $maintfpath
    $replaceRegion = $maintfcontent.Replace("<region>", "$($BackupRestoreCloudSchedRegion)")
    $replaceTimeZone = $replaceRegion.Replace("<timezone>", "$($BackupRestoreCloudSchedTimezone)")
    $brTopicName = "App_" + $AirID + "_backup_restore_topic"
    $replaceBRTopicName = $replaceTimeZone.Replace("<BR_topicName>", "$($brTopicName)")
    $replaceAIR = $replaceBRTopicName.Replace("<AIR>", "$($AirID)")
    $replaceAppName = $replaceAIR.Replace("<AppName>", "$($backupRestoreAppName)")
    $replaceAppName | Set-Content -Path $maintfpath

    $maintfpath2 = "$PSScriptRoot\$repository\infra\Terraform_Files\main_nocloudsched.tf" 
    $maintfcontent2 = Get-Content -Path $maintfpath2
    $replaceAIR2 = $maintfcontent2.Replace("<AIR>", "$($AirID)")
    $replaceAppName2 = $replaceAIR2.Replace("<AppName>", "$($backupRestoreAppName)")
    $replaceAppName2 | Set-Content -Path $maintfpath2

    #update azure-pipelines-vars.yml
    $azurepipelinesvarsymlPath = "$PSScriptRoot\$repository\azure-pipelines-vars.yml"
    $azurepipelinesvarsymlContent = Get-Content -Path $azurepipelinesvarsymlPath -ErrorAction Stop
    $replaceBlob = $azurepipelinesvarsymlContent.Replace("<BlobContainer>", "$($BackupRestoreBlobContainer)")
    $replaceAIR = $replaceBlob.Replace("<AIRID>", "$($AirID)")
    $replaceAppName = $replaceAIR.Replace("<AppName>", "$($backupRestoreAppName)")
    $replaceCreatCloudScheduler = $replaceAppName.Replace("<CreateCloudScheduler>","$($BackupRestoreCreateCloudSched)")
    $replaceAppName1 = $replaceCreatCloudScheduler.Replace("<OriginalAppName>","$($AppName)")

    if($BackupRestoreEnv -eq 'Sbx'){
        
        $newCredFile = "  GCP_SBX_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $replaceAppName1[27]
        $replaceAppName1[27] = $replaceAppName1[27].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Dev'){
        
        $newCredFile = "  GCP_DEV_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $replaceAppName1[28]
        $replaceAppName1[28] = $replaceAppName1[28].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Test'){
        
        $newCredFile = "  GCP_TEST_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $replaceAppName1[29]
        $replaceAppName1[29] = $replaceAppName1[29].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Stage'){
        
        $newCredFile = "  GCP_STAGE_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $replaceAppName1[30]
        $replaceAppName1[30] = $replaceAppName1[30].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Perf'){
        
        $newCredFile = "  GCP_PERF_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $replaceAppName1[31]
        $replaceAppName1[31] = $replaceAppName1[31].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
        $newCredFile = "  GCP_PROD_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $replaceAppName1[32]
        $replaceAppName1[32] = $replaceAppName1[32].Replace("$($toReplace)","$($newCredFile)")
    }

    $replaceAppName1 | Set-Content -Path $azurepipelinesvarsymlPath

    #update azure-pipelines-cd.yml
    $azurepipelinescdymlPath = "$PSScriptRoot\$repository\azure-pipelines-cd.yml"
    $azurepipelinescdymlContent = Get-Content -Path $azurepipelinescdymlPath -ErrorAction Stop
    $replaceAir = $azurepipelinescdymlContent.Replace("<AIR>", "$($AirID)")
    $replaceAppName = $replaceAir.Replace("<AppName>","$($AppName)")
    $replaceAppName | Set-Content -Path $azurepipelinescdymlPath

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "add azure-pipelines-vars.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository >$null 2>&1
    cd $PSScriptRoot

    $createBackupRestoreCIPipeline = CreateBackupRestoreCIPipeline -AppName $AppName -AirID $AirID -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectId $AzureDevOpsProjectId -AzureDevOpsProjectName $AzureDevOpsProjectName -backupRestoreCIPipeline $backupRestoreCIPipeline -repository $repository -repoID $repoID -base64AuthInfo $base64AuthInfo
    $createBackupRestoreCDPipeline = CreateBackupRestoreCDPipeline -AppName $AppName -AirID $AirID -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectId $AzureDevOpsProjectId -AzureDevOpsProjectName $AzureDevOpsProjectName -backupRestoreCDPipeline $backupRestoreCDPipeline -repository $repository -repoID $repoID -base64AuthInfo $base64AuthInfo
}

function CreateAdhocBackupRestorePipeline {

    Param(

        [string]$AppName,
        [string]$AirID,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectId,
        [string]$AzureDevOpsProjectName,
        [string]$adhocBRPipeline,
        [string]$repository,
        [string]$repoID,
        $base64AuthInfo  
    )
    
    Write-Verbose "Creating $($adhocBRPipeline) Pipeline..." -Verbose

    #Creating the pipeline for Backup and Restore
    $foldername = $AppName + "_backup_restore_solution_" + $AirID + " Build Pipelines"
    $AzurePipelineYmlFileName = "adhoc-backup-restore-pipeline.yml"

    $pipelineTemplatePath = "$PSScriptRoot\template\pipeline-builds\adhoc-backup-restore-azure-pipelines-api-request-body.json"
    [String]$pipelineTemplateContent = Get-Content -Path "$($pipelineTemplatePath)" | Out-String
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzurePipelineYmlFileName}~", $AzurePipelineYmlFileName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsOrg}~", $AzureDevOpsOrg)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectID}~", $AzureDevOpsProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectName}~", $AzureDevOpsProjectName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsPipelineName}~", $adhocBRPipeline)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoName}~", $repository)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoId}~", $repoID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{Folder}~", $foldername)    

    $createPipelineURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=5.0-preview.6"

    try{

        $createPipelineResponse = Invoke-RestMethod -Method Post -Uri $createPipelineURI -Body $pipelineTemplateContent -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}  
        
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create Pipeline $adhocBRPipeline -> $ex.Message"
            
        Exit 0
    }

    return $createPipelineResponse
}

function SetupPipelineAdhocBackupRestore {

    Param(

        [string]$adhocBRRepo,
        [string]$adhocBRPipeline,
        [string]$AirID,
        [string]$backupRestoreAppName,
        [string]$BackupRestoreEnv,
        [string]$AppName,
        [string]$AzureDevOpsAccount,
        [string]$AzureDevOpsProjectName,
        [string]$AzureDevOpsProjectId,
        $base64AuthInfo,
        $PAT,
        [string]$RequestorEmail,
        [string]$RequestorName
    )

    #Creating GIT repo for adhoc backup and restore
    $repository = $adhocBRRepo
    $repositoryURL, $repoID = CreateRepo -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -repository $repository
    
    Write-Host "Repository URL: $repositoryURL"
    Write-Host "Repository ID: $repoID"

    #clone the repo
    cd $PSScriptRoot

    git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository 2>$null

    #Copy adhoc backup and restore files in the repository
    $yamlFilePath = "$PSScriptRoot\template\adhoc-backup-restore\adhoc-backup-restore-pipeline.yml"
    $readmeFilePath = "$PSScriptRoot\template\adhoc-backup-restore\README.md"
    $imgFilePath = "$PSScriptRoot\template\adhoc-backup-restore\FirestoreBackupRestore.png"

    try{

       cd $PSScriptRoot\$repository
            
       Copy-Item -Path $yamlFilePath -Destination $PSScriptRoot\$repository -ErrorAction Stop
       Copy-Item -Path $readmeFilePath -Destination $PSScriptRoot\$repository -ErrorAction Stop
       Copy-Item -Path $imgFilePath -Destination $PSScriptRoot\$repository -ErrorAction Stop

    }
    catch{
       
       [Exception]$ex = $_.Exception
       Throw "Unable to copy the template files -> $ex.Message"
            
       Exit 0
    }

    #Update adhoc-backup-restore-pipeline.yml file
    $adhocymlPath = "$PSScriptRoot\$repository\adhoc-backup-restore-pipeline.yml"
    $adhocyml = Get-Content -Path $adhocymlPath
    $replaceAIR = $adhocyml.Replace("<AIRID>", "$($AirID)")
    $replaceAppName = $replaceAIR.Replace("<AppName>", "$($backupRestoreAppName)")
    $replaceEnv = $replaceAppName.Replace("<Env>", "$($BackupRestoreEnv)")
    $replaceEnv | Set-Content -Path $adhocymlPath -ErrorAction Stop

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "add adhoc-backup-restore-pipeline.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository >$null 2>&1
    cd $PSScriptRoot

    $createAdhocBackupRestorePipeline = CreateAdhocBackupRestorePipeline -AppName $AppName -AirID $AirID -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectId $AzureDevOpsProjectId -AzureDevOpsProjectName $AzureDevOpsProjectName -adhocBRPipeline $adhocBRPipeline -repository $repository -repoID $repoID -base64AuthInfo $base64AuthInfo
}

function CreateBackupRestoreAlertsMonitoringPipeline {
    
    Param(

        [string]$AppName,
        [string]$AirID,
        [String]$alertsMonitoringPipeline,
        [string]$BackupRestoreProjectID,
        [string]$BackupRestoreCredFile,
        [string]$BackupRestoreSAClientEmail,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectId,
        [string]$AzureDevOpsProjectName,
        [string]$repository,
        [string]$repoID,
        $base64AuthInfo  
    )

    Write-Verbose "Creating $($alertsMonitoringPipeline) Pipeline..." -Verbose

    #Creating the pipeline for Backup and Restore
    $foldername = $AppName + "_backup_restore_solution_" + $AirID + " Build Pipelines"
    $AzurePipelineYmlFileName = "backup-restore-alerts-monitoring.yml"
    $pubsubTopic = "App_" + $AirID + "_backup_restore_topic"

    $pipelineTemplatePath = "$PSScriptRoot\template\pipeline-builds\alerts-backup-restore-azure-pipelines-api-request-body.json"
    [String]$pipelineTemplateContent = Get-Content -Path "$($pipelineTemplatePath)" | Out-String
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzurePipelineYmlFileName}~", $AzurePipelineYmlFileName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{GCPProjectID}~", $BackupRestoreProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{GCPCredFile}~", $BackupRestoreCredFile)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{DefaultSAClientEmail}~", $BackupRestoreSAClientEmail)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{PubsubTopic}~", $pubsubTopic)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsOrg}~", $AzureDevOpsOrg)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectID}~", $AzureDevOpsProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectName}~", $AzureDevOpsProjectName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsPipelineName}~", $alertsMonitoringPipeline)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoName}~", $repository)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoId}~", $repoID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{Folder}~", $foldername)    

    $createPipelineURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=5.0-preview.6"

    try{

        $createPipelineResponse = Invoke-RestMethod -Method Post -Uri $createPipelineURI -Body $pipelineTemplateContent -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}  
        
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create Pipeline $alertsMonitoringPipeline -> $ex.Message"
            
        Exit 0
    }

    return $createPipelineResponse 
}

function SetupBackupRestoreAlertsMonitoringPipeline {

    Param(

        [string]$alertsMonitoringRepo,
        [string]$cloudFunctionName,
        [string]$AirID,
        [string]$backupRestoreAppName,
        [string]$BackupRestoreEnv,
        [string]$AppName,
        [String]$alertsMonitoringPipeline,
        [string]$BackupRestoreProjectID,
        [string]$BackupRestoreCredFile,
        [string]$BackupRestoreSAClientEmail,
        [string]$AzureDevOpsAccount,
        [string]$AzureDevOpsProjectName,
        [string]$AzureDevOpsProjectId,
        $base64AuthInfo,
        $PAT,
        [string]$RequestorEmail,
        [string]$RequestorName
    )

    #Creating GIT repo for backup and restore alerts monitoring
    $repository = $alertsMonitoringRepo
    $repositoryURL, $repoID = CreateRepo -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -repository $repository
    
    Write-Host "Repository URL: $repositoryURL"
    Write-Host "Repository ID: $repoID"

    #clone the repo
    cd $PSScriptRoot

    git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository 2>$null

    #Copy backup and restore alerts monitoring files in the repository
    $yamlFilePath = "$PSScriptRoot\template\backup-restore-alerts-monitoring\backup-restore-alerts-monitoring.yml"
    $alertsjsonPath1 = "$PSScriptRoot\template\backup-restore-alerts-monitoring\firestore-backuprestore-alerts.json"
    $alertsjsonPath2 = "$PSScriptRoot\template\backup-restore-alerts-monitoring\firestore-backuprestore-dashboard.json"

    try{

       cd $PSScriptRoot\$repository
            
       Copy-Item -Path $yamlFilePath -Destination $PSScriptRoot\$repository -ErrorAction Stop

       New-Item -ItemType "directory" -Path "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop | Out-Null
       Copy-Item -Path $alertsjsonPath1 -Destination "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop
       Copy-Item -Path $alertsjsonPath2 -Destination "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop
    }
    catch{

       [Exception]$ex = $_.Exception
       Throw "Unable to copy the template files -> $ex.Message"
            
       Exit 0
    }

    #Updating firestore-backuprestore-alerts.json for the Cloud Function 
    $alertsjsonPath = "$PSScriptRoot\$repository\AlertsMonitoring\firestore-backuprestore-alerts.json"
    $alertsjsonContent = Get-Content -Path $alertsjsonPath -ErrorAction Stop
    $CloudfunctionInfo = $alertsjsonContent[59]
    $new = '        "filter": "metric.type=\"cloudfunctions.googleapis.com/function/execution_count\" resource.type=\"cloud_function\" resource.label.\"function_name\"=\"' + $cloudFunctionName + '\" metric.label.\"status\"=\"error\"",'
    $CloudFunction = $alertsjsonContent.Replace("$($CloudfunctionInfo)", "$($new)")
    $CloudFunction | Set-Content -Path $alertsjsonPath -ErrorAction Stop

    #Update backup-restore-alerts-monitoring.yml
    $alertsymlPath = "$PSScriptRoot\$repository\backup-restore-alerts-monitoring.yml"
    $alertsyml = Get-Content -Path $alertsymlPath
    $replaceAIR = $alertsyml.Replace("<AIRID>", "$($AirID)") 
    $replaceAppName = $replaceAIR.Replace("<AppName>", "$($backupRestoreAppName)")
    $replaceEnv = $replaceAppName.Replace("<Env>", "$($BackupRestoreEnv)")
    $replaceEnv | Set-Content -Path $alertsymlPath -ErrorAction Stop

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "add backup-restore-alerts-monitoring.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository >$null 2>&1
    cd $PSScriptRoot

    $createBackupRestoreAlertsMonitoringPipeline = CreateBackupRestoreAlertsMonitoringPipeline -AppName $AppName -AirID $AirID -cloudFunctionName $cloudFunctionName -alertsMonitoringPipeline $alertsMonitoringPipeline -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectId $AzureDevOpsProjectId -AzureDevOpsProjectName $AzureDevOpsProjectName -repository $repository -repoID $repoID -base64AuthInfo $base64AuthInfo 
}

function SetupBackupRestoreSolution {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$BackupRestoreEnv,
      [string]$BackupRestoreBlobContainer,
      [string]$BackupRestoreStorageClass,
      [string]$BackupRestoreStorageLocation,
      [string]$BackupRestoreCloudSchedRegion,
      [string]$BackupRestoreCloudSchedTimezone,
      [string]$BackupRestoreProjectID,
      [string]$BackupRestoreProjectName,
      [string]$BackupRestoreSA,
      [string]$BackupRestoreSAClientEmail,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreCreateCloudSched,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName,
      $TOOL_TF_BACKEND_KEY,
      $ACR_BACKEND
    )

    Import-Module $PSM1Path

    if($BackupRestoreEnv -eq 'Sbx'){
        
       $env = "sbx"
    }
    elseif($BackupRestoreEnv -eq 'Dev' -or $BackupRestoreEnv -eq 'Test' -or $BackupRestoreEnv -eq 'Stage' -or $BackupRestoreEnv -eq 'Perf'){
        
       $env = "npd"
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
       $env = "prd"
    }

    $cloudFunctionName = $env + "-" + $AirID + "-backup-restore-function"
    $bucketName = $BackupRestoreProjectName + "-backup-restore-bucket"
    $backupRestoreAppName = $AppName + '-backup-restore'
    $storagename = "backup-restore-bucket"
    $adhocBRRepo = $AppName + "_adhoc_backup_restore_repo_AIR" + $AirID
    $adhocBRPipeline = $AppName + "_adhoc_backup_restore_AIR" + $AirID
    $alertsMonitoringRepo = $AppName + "_alerts_monitoring_backup_restore_repo_AIR" + $AirID
    $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_backup_restore_AIR" + $AirID
    $backupRestoreRepo = $AppName + "_backup_restore_repo_AIR" + $AirID
    $backupRestoreCIPipeline = $AppName + "_backup_restore_CI_AIR" + $AirID
    $backupRestoreCDPipeline = $AppName + "_backup_restore_CD_AIR" + $AirID

    SetupPipelineBackupRestore -backupRestoreRepo $backupRestoreRepo -backupRestoreEnv $BackupRestoreEnv -BackupRestoreCloudSchedRegion $BackupRestoreCloudSchedRegion -BackupRestoreCloudSchedTimezone $BackupRestoreCloudSchedTimezone -AirID $AirID -backupRestoreAppName $backupRestoreAppName -BackupRestoreBlobContainer $BackupRestoreBlobContainer -BackupRestoreCredFile $BackupRestoreCredFile -AppName $AppName -backupRestoreCIPipeline $backupRestoreCIPipeline -backupRestoreCDPipeline $backupRestoreCDPipeline -BackupRestoreCreateCloudSched $BackupRestoreCreateCloudSched -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName
    SetupPipelineAdhocBackupRestore -adhocBRRepo $adhocBRRepo -adhocBRPipeline $adhocBRPipeline -AirID $AirID -backupRestoreAppName $backupRestoreAppName -BackupRestoreEnv $BackupRestoreEnv -AppName $AppName -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName
    SetupBackupRestoreAlertsMonitoringPipeline -alertsMonitoringRepo $alertsMonitoringRepo -cloudFunctionName $cloudFunctionName -AirID $AirID -backupRestoreAppName $backupRestoreAppName -BackupRestoreEnv $BackupRestoreEnv -AppName $AppName -alertsMonitoringPipeline $alertsMonitoringPipeline -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

    #Create variable Groups for the provisioning of GCP Resources
    $createBackupRestoreVarGroups = CreateBackupRestoreVarGroups -base64AuthInfo $base64AuthInfo -TOOL_TF_BACKEND_KEY $TOOL_TF_BACKEND_KEY -AppName $AppName -AirID $AirID -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName

    #Modify Variable Groups
    $modifyBackupRestoreVariableGroups = ModifyBackupRestoreVariableGroups -BackupRestoreEnv $BackupRestoreEnv -AppName $AppName -AirID $AirID -BackupRestoreSA $BackupRestoreSA -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreProjectName $BackupRestoreProjectName -BackupRestoreStorageClass $BackupRestoreStorageClass -BackupRestoreStorageLocation $BackupRestoreStorageLocation -storagename $storagename -base64AuthInfo $base64AuthInfo -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName

    #Create Service Connection
    $createServiceConnection = CreateServiceConnection -base64AuthInfo $base64AuthInfo -ACR_BACKEND $ACR_BACKEND -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsAccount $AzureDevOpsAccount

    #Output and pending action items
    Write-Host
    Write-Host "Creation of Pipelines and Modification of the Repositories and $($BackupRestoreEnv) Variable Group has been completed!" -ForegroundColor Green
    Write-Host
    Write-Host "Please take note of the following pipelines: " -ForegroundColor Yellow;
    Write-Host "1. $($backupRestoreCIPipeline)"
    Write-Host "2. $($backupRestoreCDPipeline)"
    Write-Host "3. $($alertsMonitoringPipeline)"
    Write-Host "4. $($adhocBRPipeline)"
    Write-Host
    Write-Host "Action Items:" -ForegroundColor Yellow;
    Write-Host "* Provide Approvers in the Environments"
    Write-Host "* Execute the pipelines manually in the order mentioned above (except for the last pipeline), to provision the resources and deploy the solution"
    Write-Host 
    Write-Host "If you have any questions, please reach out to ArchitectureServices.DaaS.NoSQL@accenture.com"
}

function CreateBackupRestoreVarGroups {
    
    Param(
        
        $base64AuthInfo,
        $TOOL_TF_BACKEND_KEY,
        [string]$AppName,
        [string]$AirID,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectName
    )

    Write-Verbose "Creating the Variable Groups..." -Verbose
    $CommonVarGroup = "$($AppName)-backup-restore_Cloud2.0_Common"
    $SbxVarGroup = "$($AppName)-backup-restore_Cloud2.0_Sbx"
    $DevVarGroup = "$($AppName)-backup-restore_Cloud2.0_Dev"
    $TestVarGroup = "$($AppName)-backup-restore_Cloud2.0_Test"
    $StageVarGroup = "$($AppName)-backup-restore_Cloud2.0_Stage"
    $PerfVarGroup = "$($AppName)-backup-restore_Cloud2.0_Perf"
    $ProdVarGroup = "$($AppName)-backup-restore_Cloud2.0_Prod"

    $getVarGroupURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/distributedtask/variablegroups?api-version=5.0-preview.1"

    #Check first if Var Groups are already existing
    $varGroupsList = Invoke-RestMethod -Method Get -Uri $getVarGroupURI -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    $varGroupsListValue = $varGroupsList.value
    $varGroupsListName = $varGroupsListValue.Name

    if($varGroupsListName -eq "$CommonVarGroup" -or $varGroupsListName -eq "$SbxVarGroup" -or $varGroupsListName -eq "$DevVarGroup" -or $varGroupsListName -eq "$TestVarGroup" -or $varGroupsListName -eq "$StageVarGroup" -or $varGroupsListName -eq "$PerfVarGroup" -or $varGroupsListName -eq "$ProdVarGroup"){
          
          Write-Warning "Variable Groups are already existing!"

          $common = $varGroupsList.value | where-object {$_.name -eq $CommonVarGroup}
          $global:VariableGroupCommonId = $common.id
          $sandbox = $varGroupsList.value | where-object {$_.name -eq $SbxVarGroup}
          $global:VariableGroupSbxId = $sandbox.id
          $dev = $varGroupsList.value | where-object {$_.name -eq $DevVarGroup}
          $global:VariableGroupDevId = $dev.id
          $test = $varGroupsList.value | where-object {$_.name -eq $TestVarGroup}
          $global:VariableGroupTestId = $test.id
          $stage = $varGroupsList.value | where-object {$_.name -eq $StageVarGroup}
          $global:VariableGroupStageId = $stage.id
          $perf = $varGroupsList.value | where-object {$_.name -eq $PerfVarGroup}
          $global:VariableGroupPerfId = $perf.id
          $prod = $varGroupsList.value | where-object {$_.name -eq $ProdVarGroup}
          $global:VariableGroupProdId = $prod.id
    }
    else{
        
       $BackupRestoreAppName = "$($AppName)-backup-restore"
       $Blob = $AirID + "-" + $AppName + "-tfstate"
       $createVarGroupURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/distributedtask/variablegroups?api-version=5.0-preview.1"

       #Creating Common Var Group
       cd $PSScriptRoot

       [String]$varGroupCommon_Str = Get-Content -Path "$PSScriptRoot\template\variable-groups\var_group_common.json" | Out-String 
       $varGroupCommon_Str = $varGroupCommon_Str.replace("~{AppName}~", $BackupRestoreAppName)
       $varGroupCommon_Str = $varGroupCommon_Str.replace("~{AirID}~", $AirID)
       $varGroupCommon_Str = $varGroupCommon_Str.replace("~{BlobContainer}~", $Blob)
       $varGroupCommon_Str = $varGroupCommon_Str.replace("~{TOOL_TF_BACKEND_KEY}~", $TOOL_TF_BACKEND_KEY)
       $createCommonVarGroup = Invoke-RestMethod -Method Post -Uri $createVarGroupURI -Body $varGroupCommon_Str -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}

       if ($createCommonVarGroup.id -gt 0){
        
            $global:VariableGroupCommonId = $createCommonVarGroup.id
            Write-Host "Successfully created Common Variable Group!"

       }
       else{
        
           Write-Warning "Encountered an error when creating Common Variable Group!"
       }

       #Creating other Var Groups
       $Environments = @('Sbx','Dev','Stage','Test','Perf','Prod')

       foreach($env in $Environments){
        
            if($env -eq 'Sbx'){
        
                $envi = "sbx"
            }
            elseif($env -eq 'Dev' -or $env -eq 'Test' -or $env -eq 'Stage' -or $env -eq 'Perf'){
        
                $envi = "npd"
            }
            elseif($env -eq 'Prod'){
        
                $envi = "prd"
            }

            if($env -eq 'Sbx'){
        
                $envName = "gcp_sbx"
            }
            elseif($env -eq 'Dev'){
        
                $envName = "gcp_dev"
            }
            elseif($env -eq 'Stage'){
        
                $envName = "gcp_stg"
            }
            elseif($env -eq 'Test'){
        
                $envName = "gcp_test"
            }
            elseif($env -eq 'Perf'){
        
                $envName = "gcp_perf"
            }
            elseif($env -eq 'Prod'){
        
                $envName = "gcp_prd"
            }

            [String]$BackupRestoreVarGroup_Str = Get-Content -Path "$PSScriptRoot\template\variable-groups\backup_restore_var_group.json" | Out-String 
            $BackupRestoreVarGroup_Str = $BackupRestoreVarGroup_Str.replace("~{Environment}~", $envi)
            $BackupRestoreVarGroup_Str = $BackupRestoreVarGroup_Str.replace("~{Envi}~", $envName)
            $BackupRestoreVarGroup_Str = $BackupRestoreVarGroup_Str.replace("~{AppName}~", $BackupRestoreAppName)
            $BackupRestoreVarGroup_Str = $BackupRestoreVarGroup_Str.replace("~{Env}~", $env)
            $createVarGroup = Invoke-RestMethod -Method Post -Uri $createVarGroupURI -Body $BackupRestoreVarGroup_Str -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
            
            if ($createVarGroup.id -gt 0){
                
                if($env -eq 'Sbx'){
                    
                    $global:VariableGroupSbxId = $createVarGroup.id
                }
                elseif($env -eq 'Dev'){
        
                    $global:VariableGroupDevId = $createVarGroup.id
                }
                elseif($env -eq 'Stage'){
        
                    $global:VariableGroupTestId = $createVarGroup.id
                }
                elseif($env -eq 'Test'){
        
                    $global:VariableGroupStageId = $createVarGroup.id
                }
                elseif($env -eq 'Perf'){
        
                    $global:VariableGroupPerfId = $createVarGroup.id
                }
                elseif($env -eq 'Prod'){
        
                    $global:VariableGroupProdId = $createVarGroup.id
                }

                Write-Host "Successfully created $($env) Variable Group!"

            }
            else{
        
               Write-Warning "Encountered an error when creating $($env) Variable Group!"
            }
       }

    }
}

function ModifyBackupRestoreVariableGroups {

    Param(
        
        [string]$BackupRestoreEnv,
        [string]$AppName,
        [string]$AirID,
        [string]$BackupRestoreSA,
        [string]$BackupRestoreProjectID,
        [string]$BackupRestoreProjectName,
        [string]$BackupRestoreStorageClass,
        [string]$BackupRestoreStorageLocation,
        [string]$storagename,
        $base64AuthInfo,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectName
    )

    $appNameVarGroup = "$AppName-backup-restore_Cloud2.0_$BackupRestoreEnv"

    Write-Host "Updating $appNameVarGroup Variable Group..."

    $serviceAccountClientEmail = $BackupRestoreSA + '@' + $BackupRestoreProjectID + '.iam.gserviceaccount.com'
    $storagePermissions = '{service_account_emails=[\"' + $serviceAccountClientEmail + '\"],role=\"roles/storage.objectCreator\"}'
    $storageBucket = $BackupRestoreProjectID + '.appspot.com'
    $sourcevalue = './'
    $triggerhttpvalue = 'false'
    $triggerEvent = '{event_type=\"google.pubsub.topic.publish\", event_resource=\"projects/' + $BackupRestoreProjectID + '/topics/App_' + $AirID + '_backup_restore_topic\", \"retry\"=false}'

    $getVarGroupURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/distributedtask/variablegroups?api-version=5.0-preview.1"

    #List var groups
    $listVariableGroups = Invoke-RestMethod -Method Get -Uri $getVarGroupURI -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    $listVariableGroups = $listVariableGroups.value
    $VarGroup = $listVariableGroups | Where-Object {$_.name -eq $appNameVarGroup}
    $VarGroupName = $VarGroup.name
    $variableGroupID = $VarGroup.id
    $envVar = 'GCLOUD_PROJECT=\"' + $BackupRestoreProjectID + '\"'
    $entryPoint = "commonBRSolution"
    $functionName = "backup-restore-function"
    $storageBucketObj = "backupRestore"
    $pathToData = "./cf-backupRestore.zip"

    if($BackupRestoreEnv -eq 'Sbx'){
        
       $envi = "sbx"
       $envName = "gcp_sbx"
    }
    elseif($BackupRestoreEnv -eq 'Dev'){
       
       $envi = "npd"
       $envName = "gcp_dev"
    }
    elseif($BackupRestoreEnv -eq 'Stage'){
       
       $envi = "npd"
       $envName = "gcp_stg"
    }
    elseif($BackupRestoreEnv -eq 'Test'){
       
       $envi = "npd"
       $envName = "gcp_test"
    }
    elseif($BackupRestoreEnv -eq 'Perf'){
    
       $envi = "npd"
       $envName = "gcp_perf"
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
       $envName = "gcp_prd"
       $envi = "prd"
    }

    #Write-Host "Var Group Name: $VarGroupName"
    #Write-Host "Var Group ID: $variableGroupID"
    
    #Updating the variables for first time setup
    try {

       $updateVarGroupURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/distributedtask/variablegroups/$($variableGroupID)?api-version=5.1-preview.1"

       [String]$updateVarGroupBody = Get-Content -Path "$PSScriptRoot\template\variable-groups\update_backup_restore_var_group.json" | Out-String
       $updateVarGroupBody = $updateVarGroupBody.replace("~{Environment}~", $envi) 
       $updateVarGroupBody = $updateVarGroupBody.replace("~{RuntimeSA}~", $BackupRestoreSA)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{EnvVar}~", $envVar)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{FunctionEntryPoint}~", $entryPoint)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{FunctionName}~", $functionName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{BucketName}~", $storageBucket)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageObjName}~", $storageBucketObj)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PathToDataToUpload}~", $pathToData)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{SourceDir}~", $sourcevalue)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{TriggerEvent}~", $triggerEvent)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{TriggerHTTP}~", $triggerhttpvalue)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{Envi}~", $envName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{ProjectID}~", $BackupRestoreProjectID)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{ProjectName}~", $BackupRestoreProjectName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PubsubPublisherSA}~", '[]')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{ResourceToCreate}~", 'TOPIC')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PubsubSubscriberSA}~", '[]')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PubsubTopic}~", 'backup_restore_topic')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageClass}~", $BackupRestoreStorageClass)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageLifecycle}~", '35')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageLocation}~", $BackupRestoreStorageLocation)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageName}~", $storageName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StoragePermissions}~", $storagePermissions)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{VarGroupToUpdate}~", $VarGroupName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{Env}~", $BackupRestoreEnv)
       
       #Write-Host "Body: $updateVarGroupBody"

       $updateVarGroup = Invoke-RestMethod -Method PUT -Uri $updateVarGroupURI -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $updateVarGroupBody
    
    }
    catch {
       
       [Exception]$ex = $_.Exception
       Throw "Unable to update variable group $VarGroupName -> $ex.Message"

       Exit 0
    }

    return $updateVarGroup

}

function GetServiceEndpointList {
    
    Param(
        
        $base64AuthInfo,
        [string]$AzureDevOpsProjectName,
        [string]$AzureDevOpsAccount
    )

    try {

        $getServiceEndpointListURI = "https://$($AzureDevOpsAccount)/DefaultCollection/$($AzureDevOpsProjectName)/_apis/distributedtask/serviceendpoints?api-version=5.0-preview"
        $getServiceEndpointListResult = Invoke-RestMethod -Uri $getServiceEndpointListURI -Method Get -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    }
    catch {

        [Exception]$ex = $_.Exception
        Write-Warning "Unable to get service endpoint list -> $ex.Message"

        Exit 0
    }

    return $getServiceEndpointListResult
}

function CreateServiceConnection {
    
    Param(
        
        $base64AuthInfo,
        $ACR_BACKEND,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectName,
        [string]$AzureDevOpsAccount
    )

    #Check if CIO-5064-Tfmod-Pull-ACR service connection is existing or not. If not created, it will be created
    $serviceEndpointList = GetServiceEndpointList -base64AuthInfo $base64AuthInfo -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsAccount $AzureDevOpsAccount

    Write-Verbose "Creating the Service Connection..." -Verbose
   
    $serviceEndpointListResult = $serviceEndpointList.value
    $serviceEndpointListName = $serviceEndpointListResult.name
    $checkTFmod = $serviceEndpointListName -match 'Tfmod-Pull'

    if($checkTFmod -eq $false){
        
        #Creating Service Connection
        $createServiceConnectionURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/serviceendpoint/endpoints?api-version=5.0-preview.2"

        [String]$ACR_Str = Get-Content -Path "$PSScriptRoot\template\service-connection\service_connection.json" | Out-String 
        $ACR_Str = $ACR_Str.replace("~{ACR_BACKEND}~", $ACR_BACKEND)
        $createServiceConnection = Invoke-RestMethod -Uri $createServiceConnectionURI -Method Post -Body $ACR_Str -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}

        Write-Host "Successfully created the Service Connection Endpoint!"
        return $true
    }

    else{
        
        Write-Warning "CIO-5064-Tfmod-Pull-ACR service connection is already existing!"
        return $false
    }
}

function CloneRepos {

    Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $PAT,
      [string]$backupRestoreRepo,
      [string]$alertsMonitoringRepo
    )

    Write-Verbose "Cloning the Repositories..." -Verbose

    try {

        cd $PSScriptRoot

        git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$backupRestoreRepo 2>$null
        git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$alertsMonitoringRepo 2>$null
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to clone the repositories -> $ex.Message"

        Exit 0
    }
}

function UpdateBackupRestoreRepoForOtherEnv {
    
    Param(
      
      [string]$backupRestoreRepo,
      [string]$BackupRestoreEnv,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreCreateCloudSched,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $PAT,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Write-Verbose "Updating the Repository for Backup and Restore..." -Verbose

    cd "$PSScriptRoot\$backupRestoreRepo"

    #update azure-pipelines-vars.yml
    $azurepipelinesvarsymlPath = "$PSScriptRoot\$backupRestoreRepo\azure-pipelines-vars.yml"
    $azurepipelinesvarsymlContent = Get-Content -Path $azurepipelinesvarsymlPath -ErrorAction Stop

    if($BackupRestoreEnv -eq 'Sbx'){
        
        $newCredFile = "  GCP_SBX_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $azurepipelinesvarsymlContent[27]
        $azurepipelinesvarsymlContent[27] = $azurepipelinesvarsymlContent[27].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Dev'){
        
        $newCredFile = "  GCP_DEV_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $azurepipelinesvarsymlContent[28]
        $azurepipelinesvarsymlContent[28] = $azurepipelinesvarsymlContent[28].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Test'){
        
        $newCredFile = "  GCP_TEST_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $azurepipelinesvarsymlContent[29]
        $azurepipelinesvarsymlContent[29] = $azurepipelinesvarsymlContent[29].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Stage'){
        
        $newCredFile = "  GCP_STAGE_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $azurepipelinesvarsymlContent[30]
        $azurepipelinesvarsymlContent[30] = $azurepipelinesvarsymlContent[30].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Perf'){
        
        $newCredFile = "  GCP_PERF_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $azurepipelinesvarsymlContent[31]
        $azurepipelinesvarsymlContent[31] = $azurepipelinesvarsymlContent[31].Replace("$($toReplace)","$($newCredFile)")
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
        $newCredFile = "  GCP_PROD_CREDENTIAL_FILE: '$($BackupRestoreCredFile)'"
        $toReplace = $azurepipelinesvarsymlContent[32]
        $azurepipelinesvarsymlContent[32] = $azurepipelinesvarsymlContent[32].Replace("$($toReplace)","$($newCredFile)")
    }

    $newCreateCloudScheduler = "  CREATE_CLOUD_SCHEDULER: '$($BackupRestoreCreateCloudSched)'"
    $toReplace = $azurepipelinesvarsymlContent[4]
    $azurepipelinesvarsymlContent[4] = $azurepipelinesvarsymlContent[4].Replace("$($toReplace)","$($newCreateCloudScheduler)")

    $azurepipelinesvarsymlContent | Set-Content -Path $azurepipelinesvarsymlPath

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "update azure-pipelines-vars.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$backupRestoreRepo >$null 2>&1
    cd $PSScriptRoot

}

function UpdateBackupRestoreAlertsMonitoringRepo {
    
    Param(
      
      [string]$alertsMonitoringRepo,
      [string]$cloudFunctionName,
      [string]$AirID,
      [string]$backupRestoreAppName,
      [string]$BackupRestoreEnv,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $PAT,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Write-Verbose "Updating the Repository for Backup & Restore - Alerts and Monitoring..." -Verbose

    cd "$PSScriptRoot\$alertsMonitoringRepo"

    #update firestore-backuprestore-alerts.json
    $alertsjsonPath = "$PSScriptRoot\$alertsMonitoringRepo\AlertsMonitoring\firestore-backuprestore-alerts.json"
    $alertsjsonContent = Get-Content -Path $alertsjsonPath -ErrorAction Stop

    $CloudfunctionInfo = $alertsjsonContent[59]
    $new = '        "filter": "metric.type=\"cloudfunctions.googleapis.com/function/execution_count\" resource.type=\"cloud_function\" resource.label.\"function_name\"=\"' + $cloudFunctionName + '\" metric.label.\"status\"=\"error\"",'
    $CloudFunction = $alertsjsonContent.Replace("$($CloudfunctionInfo)", "$($new)")
    $CloudFunction | Set-Content -Path $alertsjsonPath -ErrorAction Stop

    #Update backup-restore-alerts-monitoring.yml for the environment
    $alertsYMLPath = "$PSScriptRoot\$alertsMonitoringRepo\backup-restore-alerts-monitoring.yml"
    $alertsYMLContent = Get-Content -Path $alertsYMLPath -ErrorAction Stop

    $OldEnvi = $alertsYMLContent[23]
    $newEnvi = "    environment: '$($AirID)-$($backupRestoreAppName)-GCP-$($BackupRestoreEnv)'"
    $ReplaceEnv = $alertsYMLContent.Replace("$($OldEnvi)", "$($newEnvi)")
    $ReplaceEnv | Set-Content -Path $alertsYMLPath -ErrorAction Stop

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "update backup-restore-alerts-monitoring.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$alertsMonitoringRepo >$null 2>&1
    cd $PSScriptRoot

}

function GetPipelineID {

    Param(
      
      [string]$pipeline,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    $getBuildPipelineListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=6.0"

    try {

       $buildPipelineList = Invoke-RestMethod -Uri $getBuildPipelineListURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
       $buildPipeline = $buildPipelineList.value| where-object {$_.name -eq $pipeline}
       $buildPipelineID = $buildPipeline.id
       return $buildPipelineID
    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to get the Pipeline ID -> $ex.Message"

       Exit 0
    }
}

function GetAlertsMonitoringPipelineDetails {
    
    Param(
      
      $pipelineID,
      [string]$BackupRestoreProjectID,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreSAClientEmail,
      [string]$pubsubTopic,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions/$($pipelineID)?api-version=6.0"
   
    try {

        $pipelineDetails = Invoke-RestMethod -Uri $pipelineURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
        $pipelineDetails.variables.GCP_PROJECT_ID.value = $BackupRestoreProjectID
        $pipelineDetails.variables.GCP_CREDENTIAL_FILE.value = $BackupRestoreCredFile
        $pipelineDetails.variables.SR_ACCT_CLIENT_EMAIL.value = $BackupRestoreSAClientEmail
        $pipelineDetails.variables.PUBSUB_TOPIC.value = $pubsubTopic
        $json = @($pipelineDetails) | ConvertTo-Json
        return $json

    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to get the Pipeline details -> $ex.Message"

       Exit 0
    }
}

function UpdateAlertsMonitoringPipelineVariables {
    
    Param(
      
      [string]$alertsMonitoringPipeline,
      [string]$BackupRestoreProjectID,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreSAClientEmail,
      [string]$pubsubTopic,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    Write-Verbose "Updating Pipeline Variable for Backup and Restore - Alerts and Monitoring..." -Verbose

    #Get Pipeline ID
    $pipeline = $alertsMonitoringPipeline
    $pipelineID = GetPipelineID -pipeline $pipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Get Pipeline Details
    $getAlertsMonitoringPipelineDetails = GetAlertsMonitoringPipelineDetails -pipelineID $pipelineID -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -pubsubTopic $pubsubTopic -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Update the Pipeline Variables
    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions/$($pipelineID)?api-version=6.0"
   
    try {

        $updatePipeline = Invoke-RestMethod -Method Put -Uri $pipelineURL -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $getAlertsMonitoringPipelineDetails
        return $updatePipeline
    
    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to update the Pipeline variable -> $ex.Message"

       Exit 0
    }
}

function SetupBackupRestoreSolutionForOtherEnvironments {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$BackupRestoreEnv,
      [string]$BackupRestoreStorageClass,
      [string]$BackupRestoreStorageLocation,
      [string]$BackupRestoreCloudSchedRegion,
      [string]$BackupRestoreCloudSchedTimezone,
      [string]$BackupRestoreProjectID,
      [string]$BackupRestoreProjectName,
      [string]$BackupRestoreSA,
      [string]$BackupRestoreSAClientEmail,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreCreateCloudSched,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Import-Module $PSM1Path

    if($BackupRestoreEnv -eq 'Sbx'){
        
       $env = "sbx"
    }
    elseif($BackupRestoreEnv -eq 'Dev' -or $BackupRestoreEnv -eq 'Test' -or $BackupRestoreEnv -eq 'Stage' -or $BackupRestoreEnv -eq 'Perf'){
        
       $env = "npd"
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
       $env = "prd"
    }

    $cloudFunctionName = $env + "-" + $AirID + "-backup-restore-function"
    $bucketName = $BackupRestoreProjectName + "-backup-restore-bucket"
    $backupRestoreAppName = $AppName + '-backup-restore'
    $storagename = "backup-restore-bucket"
    $alertsMonitoringRepo = $AppName + "_alerts_monitoring_backup_restore_repo_AIR" + $AirID
    $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_backup_restore_AIR" + $AirID
    $backupRestoreRepo = $AppName + "_backup_restore_repo_AIR" + $AirID
    $pubsubTopic = "App_" + $AirID + "_backup_restore_topic"
    $backupRestoreCIPipeline = $AppName + "_backup_restore_CI_AIR" + $AirID
    $backupRestoreCDPipeline = $AppName + "_backup_restore_CD_AIR" + $AirID

    #Cloning the Repositories
    $cloneRepos = CloneRepos -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -backupRestoreRepo $backupRestoreRepo -alertsMonitoringRepo $alertsMonitoringRepo

    #Modify Backup Restore repo to update the credential file in azure-pipelines.yml
    $updateBackupRestoreRepo = UpdateBackupRestoreRepoForOtherEnv -backupRestoreRepo $backupRestoreRepo -BackupRestoreEnv $BackupRestoreEnv -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreCreateCloudSched $BackupRestoreCreateCloudSched -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

    #Update Alerts Monitoring Repo
    $updateAlertsMonitoringRepo = UpdateBackupRestoreAlertsMonitoringRepo -alertsMonitoringRepo $alertsMonitoringRepo -cloudFunctionName $cloudFunctionName -AirID $AirID -backupRestoreAppName $backupRestoreAppName -BackupRestoreEnv $BackupRestoreEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName
    
    #Update Alerts Monitoring Pipeline Variables
    $updateAlertsMonitoringPipeline = UpdateAlertsMonitoringPipelineVariables -alertsMonitoringPipeline $alertsMonitoringPipeline -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -pubsubTopic $pubsubTopic -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Modify Variable Group
    $modifyBackupRestoreVariableGroup = ModifyBackupRestoreVariableGroups -BackupRestoreEnv $BackupRestoreEnv -AppName $AppName -AirID $AirID -BackupRestoreSA $BackupRestoreSA -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreProjectName $BackupRestoreProjectName -BackupRestoreStorageClass $BackupRestoreStorageClass -BackupRestoreStorageLocation $BackupRestoreStorageLocation -storagename $storagename -base64AuthInfo $base64AuthInfo -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName
    
    #Output and pending action items
    Write-Host
    Write-Host "Modification of the Repositories and $($BackupRestoreEnv) Variable Group has been completed!" -ForegroundColor Green
    Write-Host
    Write-Host "Pending item is to execute the pipelines manually in the order mentioned below to provision the resources and deploy the solution to your GCP Project for $($BackupRestoreEnv) Environment" -ForegroundColor Yellow
    Write-Host "1. $($backupRestoreCIPipeline)"
    Write-Host "2. $($backupRestoreCDPipeline)"
    Write-Host "3. $($alertsMonitoringPipeline)"
    Write-Host 
    Write-Host "If you have any questions, please reach out to ArchitectureServices.DaaS.NoSQL@accenture.com"

}

function ModifyBackupRestoreVariableGroupsForRedeploy {

    Param(
        
        [string]$BackupRestoreEnv,
        [string]$AppName,
        [string]$AirID,
        [string]$BackupRestoreSA,
        [string]$BackupRestoreProjectID,
        [string]$BackupRestoreProjectName,
        [string]$BackupRestoreStorageClass,
        [string]$BackupRestoreStorageLocation,
        [string]$storagename,
        $base64AuthInfo,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectName
    )

    $appNameVarGroup = "$AppName-backup-restore_Cloud2.0_$BackupRestoreEnv"

    Write-Host "Updating $appNameVarGroup Variable Group..."

    $serviceAccountClientEmail = $BackupRestoreSA + '@' + $BackupRestoreProjectID + '.iam.gserviceaccount.com'
    $storagePermissions = '{service_account_emails=[\"' + $serviceAccountClientEmail + '\"],role=\"roles/storage.objectCreator\"}'
    $storageBucket = $BackupRestoreProjectID + '.appspot.com'
    $sourcevalue = './'
    $triggerhttpvalue = 'false'
    $triggerEvent = '{event_type=\"google.pubsub.topic.publish\", event_resource=\"projects/' + $BackupRestoreProjectID + '/topics/App_' + $AirID + '_backup_restore_topic\", \"retry\"=false}'

    $getVarGroupURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/distributedtask/variablegroups?api-version=5.0-preview.1"

    #List var groups
    $listVariableGroups = Invoke-RestMethod -Method Get -Uri $getVarGroupURI -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    $listVariableGroups = $listVariableGroups.value
    $VarGroup = $listVariableGroups | Where-Object {$_.name -eq $appNameVarGroup}
    $VarGroupName = $VarGroup.name
    $variableGroupID = $VarGroup.id
    $envVar = 'GCLOUD_PROJECT=\"' + $BackupRestoreProjectID + '\"'
    $entryPoint = "commonBRSolution"
    $functionName = "backup-restore-function"
    $storageBucketObj = "backupRestore"
    $pathToData = "./cf-backupRestore.zip"

    if($BackupRestoreEnv -eq 'Sbx'){
        
       $envi = "sbx"

       $envValue = $VarGroup.variables.GCP_ENV_NAME.value
       $envlastChar = $envValue.Substring($envValue.Length -1, 1)
       $condition = $envlastChar -match '^[0-9]+$'

       if($condition -eq $true){
    
          $newlastchar = [int]$envlastChar + [int]1
          $envName = 'gcp_sbx' + $newlastchar
       }
       else{
    
          $envName = 'gcp_sbx' + '1'
       }
    }
    elseif($BackupRestoreEnv -eq 'Dev'){
       
       $envi = "npd"

       $envValue = $VarGroup.variables.GCP_ENV_NAME.value
       $envlastChar = $envValue.Substring($envValue.Length -1, 1)
       $condition = $envlastChar -match '^[0-9]+$'

       if($condition -eq $true){
    
          $newlastchar = [int]$envlastChar + [int]1
          $envName = 'gcp_dev' + $newlastchar
       }
       else{
    
          $envName = 'gcp_dev' + '1'
       }
    }
    elseif($BackupRestoreEnv -eq 'Stage'){
       
       $envi = "npd"

       $envValue = $VarGroup.variables.GCP_ENV_NAME.value
       $envlastChar = $envValue.Substring($envValue.Length -1, 1)
       $condition = $envlastChar -match '^[0-9]+$'

       if($condition -eq $true){
    
          $newlastchar = [int]$envlastChar + [int]1
          $envName = 'gcp_stg' + $newlastchar
       }
       else{
    
          $envName = 'gcp_stg' + '1'
       }
    }
    elseif($BackupRestoreEnv -eq 'Test'){
       
       $envi = "npd"

       $envValue = $VarGroup.variables.GCP_ENV_NAME.value
       $envlastChar = $envValue.Substring($envValue.Length -1, 1)
       $condition = $envlastChar -match '^[0-9]+$'

       if($condition -eq $true){
    
          $newlastchar = [int]$envlastChar + [int]1
          $envName = 'gcp_test' + $newlastchar
       }
       else{
    
          $envName = 'gcp_test' + '1'
       }
    }
    elseif($BackupRestoreEnv -eq 'Perf'){
    
       $envi = "npd"

       $envValue = $VarGroup.variables.GCP_ENV_NAME.value
       $envlastChar = $envValue.Substring($envValue.Length -1, 1)
       $condition = $envlastChar -match '^[0-9]+$'

       if($condition -eq $true){
    
          $newlastchar = [int]$envlastChar + [int]1
          $envName = 'gcp_perf' + $newlastchar
       }
       else{
    
          $envName = 'gcp_perf' + '1'
       }
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
       $envi = "prd"

       $envValue = $VarGroup.variables.GCP_ENV_NAME.value
       $envlastChar = $envValue.Substring($envValue.Length -1, 1)
       $condition = $envlastChar -match '^[0-9]+$'

       if($condition -eq $true){
    
          $newlastchar = [int]$envlastChar + [int]1
          $envName = 'gcp_prd' + $newlastchar
       }
       else{
    
          $envName = 'gcp_prd' + '1'
       }
    }

    #Write-Host "Var Group Name: $VarGroupName"
    #Write-Host "Var Group ID: $variableGroupID"
    
    #Updating the variables
    try {

       $updateVarGroupURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/distributedtask/variablegroups/$($variableGroupID)?api-version=5.1-preview.1"

       [String]$updateVarGroupBody = Get-Content -Path "$PSScriptRoot\template\variable-groups\update_backup_restore_var_group.json" | Out-String
       $updateVarGroupBody = $updateVarGroupBody.replace("~{Environment}~", $envi) 
       $updateVarGroupBody = $updateVarGroupBody.replace("~{RuntimeSA}~", $BackupRestoreSA)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{EnvVar}~", $envVar)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{FunctionEntryPoint}~", $entryPoint)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{FunctionName}~", $functionName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{BucketName}~", $storageBucket)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageObjName}~", $storageBucketObj)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PathToDataToUpload}~", $pathToData)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{SourceDir}~", $sourcevalue)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{TriggerEvent}~", $triggerEvent)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{TriggerHTTP}~", $triggerhttpvalue)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{Envi}~", $envName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{ProjectID}~", $BackupRestoreProjectID)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{ProjectName}~", $BackupRestoreProjectName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PubsubPublisherSA}~", '[]')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{ResourceToCreate}~", 'TOPIC')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PubsubSubscriberSA}~", '[]')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{PubsubTopic}~", 'backup_restore_topic')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageClass}~", $BackupRestoreStorageClass)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageLifecycle}~", '35')
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageLocation}~", $BackupRestoreStorageLocation)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StorageName}~", $storageName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{StoragePermissions}~", $storagePermissions)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{VarGroupToUpdate}~", $VarGroupName)
       $updateVarGroupBody = $updateVarGroupBody.replace("~{Env}~", $BackupRestoreEnv)
       
       #Write-Host "Body: $updateVarGroupBody"

       $updateVariableGroup = Invoke-RestMethod -Method PUT -Uri $updateVarGroupURI -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $updateVarGroupBody
       return $updateVariableGroup
    }
    catch {
       
       [Exception]$ex = $_.Exception
       Throw "Unable to update variable group $VarGroupName -> $ex.Message"

       Exit 0
    }

}

function SetupBackupRestoreSolutionForOtherGCPProjects {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$BackupRestoreEnv,
      [string]$BackupRestoreStorageClass,
      [string]$BackupRestoreStorageLocation,
      [string]$BackupRestoreCloudSchedRegion,
      [string]$BackupRestoreCloudSchedTimezone,
      [string]$BackupRestoreProjectID,
      [string]$BackupRestoreProjectName,
      [string]$BackupRestoreSA,
      [string]$BackupRestoreSAClientEmail,
      [string]$BackupRestoreCredFile,
      [string]$BackupRestoreCreateCloudSched,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Import-Module $PSM1Path

    if($BackupRestoreEnv -eq 'Sbx'){
        
       $env = "sbx"
    }
    elseif($BackupRestoreEnv -eq 'Dev' -or $BackupRestoreEnv -eq 'Test' -or $BackupRestoreEnv -eq 'Stage' -or $BackupRestoreEnv -eq 'Perf'){
        
       $env = "npd"
    }
    elseif($BackupRestoreEnv -eq 'Prod'){
        
       $env = "prd"
    }

    $cloudFunctionName = $env + "-" + $AirID + "-backup-restore-function"
    $bucketName = $BackupRestoreProjectName + "-backup-restore-bucket"
    $backupRestoreAppName = $AppName + '-backup-restore'
    $storagename = "backup-restore-bucket"
    $alertsMonitoringRepo = $AppName + "_alerts_monitoring_backup_restore_repo_AIR" + $AirID
    $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_backup_restore_AIR" + $AirID
    $backupRestoreRepo = $AppName + "_backup_restore_repo_AIR" + $AirID
    $pubsubTopic = "App_" + $AirID + "_backup_restore_topic"
    $backupRestoreCIPipeline = $AppName + "_backup_restore_CI_AIR" + $AirID
    $backupRestoreCDPipeline = $AppName + "_backup_restore_CD_AIR" + $AirID

    #Cloning the Repositories
    $cloneRepos = CloneRepos -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -backupRestoreRepo $backupRestoreRepo -alertsMonitoringRepo $alertsMonitoringRepo

    #Modify Backup Restore repo to update the credential file in azure-pipelines.yml
    $updateBackupRestoreRepo = UpdateBackupRestoreRepoForOtherEnv -backupRestoreRepo $backupRestoreRepo -BackupRestoreEnv $BackupRestoreEnv -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreCreateCloudSched $BackupRestoreCreateCloudSched -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

    #Update Alerts Monitoring Repo
    $updateAlertsMonitoringRepo = UpdateBackupRestoreAlertsMonitoringRepo -alertsMonitoringRepo $alertsMonitoringRepo -cloudFunctionName $cloudFunctionName -AirID $AirID -backupRestoreAppName $backupRestoreAppName -BackupRestoreEnv $BackupRestoreEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName
    
    #Update Alerts Monitoring Pipeline Variables
    $updateAlertsMonitoringPipeline = UpdateAlertsMonitoringPipelineVariables -alertsMonitoringPipeline $alertsMonitoringPipeline -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreCredFile $BackupRestoreCredFile -BackupRestoreSAClientEmail $BackupRestoreSAClientEmail -pubsubTopic $pubsubTopic -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Modify Variable Group
    $modifyBackupRestoreVariableGroup = ModifyBackupRestoreVariableGroupsForRedeploy -BackupRestoreEnv $BackupRestoreEnv -AppName $AppName -AirID $AirID -BackupRestoreSA $BackupRestoreSA -BackupRestoreProjectID $BackupRestoreProjectID -BackupRestoreProjectName $BackupRestoreProjectName -BackupRestoreStorageClass $BackupRestoreStorageClass -BackupRestoreStorageLocation $BackupRestoreStorageLocation -storagename $storagename -base64AuthInfo $base64AuthInfo -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName
    
    #Output and pending action items
    Write-Host
    Write-Host "Modification of the Repositories and $($BackupRestoreEnv) Variable Group has been completed!" -ForegroundColor Green
    Write-Host
    Write-Host "Pending item is to execute the pipelines manually in the order mentioned below to provision the resources and deploy the solution to your other GCP Project for $($BackupRestoreEnv) Environment" -ForegroundColor Yellow
    Write-Host "1. $($backupRestoreCIPipeline)"
    Write-Host "2. $($backupRestoreCDPipeline)"
    Write-Host "3. $($alertsMonitoringPipeline)"
    Write-Host 
    Write-Host "If you have any questions, please reach out to ArchitectureServices.DaaS.NoSQL@accenture.com"
}

function GetAdhocBackupRestorePipelineDetails {
    
    Param(
      
      $pipelineID,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestoreBucket,
      [string]$AdhocBackupRestoreFilePath,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestorePubsubTopic,
      [string]$type,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      $AdhocBackupRestoreFilter
    )

    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions/$($pipelineID)?api-version=6.0"

    if($AdhocBackupRestoreCollections.Count -ne 0 -and $type -eq "ADHOC_BACKUP"){
    
        try {

            $pipelineDetails = Invoke-RestMethod -Uri $pipelineURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
            $pipelineDetails.variables.BUCKET.value = $AdhocBackupRestoreBucket
            $pipelineDetails.variables.GCP_PROJECT_ID.value = $AdhocBackupRestoreProjectID
            $pipelineDetails.variables.GCP_CREDENTIAL_FILE.value = $AdhocBackupRestoreCredFile
            $pipelineDetails.variables.SR_ACCT_CLIENT_EMAIL.value = $AdhocBackupRestoreSAClientEmail
            $pipelineDetails.variables.PUBSUB_TOPIC.value = $AdhocBackupRestorePubsubTopic
            $pipelineDetails.variables.TYPE.value = $type
            $pipelineDetails.variables.FILEPATH.value = ""

            if($AdhocBackupRestoreFilter.count -ne 0){
                
                $pipelineDetails.variables.FILTER.value = $AdhocBackupRestoreFilter
            }
            else{
                
                $pipelineDetails.variables.FILTER.value = ""
            }

            for($x = 1; $x -le $AdhocBackupRestoreCollections.Count; $x++){
    
                $name = 'COLLECTION' + $x
                $value = $AdhocBackupRestoreCollections[$x-1]

                if(!$pipelineDetails.variables.$name){

                    $createVar = [PSCustomObject]@{
    
                        value = $value
                        allowOverride = $true
                    }

                    Add-Member -MemberType NoteProperty -Name $name -Value $createVar -InputObject $pipelineDetails.variables
                }
                else{
                    
                    $pipelineDetails.variables.$name.value = $value
                }
            }

            $json = $pipelineDetails | ConvertTo-Json -Depth 3
            return $json
        }
        catch {

           [Exception]$ex = $_.Exception
           Throw "Unable to get the Pipeline details -> $ex.Message"

           Exit 0
        }

    }
    elseif($AdhocBackupRestoreCollections.Count -eq 0 -and $type -eq "ADHOC_BACKUP"){

        try {

            $pipelineDetails = Invoke-RestMethod -Uri $pipelineURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
            $pipelineDetails.variables.BUCKET.value = $AdhocBackupRestoreBucket
            $pipelineDetails.variables.GCP_PROJECT_ID.value = $AdhocBackupRestoreProjectID
            $pipelineDetails.variables.GCP_CREDENTIAL_FILE.value = $AdhocBackupRestoreCredFile
            $pipelineDetails.variables.SR_ACCT_CLIENT_EMAIL.value = $AdhocBackupRestoreSAClientEmail
            $pipelineDetails.variables.PUBSUB_TOPIC.value = $AdhocBackupRestorePubsubTopic
            $pipelineDetails.variables.TYPE.value = $type
            $pipelineDetails.variables.FILEPATH.value = ""

            if($AdhocBackupRestoreFilter.count -ne 0){
                
                $pipelineDetails.variables.FILTER.value = $AdhocBackupRestoreFilter
            }
            else{
                
                $pipelineDetails.variables.FILTER.value = ""
            }

            $json = $pipelineDetails | ConvertTo-Json -Depth 3
            return $json
        }
        catch {

           [Exception]$ex = $_.Exception
           Throw "Unable to get the Pipeline details -> $ex.Message"

           Exit 0
        }
    }
    elseif($AdhocBackupRestoreCollections.Count -eq 0 -and $type -eq "ADHOC_RESTORE"){

        try {
            
            Write-Host "Pipeline URL: $pipelineURL"

            $pipelineDetails = Invoke-RestMethod -Uri $pipelineURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
            $pipelineDetails.variables.BUCKET.value = $AdhocBackupRestoreBucket
            $pipelineDetails.variables.FILEPATH.value = $AdhocBackupRestoreFilePath
            $pipelineDetails.variables.GCP_PROJECT_ID.value = $AdhocBackupRestoreProjectID
            $pipelineDetails.variables.GCP_CREDENTIAL_FILE.value = $AdhocBackupRestoreCredFile
            $pipelineDetails.variables.SR_ACCT_CLIENT_EMAIL.value = $AdhocBackupRestoreSAClientEmail
            $pipelineDetails.variables.PUBSUB_TOPIC.value = $AdhocBackupRestorePubsubTopic
            $pipelineDetails.variables.TYPE.value = $type
            
            if($AdhocBackupRestoreFilter.count -ne 0){
                
                $pipelineDetails.variables.FILTER.value = $AdhocBackupRestoreFilter
            }
            else{
                
                $pipelineDetails.variables.FILTER.value = ""
            }

            $json = $pipelineDetails | ConvertTo-Json -Depth 3
            return $json
        }
        catch {

           [Exception]$ex = $_.Exception
           Throw "Unable to get the Pipeline details -> $ex.Message"

           Exit 0
        }
    }
    elseif($AdhocBackupRestoreCollections.Count -ne 0 -and $type -eq "ADHOC_RESTORE"){

        try {

            $pipelineDetails = Invoke-RestMethod -Uri $pipelineURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
            $pipelineDetails.variables.BUCKET.value = $AdhocBackupRestoreBucket
            $pipelineDetails.variables.FILEPATH.value = $AdhocBackupRestoreFilePath
            $pipelineDetails.variables.GCP_PROJECT_ID.value = $AdhocBackupRestoreProjectID
            $pipelineDetails.variables.GCP_CREDENTIAL_FILE.value = $AdhocBackupRestoreCredFile
            $pipelineDetails.variables.SR_ACCT_CLIENT_EMAIL.value = $AdhocBackupRestoreSAClientEmail
            $pipelineDetails.variables.PUBSUB_TOPIC.value = $AdhocBackupRestorePubsubTopic
            $pipelineDetails.variables.TYPE.value = $type
            
            if($AdhocBackupRestoreFilter.count -ne 0){
                
                $pipelineDetails.variables.FILTER.value = $AdhocBackupRestoreFilter
            }
            else{
                
                $pipelineDetails.variables.FILTER.value = ""
            }

            for($x = 1; $x -le $AdhocBackupRestoreCollections.Count; $x++){
    
                $name = 'COLLECTION' + $x
                $value = $AdhocBackupRestoreCollections[$x-1]

                if(!$pipelineDetails.variables.$name){

                    $createVar = [PSCustomObject]@{
    
                        value = $value
                        allowOverride = $true
                    }

                    Add-Member -MemberType NoteProperty -Name $name -Value $createVar -InputObject $pipelineDetails.variables
                }
                else{
                    
                    $pipelineDetails.variables.$name.value = $value
                }
            }

            $json = $pipelineDetails | ConvertTo-Json -Depth 3
            return $json
        }
        catch {

           [Exception]$ex = $_.Exception
           Throw "Unable to get the Pipeline details -> $ex.Message"

           Exit 0
        }
    }
}

function UpdateAdhocBackupRestorePipelineVariables {

    Param(
      
      [string]$AdhocBackupRestorePipeline,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestoreBucket,
      $AdhocBackupRestoreFilePath,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestorePubsubTopic,
      [string]$type,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      $AdhocBackupRestoreFilter

    )

    Write-Verbose "Updating Pipeline Variable for Adhoc Backup and Restore..." -Verbose

    #Get Pipeline ID
    $pipeline = $AdhocBackupRestorePipeline
    $pipelineID = GetPipelineID -pipeline $pipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Get Pipeline Details
    $getAdhocBackupRestorePipelineDetails = GetAdhocBackupRestorePipelineDetails -pipelineID $pipelineID -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -type $type -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

    #Update the Pipeline Variables
    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions/$($pipelineID)?api-version=6.0"
    
    try {

        $updatePipeline = Invoke-RestMethod -Method Put -Uri $pipelineURL -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $getAdhocBackupRestorePipelineDetails
        return $updatePipeline
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to update the Pipeline variable -> $ex.Message"

        Exit 0
    }
}

function UpdateAdhocBackupRestoreRepo {
    
    Param(
      
      [string]$AdhocBackupRestoreRepository,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestoreYAMLFile,
      [string]$backupRestoreAppName,
      [string]$AirID,
      [string]$AdhocBackupRestoreEnv,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $PAT,
      [string]$RequestorEmail,
      [string]$RequestorName
    )
    
    $strArrayYAML = @();

    Write-Verbose "Cloning the Repository..." -Verbose

    try {

        cd $PSScriptRoot

        git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$AdhocBackupRestoreRepository 2>$null
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to clone the repository -> $ex.Message"

        Exit 0
    }

    Write-Verbose "Updating the Repository for Adhoc Backup and Restore..." -Verbose

    cd "$PSScriptRoot\$AdhocBackupRestoreRepository"

    #update YAML file
    $adhocBackupRestoreymlPath = "$PSScriptRoot\$AdhocBackupRestoreRepository\$AdhocBackupRestoreYAMLFile"
    $adhocBackupRestoreymlContent = Get-Content -Path $adhocBackupRestoreymlPath -ErrorAction Stop

    if ($AdhocBackupRestoreCollections.count -ne 0){

        $strArrayYAML = '"COLLECTIONS":[';
        $strArrayYAMLEnd = '], "FILEPATH":"$(FILEPATH)", "FILTER":"$(FILTER)", "BuildId":"$(Build.BuildId)", "RequestedForEmail":"$(Build.RequestedForEmail)"}' + "'"

        for ($x = 1; $x -le $AdhocBackupRestoreCollections.Count; $x++){

            $str = '"$(COLLECTION' + $x + ')",'

            $strArrayYAML += $str

        }

        $strArrayYAML = $strArrayYAML -replace ".$"
        $strArrayYAML += $strArrayYAMLEnd
    }
    else{
        
        $strArrayYAML = '"COLLECTIONS":[$(COLLECTIONS)';
        $strArrayYAMLEnd = '], "FILEPATH":"$(FILEPATH)", "FILTER":"$(FILTER)", "BuildId":"$(Build.BuildId)", "RequestedForEmail":"$(Build.RequestedForEmail)"}' + "'"

        $strArrayYAML += $strArrayYAMLEnd
    }

    $command = $adhocBackupRestoreymlContent -match 'gcloud pubsub'
    $replace = $command.Substring(134)
    $replaceCollection = $adhocBackupRestoreymlContent.Replace("$($replace)","$($strArrayYAML)")
    $OldEnvi = $replaceCollection[23]
    $newEnvi = "    environment: '$($AirID)-$($backupRestoreAppName)-GCP-$($AdhocBackupRestoreEnv)'"
    $ReplaceEnv = $replaceCollection.Replace("$($OldEnvi)", "$($newEnvi)")
    $ReplaceEnv | Set-Content -Path $adhocBackupRestoreymlPath

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "update $($AdhocBackupRestoreYAMLFile)" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$AdhocBackupRestoreRepository >$null 2>&1
    cd $PSScriptRoot
}

function TriggerAdhocBackupRestorePipeline {
    
    
    Param(
      
      [string]$AdhocBackupRestorePipeline,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      [string]$AdhocBackupRestorePubsubTopic
    )

    Write-Verbose "Executing Pipeline $($AdhocBackupRestorePipeline)..." -Verbose

    #Get Pipeline ID
    $pipeline = $AdhocBackupRestorePipeline
    $pipelineID = GetPipelineID -pipeline $pipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo


    #Trigger the Pipeline
    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/builds?api-version=5.0"
   
    try {

        $body = [PSCustomObject] @{

            definition = [PSCustomObject] @{
                
                id = $pipelineID
            }
        }

        $body = $body | ConvertTo-Json
    
        $triggerPipeline = Invoke-RestMethod -Method Post -Uri $pipelineURL -ContentType "application/json" -Body $body -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
        
        Write-Host
        Write-Host "Pipeline has been sent for approval. Approver/s must approve first to proceed." -ForegroundColor Yellow;
        Write-Host "Once approved and pipeline execution is completed, backup or restore will be requested through the Pubsub Topic ($($AdhocBackupRestorePubsubTopic))." -ForegroundColor Yellow;
        Write-Host
        Write-Host "If you have any questions, please reach out to ArchitectureServices.DaaS.NoSQL@accenture.com"
        Write-Host

        return $triggerPipeline
    
    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to queue the pipeline build -> $ex.Message"

       Exit 0
    }
}

function CheckifAdhocBackupRestorePipelineRepoExist {

    Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AdhocBackupRestoreRepository,
      [string]$AdhocBackupRestorePipeline
    )

    Write-Verbose "Checking if Pipeline and Repo is already existing..." -Verbose

    $getBuildPipelineListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/pipelines?api-version=6.1-preview.1"
    $getRepoListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/git/repositories?api-version=6.1-preview.1"

    try {
        
        $buildPipelineList = GetPipelineList -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo
        $buildPipeline = $buildPipelineList.value | where-object {$_.name -eq $AdhocBackupRestorePipeline}
        $buildPipelineCount = $buildPipeline | Measure-Object

        $repoList = GetRepoList -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo
        $repo = $repoList.value | where-object {$_.name -eq $AdhocBackupRestoreRepository}
        $repoCount = $repo | Measure-Object
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get pipeline and repo list -> $ex.Message"
    }

    if($buildPipelineCount.Count -ne 0 -or $repoCount.Count -ne 0){
        
        return $true
    }
    elseif($buildPipelineCount.Count -eq 0 -or $repoCount.Count -eq 0){
        
        return $false
    }
}

function PerformAdhocBackupSpecificCollection {
    
    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName,
      [string]$AdhocBackupRestoreEnv,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestorePipeline,
      [string]$AdhocBackupRestoreRepository,
      [string]$AdhocBackupRestoreYAMLFile,
      [string]$AdhocBackupRestoreBucket,
      [string]$AdhocBackupRestoreFilePath,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestorePubsubTopic,
      $AdhocBackupRestoreFilter
    )

    Import-Module $PSM1Path

    $type = "ADHOC_BACKUP"
    $backupRestoreAppName = $AppName + '-backup-restore'

    #Validate if collections has been provided
    if($AdhocBackupRestoreCollections.Count -ne 0){
        
        #Update adhoc backup and restore pipeline variables
        $updateAdhocBackupRestorePipeline = UpdateAdhocBackupRestorePipelineVariables -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -type $type -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

        #Update adhoc backup and restore repo
        $updateAdhocBackupRestoreRepo = UpdateAdhocBackupRestoreRepo -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -backupRestoreAppName $backupRestoreAppName -AirID $AirID -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

        #Trigger Pipeline build
        $triggerAdhocBackupRestorePipeline = TriggerAdhocBackupRestorePipeline -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic
        
        return $true
    }
    else{
       
        return $false
    }
}

function PerformAdhocBackupAllCollections {
    
    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName,
      [string]$AdhocBackupRestoreEnv,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestorePipeline,
      [string]$AdhocBackupRestoreRepository,
      [string]$AdhocBackupRestoreYAMLFile,
      [string]$AdhocBackupRestoreBucket,
      [string]$AdhocBackupRestoreFilePath,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestorePubsubTopic,
      $AdhocBackupRestoreFilter
    )

    Import-Module $PSM1Path

    $type = "ADHOC_BACKUP"
    $backupRestoreAppName = $AppName + '-backup-restore'

    #Validate if collections has been provided
    if($AdhocBackupRestoreCollections.Count -eq 0){
        
        #Update adhoc backup and restore pipeline variables
        $updateAdhocBackupRestorePipeline = UpdateAdhocBackupRestorePipelineVariables -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -type $type -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

        #Update adhoc backup and restore repo
        $updateAdhocBackupRestoreRepo = UpdateAdhocBackupRestoreRepo -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -backupRestoreAppName $backupRestoreAppName -AirID $AirID -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

        #Trigger Pipeline build
        $triggerAdhocBackupRestorePipeline = TriggerAdhocBackupRestorePipeline -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic
        
        return $true
    }
    else{
        
        return $false
    }
}

function PerformAdhocRestoreSpecificCollection {
    
    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName,
      [string]$AdhocBackupRestoreEnv,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestorePipeline,
      [string]$AdhocBackupRestoreRepository,
      [string]$AdhocBackupRestoreYAMLFile,
      [string]$AdhocBackupRestoreBucket,
      [string]$AdhocBackupRestoreFilePath,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestorePubsubTopic,
      $AdhocBackupRestoreFilter
    )

    Import-Module $PSM1Path

    $type = "ADHOC_RESTORE"
    $backupRestoreAppName = $AppName + '-backup-restore'

    #Validate if collections has been provided
    If($AdhocBackupRestoreCollections.Count -ne 0){
        
        #Update adhoc backup and restore pipeline variables
        $updateAdhocBackupRestorePipeline = UpdateAdhocBackupRestorePipelineVariables -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -type $type -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

        #Update adhoc backup and restore repo
        $updateAdhocBackupRestoreRepo = UpdateAdhocBackupRestoreRepo -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -backupRestoreAppName $backupRestoreAppName -AirID $AirID -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

        #Trigger Pipeline build
        $triggerAdhocBackupRestorePipeline = TriggerAdhocBackupRestorePipeline -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic
        
        return $true
    
    }
    Else{
            
        return $false
    }
}

function PerformAdhocRestoreAllCollections {
    
    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName,
      [string]$AdhocBackupRestoreEnv,
      [string]$AdhocBackupRestoreProjectID,
      [string]$AdhocBackupRestoreSAClientEmail,
      [string]$AdhocBackupRestoreCredFile,
      [string]$AdhocBackupRestorePipeline,
      [string]$AdhocBackupRestoreRepository,
      [string]$AdhocBackupRestoreYAMLFile,
      [string]$AdhocBackupRestoreBucket,
      [string]$AdhocBackupRestoreFilePath,
      $AdhocBackupRestoreCollections,
      [string]$AdhocBackupRestorePubsubTopic,
      $AdhocBackupRestoreFilter
    )

    Import-Module $PSM1Path

    $type = "ADHOC_RESTORE"
    $backupRestoreAppName = $AppName + '-backup-restore'

    #Validate if collections has been provided
    If($AdhocBackupRestoreCollections.Count -eq 0){
        
        #Update adhoc backup and restore pipeline variables
        $updateAdhocBackupRestorePipeline = UpdateAdhocBackupRestorePipelineVariables -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AdhocBackupRestoreBucket $AdhocBackupRestoreBucket -AdhocBackupRestoreFilePath $AdhocBackupRestoreFilePath -AdhocBackupRestoreProjectID $AdhocBackupRestoreProjectID -AdhocBackupRestoreCredFile $AdhocBackupRestoreCredFile -AdhocBackupRestoreSAClientEmail $AdhocBackupRestoreSAClientEmail -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic -type $type -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestoreFilter $AdhocBackupRestoreFilter

        #Update adhoc backup and restore repo
        $updateAdhocBackupRestoreRepo = UpdateAdhocBackupRestoreRepo -AdhocBackupRestoreRepository $AdhocBackupRestoreRepository -AdhocBackupRestoreCollections $AdhocBackupRestoreCollections -AdhocBackupRestoreYAMLFile $AdhocBackupRestoreYAMLFile -backupRestoreAppName $backupRestoreAppName -AirID $AirID -AdhocBackupRestoreEnv $AdhocBackupRestoreEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

        #Trigger Pipeline build
        $triggerAdhocBackupRestorePipeline = TriggerAdhocBackupRestorePipeline -AdhocBackupRestorePipeline $AdhocBackupRestorePipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo -AdhocBackupRestorePubsubTopic $AdhocBackupRestorePubsubTopic
    
        return $true

    }
    Else{
       
        return $false
    }
}