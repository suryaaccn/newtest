﻿function GetDetails {
    
    Param(

       [string]$AzureDevOpsOrg,
       [string]$AzureDevOpsProjectName,
       $base64AuthInfo,
       [string]$Repo,
       [string]$ConfigFile
    )

    try{
        
        $GetConfigDetailsURI = "https://dev.azure.com/$($AzureDevOpsOrg)/$($AzureDevOpsProjectName)/_apis/git/repositories/$($Repo)/items?path=$($ConfigFile)&download=true&api-version=6.0"
        $configDetails = Invoke-RestMethod -Uri $GetConfigDetailsURI -Method Get -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
        
    }
    catch {

        #[Exception]$ex = $_.Exception
        Throw "Unable to get configuration details -> $_.Exception.Message"

        #Exit 0
    }

    return $configDetails
}

function ValidateAlertsMonitoringSetupInputs {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AlertsMonitoringEnv,
      [string]$AlertsMonitoringProjectID,
      [string]$AlertsMonitoringCredFile,
      [string]$AlertsMonitoringSAClientEmail
    )

    $validateAlertsMonitoringSetupInputsResult = '{"code": 0, "desc":"" }'
    $validateAlertsMonitoringSetupInputsResult = ConvertFrom-Json -InputObject $validateAlertsMonitoringSetupInputsResult

    if([string]::IsNullOrEmpty($PAT)) {   
        $validateAlertsMonitoringSetupInputsResult.code = -1       
        $validateAlertsMonitoringSetupInputsResult.desc = "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret."
        return $validateAlertsMonitoringSetupInputsResult
    }
    if("undefined" -eq "$PAT") {            
        $validateAlertsMonitoringSetupInputsResult.code = -1       
        $validateAlertsMonitoringSetupInputsResult.desc = "Azure DevOps Personal Access Token (PAT) cannot be EMPTY or NULL. Please add vsts.pat in build variable and change it's type to secret."
        return $validateAlertsMonitoringSetupInputsResult
    }
    if([string]::IsNullOrEmpty($AirID)) {            
        $validateAlertsMonitoringSetupInputsResult.code = -1       
        $validateAlertsMonitoringSetupInputsResult.desc = "Air ID cannot be EMPTY or NULL. Please make sure to provide a valid Air ID."
        return $validateAlertsMonitoringSetupInputsResult   
    }
    if([string]::IsNullOrEmpty($AppName)) {            
        $validateAlertsMonitoringSetupInputsResult.code = -1       
        $validateAlertsMonitoringSetupInputsResult.desc = "Application Name cannot be EMPTY or NULL. Please make sure to provide a valid Application Name."
        return $validateAlertsMonitoringSetupInputsResult       
    }
    if([string]::IsNullOrEmpty($AlertsMonitoringEnv) -or [string]::IsNullOrEmpty($AlertsMonitoringProjectID) -or [string]::IsNullOrEmpty($AlertsMonitoringCredFile) -or [string]::IsNullOrEmpty($AlertsMonitoringSAClientEmail)){
        
        $validateAlertsMonitoringSetupInputsResult.code = -1       
        $validateAlertsMonitoringSetupInputsResult.desc = "Please make sure to provide all the details needed in the JSON file."
        return $validateAlertsMonitoringSetupInputsResult
    }

    if($AlertsMonitoringEnv -ne 'Sbx' -and $AlertsMonitoringEnv -ne 'Dev' -and $AlertsMonitoringEnv -ne 'Test' -and $AlertsMonitoringEnv -ne 'Stage' -and $AlertsMonitoringEnv -ne 'Perf' -and $AlertsMonitoringEnv -ne 'Prod'){
           
        $validateAlertsMonitoringSetupInputsResult.code = -1       
        $validateAlertsMonitoringSetupInputsResult.desc = "Please make sure that the value for Environment in the JSON file is set to Sbx, Dev, Test, Stage, Perf, or Prod only!"
        return $validateAlertsMonitoringSetupInputsResult
    }

    return $validateAlertsMonitoringSetupInputsResult
}

function GetRepoList {
    
     Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    Write-Verbose "Getting the Repositories..." -Verbose

    $getRepoListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/git/repositories?api-version=6.1-preview.1"
    
    try {

        $repoList = Invoke-RestMethod -Uri $getRepoListURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get repo list -> $ex.Message"
    }

    return $repoList
}

function GetPipelineList {
    
     Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    Write-Verbose "Getting the Pipelines..." -Verbose

    $getBuildPipelineListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/pipelines?api-version=6.1-preview.1"
    
    try {

        $buildPipelineList = Invoke-RestMethod -Uri $getBuildPipelineListURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get pipeline list -> $ex.Message"
    }

    return $buildPipelineList
}

function CheckifAlertsMonitoringPipelineRepoExists {

    Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$alertsMonitoringRepo,
      [string]$alertsMonitoringPipeline
    )

    Write-Verbose "Checking if Pipelines and Repo are already existing..." -Verbose

    try {

        $buildPipelineList = GetPipelineList -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo
        $buildPipeline = $buildPipelineList.value | where-object {$_.name -eq $alertsMonitoringPipeline}
        $buildPipelineCount = $buildPipeline | Measure-Object

        $repoList = GetRepoList -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo
        $repo = $repoList.value | where-object {$_.name -eq $alertsMonitoringRepo}
        $repoCount = $repo | Measure-Object
 
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to get pipeline and repo list -> $ex.Message"
    }

    if($buildPipelineCount.Count -ne 0 -or $repoCount.Count -ne 0){
        
        return $true
    }
    elseif($buildPipelineCount.Count -eq 0 -or $repoCount.Count -eq 0){
        
        return $false
    }
}

function CreateRepo {
    
    Param(

       [string]$AzureDevOpsAccount,
       [string]$AzureDevOpsProjectName,
       [string]$AzureDevOpsProjectId,
       $base64AuthInfo,
       [string]$repository
    )

    Write-Verbose "Creating $($repository) Repo..." -Verbose

    try{

        # Construct the REST URL and payload to create a repository
        $createRepoURI = "https://$($AzureDevOpsAccount)/$($AzureDevOpsProjectName)/_apis/git/repositories/?api-version=1.0"
        $body = '{"name": "'+ $repository +'"}'

        # Invoke the REST call and capture the results
        $createrepo = Invoke-RestMethod -Uri $createRepoURI -Method Post -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $body
        $repoID = $createrepo.id
        $repoURL = $createrepo.webUrl  
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create the repository -> $ex.Message"

        Exit 0
    }

    return $repoURL, $repoID
}

function CreateAlertsMonitoringPipeline {
    
    Param(

        [string]$AppName,
        [string]$AirID,
        [String]$alertsMonitoringPipeline,
        [string]$AlertsMonitoringProjectID,
        [string]$AlertsMonitoringCredFile,
        [string]$AlertsMonitoringSAClientEmail,
        [string]$AzureDevOpsOrg,
        [string]$AzureDevOpsProjectId,
        [string]$AzureDevOpsProjectName,
        [string]$repository,
        [string]$repoID,
        $base64AuthInfo  
    )

    Write-Verbose "Creating $($alertsMonitoringPipeline) Pipeline..." -Verbose

    #Creating the pipeline for Alerts and Monitoring Solution
    $foldername = $AppName + "_alerts_monitoring_solution_" + $AirID + " Build Pipelines"
    $AzurePipelineYmlFileName = "alerts-monitoring.yml"

    $pipelineTemplatePath = "$PSScriptRoot\template\pipeline-builds\alerts-monitoring-azure-pipelines-api-request-body.json"
    [String]$pipelineTemplateContent = Get-Content -Path "$($pipelineTemplatePath)" | Out-String
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzurePipelineYmlFileName}~", $AzurePipelineYmlFileName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{GCPProjectID}~", $AlertsMonitoringProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{GCPCredFile}~", $AlertsMonitoringCredFile)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{DefaultSAClientEmail}~", $AlertsMonitoringSAClientEmail)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsOrg}~", $AzureDevOpsOrg)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectID}~", $AzureDevOpsProjectID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsProjectName}~", $AzureDevOpsProjectName)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsPipelineName}~", $alertsMonitoringPipeline)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoName}~", $repository)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{AzureDevOpsRepoId}~", $repoID)
    $pipelineTemplateContent = $pipelineTemplateContent.replace("~{Folder}~", $foldername)    

    $createPipelineURI = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=5.0-preview.6"

    try{

        $createPipelineResponse = Invoke-RestMethod -Method Post -Uri $createPipelineURI -Body $pipelineTemplateContent -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}  
        return $createPipelineResponse
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to create Pipeline $alertsMonitoringPipeline -> $ex.Message"
            
        Exit 0
    }
}

function SetupAlertsMonitoringPipeline {

    Param(

        [string]$alertsMonitoringRepo,
        [string]$cloudFunctionName,
        [string]$AirID,
        [string]$alertsMonitoringAppName,
        [string]$AlertsMonitoringEnv,
        [string]$AppName,
        [String]$alertsMonitoringPipeline,
        [string]$AlertsMonitoringProjectID,
        [string]$AlertsMonitoringCredFile,
        [string]$AlertsMonitoringSAClientEmail,
        [string]$AzureDevOpsAccount,
        [string]$AzureDevOpsProjectName,
        [string]$AzureDevOpsProjectId,
        $base64AuthInfo,
        $PAT,
        [string]$RequestorEmail,
        [string]$RequestorName
    )

    #Creating GIT repo for alerts monitoring 
    $repository = $alertsMonitoringRepo
    $repositoryURL, $repoID = CreateRepo -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -repository $repository
    
    #Write-Host "Repository URL: $repositoryURL"
    #Write-Host "Repository ID: $repoID"

    #clone the repo
    cd $PSScriptRoot

    git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository 2>$null

    #Copy alerts monitoring files in the repository
    $yamlFilePath = "$PSScriptRoot\template\alerts-monitoring\alerts-monitoring.yml"
    $alertsjsonPath1 = "$PSScriptRoot\template\alerts-monitoring\firestore-operation-alerts.json"
    $alertsjsonPath2 = "$PSScriptRoot\template\alerts-monitoring\firestore-operation-dashboard.json"
    $alertsjsonPath3 = "$PSScriptRoot\template\alerts-monitoring\firestore-updatethresholdfunction-alerts.json"

    try{

       cd $PSScriptRoot\$repository
            
       Copy-Item -Path $yamlFilePath -Destination $PSScriptRoot\$repository -ErrorAction Stop

       New-Item -ItemType "directory" -Path "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop | Out-Null
       Copy-Item -Path $alertsjsonPath1 -Destination "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop
       Copy-Item -Path $alertsjsonPath2 -Destination "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop
       Copy-Item -Path $alertsjsonPath3 -Destination "$PSScriptRoot\$repository\AlertsMonitoring" -ErrorAction Stop
    }
    catch{

       [Exception]$ex = $_.Exception
       Throw "Unable to copy the template files -> $ex.Message"
            
       Exit 0
    }

    #Updating firestore-updatethresholdfunction-alerts.json for the Cloud Function 
    $alertsjsonPath = "$PSScriptRoot\$repository\AlertsMonitoring\firestore-updatethresholdfunction-alerts.json"
    $alertsjsonContent = Get-Content -Path $alertsjsonPath -ErrorAction Stop
    $CloudfunctionInfo = $alertsjsonContent[26]
    $new = '        "filter": "metric.type=\"cloudfunctions.googleapis.com/function/execution_count\" resource.type=\"cloud_function\" metric.label.\"status\"=\"error\" resource.label.\"function_name\"=\"' + $cloudFunctionName + '\"",'
    $CloudFunction = $alertsjsonContent.Replace("$($CloudfunctionInfo)", "$($new)")
    $CloudfunctionInfo2 = $alertsjsonContent[47]
    $new2 = '        "filter": "metric.type=\"cloudfunctions.googleapis.com/function/execution_count\" resource.type=\"cloud_function\" metric.label.\"status\"=\"timeout\" resource.label.\"function_name\"=\"' + $cloudFunctionName + '\"",'
    $CloudFunction2 = $CloudFunction.Replace("$($CloudfunctionInfo2)", "$($new2)")
    $CloudFunction2 | Set-Content -Path $alertsjsonPath -ErrorAction Stop

    #Update alerts-monitoring.yml
    $alertsymlPath = "$PSScriptRoot\$repository\alerts-monitoring.yml"
    $alertsyml = Get-Content -Path $alertsymlPath
    $replaceAIR = $alertsyml.Replace("<AIRID>", "$($AirID)") 
    $replaceAppName = $replaceAIR.Replace("<AppName>", "$($alertsMonitoringAppName)")
    $replaceEnv = $replaceAppName.Replace("<Env>", "$($AlertsMonitoringEnv)")
    $replaceEnv | Set-Content -Path $alertsymlPath -ErrorAction Stop

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "add alerts-monitoring.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$repository >$null 2>&1
    cd $PSScriptRoot

    $createAlertsMonitoringPipeline = CreateAlertsMonitoringPipeline -AppName $AppName -AirID $AirID -cloudFunctionName $cloudFunctionName -alertsMonitoringPipeline $alertsMonitoringPipeline -AlertsMonitoringProjectID $AlertsMonitoringProjectID -AlertsMonitoringCredFile $AlertsMonitoringCredFile -AlertsMonitoringSAClientEmail $AlertsMonitoringSAClientEmail -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectId $AzureDevOpsProjectId -AzureDevOpsProjectName $AzureDevOpsProjectName -repository $repository -repoID $repoID -base64AuthInfo $base64AuthInfo 
}

function SetupAlertsMonitoringSolution {

    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AlertsMonitoringEnv,
      [string]$AlertsMonitoringProjectID,
      [string]$AlertsMonitoringCredFile,
      [string]$AlertsMonitoringSAClientEmail,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Import-Module $PSM1Path

    if($AlertsMonitoringEnv -eq 'Sbx'){
        
       $env = "sbx"
    }
    elseif($AlertsMonitoringEnv -eq 'Dev' -or $AlertsMonitoringEnv -eq 'Test' -or $AlertsMonitoringEnv -eq 'Stage' -or $AlertsMonitoringEnv -eq 'Perf'){
        
       $env = "npd"
    }
    elseif($AlertsMonitoringEnv -eq 'Prod'){
        
       $env = "prd"
    }

    $cloudFunctionName = $env + "-" + $AirID + "-update-threshold-function"
    $alertsMonitoringRepo = $AppName + "_alerts_monitoring_repo_AIR" + $AirID
    $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_AIR" + $AirID
    $alertsMonitoringAppName = $AppName + '-alerts-monitoring'

    SetupAlertsMonitoringPipeline -alertsMonitoringRepo $alertsMonitoringRepo -cloudFunctionName $cloudFunctionName -AirID $AirID -alertsMonitoringAppName $alertsMonitoringAppName -AlertsMonitoringEnv $AlertsMonitoringEnv -AppName $AppName -alertsMonitoringPipeline $alertsMonitoringPipeline -AlertsMonitoringProjectID $AlertsMonitoringProjectID -AlertsMonitoringCredFile $AlertsMonitoringCredFile -AlertsMonitoringSAClientEmail $AlertsMonitoringSAClientEmail -AzureDevOpsAccount $AzureDevOpsAccount -AzureDevOpsProjectName $AzureDevOpsProjectName -AzureDevOpsProjectId $AzureDevOpsProjectId -base64AuthInfo $base64AuthInfo -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName

    #Output and pending action items
    Write-Host
    Write-Host "Creation of Pipeline, Modification of the Repository and Pipeline Variables has been completed!" -ForegroundColor Green
    Write-Host
    Write-Host "Please take note of the pipeline: $($alertsMonitoringPipeline)" -ForegroundColor Yellow;
    Write-Host
    Write-Host "Action Items:" -ForegroundColor Yellow;
    Write-Host "* Provide Approvers in the Environments"
    Write-Host "* Execute the pipeline manually to deploy Alerts and Monitoring solution"
    Write-Host 
    Write-Host "If you have any questions, please reach out to ArchitectureServices.DaaS.NoSQL@accenture.com"
}

function CloneRepo {

    Param(
      
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $PAT,
      [string]$alertsMonitoringRepo
    )

    Write-Verbose "Cloning the Repository..." -Verbose

    try {

        cd $PSScriptRoot

        git clone https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$alertsMonitoringRepo 2>$null

        Write-Host "Successfully cloned the repo!"
    }
    catch {

        [Exception]$ex = $_.Exception
        Throw "Unable to clone the repository -> $ex.Message"

        Exit 0
    }
}

function UpdateAlertsMonitoringRepo {

    Param(
      
      [string]$alertsMonitoringRepo,
      [string]$cloudFunctionName,
      [string]$AirID,
      [string]$alertsMonitoringAppName,
      [string]$AlertsMonitoringEnv,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $PAT,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Write-Verbose "Updating the Repository for Alerts and Monitoring..." -Verbose

    cd "$PSScriptRoot\$alertsMonitoringRepo"

    #update firestore-updatethresholdfunction-alerts.json for the Cloud Function
    $alertsjsonPath = "$PSScriptRoot\$alertsMonitoringRepo\AlertsMonitoring\firestore-updatethresholdfunction-alerts.json"
    $alertsjsonContent = Get-Content -Path $alertsjsonPath -ErrorAction Stop
    $CloudfunctionInfo = $alertsjsonContent[26]
    $new = '        "filter": "metric.type=\"cloudfunctions.googleapis.com/function/execution_count\" resource.type=\"cloud_function\" metric.label.\"status\"=\"error\" resource.label.\"function_name\"=\"' + $cloudFunctionName + '\"",'
    $CloudFunction = $alertsjsonContent.Replace("$($CloudfunctionInfo)", "$($new)")
    $CloudfunctionInfo2 = $CloudFunction[47]
    $new2 = '        "filter": "metric.type=\"cloudfunctions.googleapis.com/function/execution_count\" resource.type=\"cloud_function\" metric.label.\"status\"=\"timeout\" resource.label.\"function_name\"=\"' + $cloudFunctionName + '\"",'
    $CloudFunction2 = $CloudFunction.Replace("$($CloudfunctionInfo2)", "$($new2)")
    $CloudFunction2 | Set-Content -Path $alertsjsonPath -ErrorAction Stop

    #Update alerts-monitoring.yml
    $alertsymlPath = "$PSScriptRoot\$alertsMonitoringRepo\alerts-monitoring.yml"
    $alertsyml = Get-Content -Path $alertsymlPath

    $OldEnvi = $alertsyml[23]
    $newEnvi = "    environment: '$($AirID)-$($alertsMonitoringAppName)-GCP-$($AlertsMonitoringEnv)'"
    $ReplaceEnv = $alertsyml.Replace("$($OldEnvi)", "$($newEnvi)")
    $ReplaceEnv | Set-Content -Path $alertsymlPath -ErrorAction Stop

    #Upload files in the Repo
    git config --global user.email "$RequestorEmail"
    git config --global user.name "$RequestorName"
    git add . 2>$null
    git commit -m "update alerts-monitoring.yml" >$null 2>&1
    git push https://$PAT@dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_git/$alertsMonitoringRepo >$null 2>&1

    cd $PSScriptRoot

}

function GetPipelineID {

    Param(
      
      [string]$pipeline,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    $getBuildPipelineListURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions?api-version=6.0"

    try {

       $buildPipelineList = Invoke-RestMethod -Uri $getBuildPipelineListURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
       $buildPipeline = $buildPipelineList.value| where-object {$_.name -eq $pipeline}
       $buildPipelineID = $buildPipeline.id
       return $buildPipelineID
    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to get the Pipeline ID -> $ex.Message"

       Exit 0
    }
}

function GetAlertsMonitoringPipelineDetails {
    
    Param(
      
      $pipelineID,
      [string]$AlertsMonitoringProjectID,
      [string]$AlertsMonitoringCredFile,
      [string]$AlertsMonitoringSAClientEmail,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions/$($pipelineID)?api-version=6.0"
   
    try {

        $pipelineDetails = Invoke-RestMethod -Uri $pipelineURL -Method Get -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)}
        $pipelineDetails.variables.GCP_PROJECT_ID.value = $AlertsMonitoringProjectID
        $pipelineDetails.variables.GCP_CREDENTIAL_FILE.value = $AlertsMonitoringCredFile
        $pipelineDetails.variables.SR_ACCT_CLIENT_EMAIL.value = $AlertsMonitoringSAClientEmail
        $json = @($pipelineDetails) | ConvertTo-Json
        return $json

    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to get the Pipeline details -> $ex.Message"

       Exit 0
    }
}

function UpdateAlertsMonitoringPipelineVariables {
    
    Param(
      
      [string]$alertsMonitoringPipeline,
      [string]$AlertsMonitoringProjectID,
      [string]$AlertsMonitoringCredFile,
      [string]$AlertsMonitoringSAClientEmail,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo
    )

    Write-Verbose "Updating Pipeline Variable for Alerts and Monitoring..." -Verbose

    #Get Pipeline ID
    $pipeline = $alertsMonitoringPipeline
    $pipelineID = GetPipelineID -pipeline $pipeline -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Get Pipeline Details
    $getAlertsMonitoringPipelineDetails = GetAlertsMonitoringPipelineDetails -pipelineID $pipelineID -AlertsMonitoringProjectID $AlertsMonitoringProjectID -AlertsMonitoringCredFile $AlertsMonitoringCredFile -AlertsMonitoringSAClientEmail $AlertsMonitoringSAClientEmail -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Update the Pipeline Variables
    $pipelineURL = "https://dev.azure.com/$AzureDevOpsOrg/$AzureDevOpsProjectName/_apis/build/definitions/$($pipelineID)?api-version=6.0"
   
    try {

        $updatePipeline = Invoke-RestMethod -Method Put -Uri $pipelineURL -ContentType "application/json" -Headers @{Authorization=("Basic {0}" -f $base64AuthInfo)} -Body $getAlertsMonitoringPipelineDetails
        return $updatePipeline
    }
    catch {

       [Exception]$ex = $_.Exception
       Throw "Unable to update the Pipeline variable -> $ex.Message"

       Exit 0
    } 
}

function SetupAlertsMonitoringSolutionForOtherEnvironments {
    
    Param(
      
      $PAT,
      [string]$AirID,
      [string]$AppName,
      [string]$AlertsMonitoringEnv,
      [string]$AlertsMonitoringProjectID,
      [string]$AlertsMonitoringCredFile,
      [string]$AlertsMonitoringSAClientEmail,
      [string]$AzureDevOpsAccount,
      [string]$AzureDevOpsOrg,
      [string]$AzureDevOpsProjectName,
      $base64AuthInfo,
      [string]$AzureDevOpsProjectId,
      [string]$PSM1Path,
      [string]$RequestorEmail,
      [string]$RequestorName
    )

    Import-Module $PSM1Path

    if($AlertsMonitoringEnv -eq 'Sbx'){
        
       $env = "sbx"
    }
    elseif($AlertsMonitoringEnv -eq 'Dev' -or $AlertsMonitoringEnv -eq 'Test' -or $AlertsMonitoringEnv -eq 'Stage' -or $AlertsMonitoringEnv -eq 'Perf'){
        
       $env = "npd"
    }
    elseif($AlertsMonitoringEnv -eq 'Prod'){
        
       $env = "prd"
    }

    $cloudFunctionName = $env + "-" + $AirID + "-update-threshold-function"
    $alertsMonitoringRepo = $AppName + "_alerts_monitoring_repo_AIR" + $AirID
    $alertsMonitoringPipeline = $AppName + "_alerts_monitoring_AIR" + $AirID
    $alertsMonitoringAppName = $AppName + '-alerts-monitoring'

    #Cloning the Repository
    $cloneRepo = CloneRepo -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -alertsMonitoringRepo $alertsMonitoringRepo

    #Update Alerts Monitoring Repo
    $updateAlertsMonitoringRepo = UpdateAlertsMonitoringRepo -alertsMonitoringRepo $alertsMonitoringRepo -cloudFunctionName $cloudFunctionName -AirID $AirID -alertsMonitoringAppName $alertsMonitoringAppName -AlertsMonitoringEnv $AlertsMonitoringEnv -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -PAT $PAT -RequestorEmail $RequestorEmail -RequestorName $RequestorName
    
    #Update Alerts Monitoring Pipeline Variables
    $updateAlertsMonitoringPipeline = UpdateAlertsMonitoringPipelineVariables -alertsMonitoringPipeline $alertsMonitoringPipeline -AlertsMonitoringProjectID $AlertsMonitoringProjectID -AlertsMonitoringCredFile $AlertsMonitoringCredFile -AlertsMonitoringSAClientEmail $AlertsMonitoringSAClientEmail -AzureDevOpsOrg $AzureDevOpsOrg -AzureDevOpsProjectName $AzureDevOpsProjectName -base64AuthInfo $base64AuthInfo

    #Output and pending action items
    Write-Host
    Write-Host "Modification of the Repository and Variables has been completed!" -ForegroundColor Green
    Write-Host
    Write-Host "Pending item is to execute the pipeline $($alertsMonitoringPipeline) manually to deploy the Alerts and Monitoring solution" -ForegroundColor Yellow
    Write-Host 
    Write-Host "If you have any questions, please reach out to ArchitectureServices.DaaS.NoSQL@accenture.com"

}